// hello.S - Exemplo "Hello World" em Assembly AArch64
// Imprime mensagem no stdout usando chamadas de sistema (syscalls)

.global _start          // define o símbolo de entrada do programa

.section .data
  	msg:    .ascii   "Hello, Arm64!\n"   // mensagem (sem byte nulo)
  	len = . - msg                     // calcula o comprimento da mensagem

.section .text
_start:
    // Chamada de sistema write(int fd, const void *buf, size_t count)
    mov    x0, #1          // x0 = 1 (stdout, file descriptor 1)
    ldr    x1, =msg        // x1 = endereço da string msg
    mov    x2, #len        // x2 = número de bytes (len)
    mov    x8, #64         // x8 = número da syscall 'write' (64 na AArch64)
    svc    #0              // faz a chamada de sistema (supervisor call)

    // Chamada de sistema exit(int status)
    mov    x0, #0          // x0 = 0 (status de saída)
    mov    x8, #93         // x8 = número da syscall 'exit' (93 em AArch64)
    svc    #0              // chama o kernel para encerrar
