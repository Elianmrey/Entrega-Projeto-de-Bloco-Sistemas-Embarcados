`timescale 1ns/1ps

module led_tb;

    reg sys_clk;
    reg sys_rst_n;

    wire led;

    // Instancia o DUT
    led uut (
        .sys_clk(sys_clk),
        .sys_rst_n(sys_rst_n),
        .led(led)
    );

    // Inicializa clock
    initial begin
        sys_clk = 0;
    end

    // Geração do clock
    always #18.5 sys_clk = ~sys_clk;

    // Estímulos
    initial begin

        // Reset ativo
        sys_rst_n = 0;

        #100;

        // Libera reset
        sys_rst_n = 1;

        // Aguarda tempo de simulação
        #5000;

        $finish;
    end

    // Monitor
    initial begin
        $monitor(
            "Tempo=%0t | Reset=%b | Counter=%d | LED=%b",
            $time,
            sys_rst_n,
            uut.counter,
            led
        );
    end

endmodule