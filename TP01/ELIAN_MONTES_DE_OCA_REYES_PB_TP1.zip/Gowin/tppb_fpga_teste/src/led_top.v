module led (

    input  wire sys_clk,     // clock 27 MHz
    input  wire sys_rst_n,   // reset
    input  wire key,         // botão KEY
    output reg  led          // LED onboard

);

    reg [23:0] counter;

    // 55.5 ms aproximadamente
    localparam MAX_COUNT = 24'd1499999;

    // Contador
    always @(posedge sys_clk or negedge sys_rst_n) begin

        if (!sys_rst_n)
            counter <= 24'd0;

        // Só conta quando o botão estiver pressionado
        else if (!key) begin

            if (counter < MAX_COUNT)
                counter <= counter + 1'b1;
            else
                counter <= 24'd0;

        end

        else
            counter <= 24'd0;

    end

    // Controle do LED
    always @(posedge sys_clk or negedge sys_rst_n) begin

        if (!sys_rst_n)
            led <= 1'b1;

        // Pisca somente quando botão pressionado
        else if (!key && counter == MAX_COUNT)
            led <= ~led;

        // LED apagado quando botão solto
        else if (key)
            led <= 1'b1;

    end

endmodule