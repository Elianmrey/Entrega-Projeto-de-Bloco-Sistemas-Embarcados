// TP5 deterministic protocol, parser, buffer and statistics tests.
.include "common.inc"
.text
.align 2
.global _start

.extern tp5_build_frame
.extern tp5_validate_frame
.extern tp5_is_response_frame
.extern tp5_checksum
.extern tp5_validate_sequence
.extern tp5_reset_sequence
.extern tp5_parse_u64
.extern tp5_strnlen
.extern tp5_buffer_copy
.extern tp5_u64_to_buffer
.extern tp5_stats_reset
.extern tp5_stats_add
.extern tp5_elapsed_us
.extern tp5_average_ns

_start:
    // Frame with maximum payload: bounds and checksum.
    adrp    x0, frame
    add     x0, x0, :lo12:frame
    mov     w1, #TP5_CMD_SET_OUTPUT
    mov     w2, #0xFF
    mov     w3, #8
    adrp    x4, payload
    add     x4, x4, :lo12:payload
    bl      tp5_build_frame
    cmp     w1, #TP5_FRAME_SIZE
    b.ne    test_failed
    ldrb    w5, [x0, #TP5_OFF_SOF]
    cmp     w5, #TP5_SOF
    b.ne    test_failed
    ldrb    w5, [x0, #TP5_OFF_SEQUENCE]
    cmp     w5, #0xFF
    b.ne    test_failed
    ldrb    w5, [x0, #12]
    cmp     w5, #8
    b.ne    test_failed

    mov     x1, #TP5_FRAME_SIZE
    bl      tp5_validate_frame
    cbnz    w0, test_failed

    // O frame construído acima é comando, não resposta.
    adrp    x0, frame
    add     x0, x0, :lo12:frame
    mov     x1, #TP5_FRAME_SIZE
    bl      tp5_is_response_frame
    cbnz    w0, test_failed

    // Resposta LEGACY que antes contaminava a leitura deve ser reconhecida.
    adrp    x0, legacy_response
    add     x0, x0, :lo12:legacy_response
    mov     x1, #TP5_FRAME_SIZE
    bl      tp5_is_response_frame
    cmp     w0, #1
    b.ne    test_failed

    // Telemetria real iniciada por A5/01 continua sendo sensor, não resposta.
    adrp    x0, sensor_frame
    add     x0, x0, :lo12:sensor_frame
    mov     x1, #TP5_FRAME_SIZE
    bl      tp5_is_response_frame
    cbnz    w0, test_failed

    // CRC/checksum corruption.
    adrp    x1, frame
    add     x1, x1, :lo12:frame
    ldrb    w2, [x1, #6]
    eor     w2, w2, #1
    strb    w2, [x1, #6]
    mov     x0, x1
    mov     x1, #TP5_FRAME_SIZE
    bl      tp5_validate_frame
    cmp     w0, #TP5_ERR_CHECKSUM
    b.ne    test_failed

    // Truncated frame length.
    adrp    x0, frame
    add     x0, x0, :lo12:frame
    mov     x1, #13
    bl      tp5_validate_frame
    cmp     w0, #TP5_ERR_LENGTH
    b.ne    test_failed

    // Sequence wrap 255 -> 0, then duplicate rejection.
    bl      tp5_reset_sequence
    mov     w0, #0xFF
    bl      tp5_validate_sequence
    cbnz    w0, test_failed
    mov     w0, #0
    bl      tp5_validate_sequence
    cbnz    w0, test_failed
    mov     w0, #0
    bl      tp5_validate_sequence
    cmp     w0, #TP5_ERR_SEQUENCE
    b.ne    test_failed

    // Decimal parsing: zero, UINT64_MAX, invalid, empty and overflow.
    adrp    x0, str_zero
    add     x0, x0, :lo12:str_zero
    mov     x1, #1
    adrp    x2, parsed_value
    add     x2, x2, :lo12:parsed_value
    bl      tp5_parse_u64
    cbnz    w0, test_failed
    adrp    x2, parsed_value
    add     x2, x2, :lo12:parsed_value
    ldr     x3, [x2]
    cbnz    x3, test_failed

    adrp    x0, str_max
    add     x0, x0, :lo12:str_max
    mov     x1, #20
    adrp    x2, parsed_value
    add     x2, x2, :lo12:parsed_value
    bl      tp5_parse_u64
    cbnz    w0, test_failed
    adrp    x2, parsed_value
    add     x2, x2, :lo12:parsed_value
    ldr     x3, [x2]
    mov     x4, #-1
    cmp     x3, x4
    b.ne    test_failed

    adrp    x0, str_overflow
    add     x0, x0, :lo12:str_overflow
    mov     x1, #20
    adrp    x2, parsed_value
    add     x2, x2, :lo12:parsed_value
    bl      tp5_parse_u64
    cmp     w0, #-2
    b.ne    test_failed

    adrp    x0, str_invalid
    add     x0, x0, :lo12:str_invalid
    mov     x1, #3
    adrp    x2, parsed_value
    add     x2, x2, :lo12:parsed_value
    bl      tp5_parse_u64
    cmp     w0, #-1
    b.ne    test_failed

    adrp    x0, str_zero
    add     x0, x0, :lo12:str_zero
    mov     x1, #0
    adrp    x2, parsed_value
    add     x2, x2, :lo12:parsed_value
    bl      tp5_parse_u64
    cmp     w0, #-1
    b.ne    test_failed

    // Bounded string: terminator found and absent.
    adrp    x0, string_ok
    add     x0, x0, :lo12:string_ok
    mov     x1, #4
    bl      tp5_strnlen
    cmp     x0, #3
    b.ne    test_failed
    adrp    x0, string_no_nul
    add     x0, x0, :lo12:string_no_nul
    mov     x1, #3
    bl      tp5_strnlen
    cmp     x0, #-1
    b.ne    test_failed

    // Exact copy succeeds; oversized copy does not modify the guard.
    adrp    x0, copy_dst
    add     x0, x0, :lo12:copy_dst
    mov     x1, #8
    adrp    x2, payload
    add     x2, x2, :lo12:payload
    mov     x3, #8
    bl      tp5_buffer_copy
    cmp     x0, #8
    b.ne    test_failed
    adrp    x0, copy_dst
    add     x0, x0, :lo12:copy_dst
    ldrb    w1, [x0, #7]
    cmp     w1, #8
    b.ne    test_failed
    adrp    x0, guarded_dst
    add     x0, x0, :lo12:guarded_dst
    mov     x1, #4
    adrp    x2, payload
    add     x2, x2, :lo12:payload
    mov     x3, #8
    bl      tp5_buffer_copy
    cmp     x0, #-1
    b.ne    test_failed
    adrp    x0, guarded_dst
    add     x0, x0, :lo12:guarded_dst
    ldrb    w1, [x0]
    cmp     w1, #0xAA
    b.ne    test_failed

    // Number formatting at zero and UINT64_MAX.
    mov     x0, #0
    adrp    x1, number_buf
    add     x1, x1, :lo12:number_buf
    mov     x2, #32
    bl      tp5_u64_to_buffer
    cmp     x1, #1
    b.ne    test_failed
    ldrb    w2, [x0]
    cmp     w2, #'0'
    b.ne    test_failed
    mov     x0, #-1
    adrp    x1, number_buf
    add     x1, x1, :lo12:number_buf
    mov     x2, #32
    bl      tp5_u64_to_buffer
    cmp     x1, #20
    b.ne    test_failed

    // Capacidade insuficiente: retorna falha e preserva o sentinela.
    adrp    x3, number_buf
    add     x3, x3, :lo12:number_buf
    mov     w4, #0xAA
    strb    w4, [x3]
    mov     x0, #-1
    mov     x1, x3
    mov     x2, #1
    bl      tp5_u64_to_buffer
    cbnz    x0, test_failed
    cbnz    x1, test_failed
    adrp    x3, number_buf
    add     x3, x3, :lo12:number_buf
    ldrb    w4, [x3]
    cmp     w4, #0xAA
    b.ne    test_failed

    // Statistics: min=100, max=300, average=200, one failure.
    adrp    x0, stats
    add     x0, x0, :lo12:stats
    bl      tp5_stats_reset
    adrp    x0, stats
    add     x0, x0, :lo12:stats
    mov     x1, #100
    mov     w2, #1
    bl      tp5_stats_add
    adrp    x0, stats
    add     x0, x0, :lo12:stats
    mov     x1, #300
    mov     w2, #0
    bl      tp5_stats_add
    adrp    x0, stats
    add     x0, x0, :lo12:stats
    bl      tp5_average_ns
    cmp     x0, #200
    b.ne    test_failed
    adrp    x0, stats
    add     x0, x0, :lo12:stats
    ldr     x1, [x0, #8]
    cmp     x1, #1
    b.ne    test_failed
    ldr     x1, [x0, #24]
    cmp     x1, #100
    b.ne    test_failed
    ldr     x1, [x0, #32]
    cmp     x1, #300
    b.ne    test_failed

    // Clock delta conversion and underflow guard.
    mov     x0, #1000
    mov     x1, #6500
    bl      tp5_elapsed_us
    cmp     x0, #5
    b.ne    test_failed
    mov     x0, #7000
    mov     x1, #6500
    bl      tp5_elapsed_us
    cbnz    x0, test_failed

    mov     x0, #0
    mov     x8, #SYS_exit
    svc     #0

test_failed:
    mov     x0, #1
    mov     x8, #SYS_exit
    svc     #0

.section .rodata
payload:
    .byte 1,2,3,4,5,6,7,8
str_zero:
    .ascii "0"
str_max:
    .ascii "18446744073709551615"
str_overflow:
    .ascii "18446744073709551616"
str_invalid:
    .ascii "12x"
string_ok:
    .asciz "abc"
string_no_nul:
    .ascii "xyz"
legacy_response:
    .byte 0xA5,0x01,0x83,0x00,0x02,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x25
sensor_frame:
    .byte 0xA5,0x01,0x23,0x04,0x56,0x32,0x00,0x77,0x02,0x00,0x00,0x01,0x8B,0xCD

.data
guarded_dst:
    .byte 0xAA,0xAA,0xAA,0xAA

.bss
.align 3
frame:
    .skip TP5_FRAME_SIZE
parsed_value:
    .skip 8
copy_dst:
    .skip 8
number_buf:
    .skip 32
stats:
    .skip 40
