// TP5 exchange integration test with deterministic spidev stubs.
.include "common.inc"
.text
.align 2
.global _start
.global spi_read_frame
.global spi_open
.global spi_configure
.global clock_monotonic_ns
.global print_u32
.global write_str
.global active_spi_fd
.global tx_dummy

.extern tp5_exchange
.extern tp5_build_frame

_start:
    mov     x0, #3
    mov     w1, #TP5_CMD_SET_OUTPUT
    mov     w2, #7
    mov     w3, #5
    adrp    x4, test_response
    add     x4, x4, :lo12:test_response
    bl      tp5_exchange
    cbnz    w0, test_failed

    adrp    x1, test_response
    add     x1, x1, :lo12:test_response
    ldrb    w2, [x1, #TP5_OFF_COMMAND]
    cmp     w2, #TP5_RSP_ACK
    b.ne    test_failed
    ldrb    w2, [x1, #TP5_OFF_SEQUENCE]
    cmp     w2, #7
    b.ne    test_failed
    ldrb    w2, [x1, #TP5_OFF_PAYLOAD]
    cmp     w2, #TP5_CMD_SET_OUTPUT
    b.ne    test_failed
    adrp    x1, stub_calls
    add     x1, x1, :lo12:stub_calls
    ldr     w2, [x1]
    cmp     w2, #2
    b.ne    test_failed

    // ACK estruturalmente valido, mas de outro comando, deve ser rejeitado.
    adrp    x1, stub_calls
    add     x1, x1, :lo12:stub_calls
    str     wzr, [x1]
    adrp    x1, stub_mode
    add     x1, x1, :lo12:stub_mode
    mov     w2, #1
    str     w2, [x1]
    adrp    x1, expected_seq
    add     x1, x1, :lo12:expected_seq
    mov     w2, #8
    str     w2, [x1]
    mov     x0, #3
    mov     w1, #TP5_CMD_SET_OUTPUT
    mov     w2, #8
    mov     w3, #5
    adrp    x4, test_response
    add     x4, x4, :lo12:test_response
    bl      tp5_exchange
    cmp     w0, #TP5_ERR_UNKNOWN_COMMAND
    b.ne    test_failed

    // ACK sem payload nao pode ser aceito como sucesso.
    adrp    x1, stub_calls
    add     x1, x1, :lo12:stub_calls
    str     wzr, [x1]
    adrp    x1, stub_mode
    add     x1, x1, :lo12:stub_mode
    mov     w2, #2
    str     w2, [x1]
    adrp    x1, expected_seq
    add     x1, x1, :lo12:expected_seq
    mov     w2, #9
    str     w2, [x1]
    mov     x0, #3
    mov     w1, #TP5_CMD_SET_OUTPUT
    mov     w2, #9
    mov     w3, #5
    adrp    x4, test_response
    add     x4, x4, :lo12:test_response
    bl      tp5_exchange
    cmp     w0, #TP5_ERR_LENGTH
    b.ne    test_failed

    mov     x0, #0
    mov     x8, #SYS_exit
    svc     #0

test_failed:
    mov     x0, #1
    mov     x8, #SYS_exit
    svc     #0

// spi_read_frame(x0=fd, x1=rx). First call validates TX, second returns ACK.
spi_read_frame:
    stp     x29, x30, [sp, #-48]!
    stp     x19, x20, [sp, #16]
    str     x21, [sp, #32]
    mov     x29, sp
    mov     x19, x1
    adrp    x20, stub_calls
    add     x20, x20, :lo12:stub_calls
    ldr     w21, [x20]
    add     w21, w21, #1
    str     w21, [x20]
    cmp     w21, #1
    b.ne    stub_second

    adrp    x2, tx_dummy
    add     x2, x2, :lo12:tx_dummy
    ldrb    w3, [x2, #TP5_OFF_SOF]
    cmp     w3, #TP5_SOF
    b.ne    stub_fail
    ldrb    w3, [x2, #TP5_OFF_COMMAND]
    cmp     w3, #TP5_CMD_SET_OUTPUT
    b.ne    stub_fail
    ldrb    w3, [x2, #TP5_OFF_SEQUENCE]
    adrp    x4, expected_seq
    add     x4, x4, :lo12:expected_seq
    ldr     w4, [x4]
    cmp     w3, w4
    b.ne    stub_fail
    ldrb    w3, [x2, #TP5_OFF_LENGTH]
    cmp     w3, #1
    b.ne    stub_fail
    ldrb    w3, [x2, #TP5_OFF_PAYLOAD]
    cmp     w3, #5
    b.ne    stub_fail
    mov     x0, #0
    b       stub_done

stub_second:
    // The second transfer must be neutral and receives the queued ACK.
    adrp    x2, tx_dummy
    add     x2, x2, :lo12:tx_dummy
    mov     x3, #TP5_FRAME_SIZE
stub_zero_check:
    ldrb    w4, [x2], #1
    cbnz    w4, stub_fail
    subs    x3, x3, #1
    b.ne    stub_zero_check

    adrp    x5, stub_mode
    add     x5, x5, :lo12:stub_mode
    ldr     w5, [x5]
    cmp     w5, #2
    b.eq    stub_zero_length
    cmp     w5, #1
    b.eq    stub_wrong_command
    adrp    x4, ack_payload
    add     x4, x4, :lo12:ack_payload
    b       stub_build_ack
stub_wrong_command:
    adrp    x4, bad_ack_payload
    add     x4, x4, :lo12:bad_ack_payload
stub_build_ack:
    mov     x0, x19
    mov     w1, #TP5_RSP_ACK
    adrp    x6, expected_seq
    add     x6, x6, :lo12:expected_seq
    ldr     w2, [x6]
    mov     w3, #1
    bl      tp5_build_frame
    mov     x0, #0
    b       stub_done
stub_zero_length:
    mov     x0, x19
    mov     w1, #TP5_RSP_ACK
    adrp    x6, expected_seq
    add     x6, x6, :lo12:expected_seq
    ldr     w2, [x6]
    mov     w3, #0
    mov     x4, #0
    bl      tp5_build_frame
    mov     x0, #0
    b       stub_done
stub_fail:
    mov     x0, #-5
stub_done:
    ldr     x21, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #48
    ret

spi_open:
    mov     x0, #-1
    ret
spi_configure:
    mov     x0, #0
    ret
clock_monotonic_ns:
    mov     x0, #0
    ret
print_u32:
    ret
write_str:
    ret

.section .rodata
ack_payload:
    .byte TP5_CMD_SET_OUTPUT
bad_ack_payload:
    .byte TP5_CMD_PING

.data
.align 3
active_spi_fd:
    .quad -1
stub_mode:
    .word 0
expected_seq:
    .word 7

.bss
.align 3
tx_dummy:
    .skip TP5_FRAME_SIZE
test_response:
    .skip TP5_FRAME_SIZE
stub_calls:
    .skip 4
