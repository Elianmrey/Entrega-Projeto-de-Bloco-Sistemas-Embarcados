// TP5 numeric edge tests for integer, Q16.16 and floating-point conversion.
.include "common.inc"
.text
.align 2
.global _start

.extern uint128_add
.extern uint128_sub
.extern uint64_mul_128
.extern uint64_to_double
.extern double_to_uint64
.extern q16_16_mul
.extern q16_16_mul_sat
.extern lookup_value

_start:
    // Unsigned minimum and carry at maximum.
    mov     x0, #0
    mov     x1, #0
    mov     x2, #0
    mov     x3, #0
    bl      uint128_add
    orr     x4, x0, x1
    cbnz    x4, test_failed

    mov     x0, #-1
    mov     x1, #-1
    mov     x2, #1
    mov     x3, #0
    bl      uint128_add
    cbnz    x0, test_failed
    cbnz    x1, test_failed

    // 64-bit maximum times two -> high=1, low=...FFFE.
    mov     x0, #-1
    mov     x1, #2
    bl      uint64_mul_128
    mov     x4, #-2
    cmp     x0, x4
    b.ne    test_failed
    cmp     x1, #1
    b.ne    test_failed

    // Existing Q16.16: zero and signed multiplication.
    mov     x0, #0
    mov     x1, #131072
    bl      q16_16_mul
    cbnz    x0, test_failed
    ldr     x0, =-98304
    mov     x1, #131072
    bl      q16_16_mul
    ldr     x4, =-196608
    cmp     x0, x4
    b.ne    test_failed

    // Saturating Q16.16: positive, negative, maximum and minimum.
    mov     w0, #98304
    mov     w1, #131072
    bl      q16_16_mul_sat
    mov     x4, #196608
    cmp     x0, x4
    b.ne    test_failed
    ldr     w0, =-98304
    mov     w1, #131072
    bl      q16_16_mul_sat
    ldr     x4, =-196608
    cmp     x0, x4
    b.ne    test_failed
    ldr     w0, =2147483647
    mov     w1, #131072
    bl      q16_16_mul_sat
    ldr     x4, =2147483647
    cmp     x0, x4
    b.ne    test_failed
    ldr     w0, =-2147483648
    mov     w1, #131072
    bl      q16_16_mul_sat
    ldr     x4, =-2147483648
    cmp     x0, x4
    b.ne    test_failed

    // Lookup lower/upper boundary and out of range.
    mov     x0, #0
    bl      lookup_value
    cmp     x0, #256
    b.ne    test_failed
    mov     x0, #15
    bl      lookup_value
    cmp     x0, #640
    b.ne    test_failed
    mov     x0, #16
    bl      lookup_value
    cbnz    x0, test_failed

    // Floating conversion: exact integer and documented truncation.
    mov     x0, #42
    bl      uint64_to_double
    adrp    x1, double_42
    add     x1, x1, :lo12:double_42
    ldr     d1, [x1]
    fcmp    d0, d1
    b.ne    test_failed
    adrp    x1, double_42_75
    add     x1, x1, :lo12:double_42_75
    ldr     d0, [x1]
    bl      double_to_uint64
    cmp     x0, #42
    b.ne    test_failed

    mov     x0, #0
    mov     x8, #SYS_exit
    svc     #0

test_failed:
    mov     x0, #1
    mov     x8, #SYS_exit
    svc     #0

.section .rodata
.align 3
double_42:
    .double 42.0
double_42_75:
    .double 42.75
