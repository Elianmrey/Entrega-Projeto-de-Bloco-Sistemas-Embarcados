// Integration test for protocol-based sensor acquisition with deterministic SPI stubs.
.include "common.inc"
.text
.align 2
.global _start
.global spi_read_frame
.global spi_open
.global spi_configure
.global clock_monotonic_ns
.global print_u32
.global write_str
.global active_spi_fd
.global tx_dummy

.extern tp5_read_sensor_frame
.extern tp5_build_frame

_start:
    mov     x0, #3
    adrp    x1, sensor_frame
    add     x1, x1, :lo12:sensor_frame
    bl      tp5_read_sensor_frame
    cbnz    w0, test_failed

    adrp    x0, sensor_frame
    add     x0, x0, :lo12:sensor_frame
    adrp    x1, expected_frame
    add     x1, x1, :lo12:expected_frame
    mov     x2, #TP5_FRAME_SIZE
compare_loop:
    ldrb    w3, [x0], #1
    ldrb    w4, [x1], #1
    cmp     w3, w4
    b.ne    test_failed
    subs    x2, x2, #1
    b.ne    compare_loop

    adrp    x0, stub_calls
    add     x0, x0, :lo12:stub_calls
    ldr     w1, [x0]
    cmp     w1, #6
    b.ne    test_failed

    mov     x0, #0
    mov     x8, #SYS_exit
    svc     #0

test_failed:
    mov     x0, #1
    mov     x8, #SYS_exit
    svc     #0

// Every TP5 exchange has one command transfer and one neutral response transfer.
spi_read_frame:
    stp     x29, x30, [sp, #-48]!
    stp     x19, x20, [sp, #16]
    str     x21, [sp, #32]
    mov     x29, sp
    mov     x19, x1

    adrp    x20, stub_calls
    add     x20, x20, :lo12:stub_calls
    ldr     w21, [x20]
    add     w21, w21, #1
    str     w21, [x20]
    tst     w21, #1
    b.eq    stub_response_transfer

    // Command transfer: capture command/sequence and verify order.
    adrp    x2, tx_dummy
    add     x2, x2, :lo12:tx_dummy
    ldrb    w3, [x2, #TP5_OFF_COMMAND]
    ldrb    w4, [x2, #TP5_OFF_SEQUENCE]
    adrp    x5, last_command
    add     x5, x5, :lo12:last_command
    strb    w3, [x5]
    adrp    x5, last_sequence
    add     x5, x5, :lo12:last_sequence
    strb    w4, [x5]

    cmp     w21, #1
    b.ne    check_read_command
    cmp     w3, #TP5_CMD_RESET_STATE
    b.ne    stub_fail
    cbnz    w4, stub_fail
    b       stub_success
check_read_command:
    cmp     w21, #3
    b.ne    check_telemetry_command
    cmp     w3, #TP5_CMD_READ_SENSORS
    b.ne    stub_fail
    cbnz    w4, stub_fail
    b       stub_success
check_telemetry_command:
    cmp     w21, #5
    b.ne    stub_fail
    cmp     w3, #TP5_CMD_GET_TELEMETRY
    b.ne    stub_fail
    cmp     w4, #1
    b.ne    stub_fail
stub_success:
    mov     x0, #0
    b       stub_done

stub_response_transfer:
    adrp    x5, last_command
    add     x5, x5, :lo12:last_command
    ldrb    w6, [x5]
    cmp     w6, #TP5_CMD_RESET_STATE
    b.eq    use_reset_payload
    cmp     w6, #TP5_CMD_READ_SENSORS
    b.eq    use_sensor_payload
    cmp     w6, #TP5_CMD_GET_TELEMETRY
    b.ne    stub_fail
    adrp    x4, telemetry_payload
    add     x4, x4, :lo12:telemetry_payload
    b       build_response
use_reset_payload:
    adrp    x4, reset_payload
    add     x4, x4, :lo12:reset_payload
    b       build_response
use_sensor_payload:
    adrp    x4, sensor_payload
    add     x4, x4, :lo12:sensor_payload
build_response:
    mov     x0, x19
    mov     w1, #TP5_RSP_ACK
    adrp    x5, last_sequence
    add     x5, x5, :lo12:last_sequence
    ldrb    w2, [x5]
    mov     w3, #8
    bl      tp5_build_frame
    mov     x0, #0
    b       stub_done
stub_fail:
    mov     x0, #-5
stub_done:
    ldr     x21, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #48
    ret

spi_open:
    mov     x0, #-1
    ret
spi_configure:
    mov     x0, #0
    ret
clock_monotonic_ns:
    mov     x0, #0
    ret
print_u32:
    ret
write_str:
    ret

.section .rodata
reset_payload:
    .byte TP5_CMD_RESET_STATE,0,0,0,0,0,0,0
sensor_payload:
    .byte TP5_CMD_READ_SENSORS,0x01,0x23,0x04,0x56,0x32,0x00,0x77
telemetry_payload:
    .byte TP5_CMD_GET_TELEMETRY,0x00,0x01,0x8B,0xCD,0x02,0x00,0xAA
expected_frame:
    .byte 0xA5,0x01,0x23,0x04,0x56,0x32,0x00,0x77,0x02,0x00,0x00,0x01,0x8B,0xCD

.data
.align 3
active_spi_fd:
    .quad -1
last_command:
    .byte 0
last_sequence:
    .byte 0

.bss
.align 3
tx_dummy:
    .skip TP5_FRAME_SIZE
sensor_frame:
    .skip TP5_FRAME_SIZE
stub_calls:
    .skip 4
