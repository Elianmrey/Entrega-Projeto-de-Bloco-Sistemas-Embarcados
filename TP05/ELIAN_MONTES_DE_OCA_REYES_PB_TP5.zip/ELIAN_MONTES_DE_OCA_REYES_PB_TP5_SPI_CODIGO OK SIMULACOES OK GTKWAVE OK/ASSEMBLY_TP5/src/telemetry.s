// TP5 ARM64 protocol client using the existing spidev descriptor.
.include "common.inc"
.include "tp5_macros.inc"
.text
.align 2

.extern spi_open
.extern spi_configure
.extern spi_read_frame
.extern clock_monotonic_ns
.extern tp5_build_frame
.extern tp5_validate_frame
.extern tp5_stats_reset
.extern tp5_stats_add
.extern tp5_average_ns
.extern tp5_write_all
.extern print_u32
.extern write_str
.extern active_spi_fd

.global tp5_exchange
.global tp5_read_sensor_frame
.global tp5_stability_mode
.global tp5_log_csv_header
.global tp5_log_csv_row

// tp5_exchange(x0=fd, w1=command, w2=sequence, w3=payload0,
//              x4=response buffer) -> w0=0 success, negative local/I/O error,
//              positive TP5_ERR_* validation error.
.type tp5_exchange, %function
tp5_exchange:
    stp     x29, x30, [sp, #-80]!
    stp     x19, x20, [sp, #16]
    stp     x21, x22, [sp, #32]
    stp     x23, x24, [sp, #48]
    mov     x29, sp
    mov     x19, x0
    mov     w20, w1
    mov     w21, w2
    mov     w22, w3
    mov     x23, x4

    TP5_GLOBAL_ADDR x0, tp5_tx_frame
    mov     w1, w20
    mov     w2, w21
    cmp     w20, #TP5_CMD_SET_OUTPUT
    b.eq    1f
    cmp     w20, #TP5_CMD_CONTROL_MOTOR
    b.eq    1f
    mov     w3, #0
    mov     x4, #0
    b       2f
1:
    mov     w3, #1
    add     x4, sp, #64
    strb    w22, [x4]
2:
    bl      tp5_build_frame

    // Reuse the validated TP4 spi_ioc_transfer path: temporarily point tx_buf
    // to the TP5 command and receive the simultaneously shifted response.
    TP5_GLOBAL_ADDR x0, tp5_tx_frame
    TP5_GLOBAL_ADDR x1, tx_dummy
    mov     x2, #TP5_FRAME_SIZE
3:
    ldrb    w3, [x0], #1
    strb    w3, [x1], #1
    subs    x2, x2, #1
    b.ne    3b

    mov     x0, x19
    mov     x1, x23
    bl      spi_read_frame
    cmp     x0, #0
    b.lt    5f

    // A SPI e full-duplex: a resposta ao comando fica disponivel somente
    // depois da primeira transferencia. Uma segunda transferencia neutra
    // busca essa resposta; o frame neutro e tratado como legado no FPGA.
    TP5_GLOBAL_ADDR x0, tx_dummy
    mov     x1, #TP5_FRAME_SIZE
4:
    strb    wzr, [x0], #1
    subs    x1, x1, #1
    b.ne    4b
    mov     x0, x19
    mov     x1, x23
    bl      spi_read_frame
    cmp     x0, #0
    b.lt    5f

    mov     x0, x23
    mov     x1, #TP5_FRAME_SIZE
    bl      tp5_validate_frame
    cbnz    w0, 5f
    ldrb    w1, [x23, #TP5_OFF_SEQUENCE]
    cmp     w1, w21
    b.ne    6f
    ldrb    w2, [x23, #TP5_OFF_LENGTH]
    cbz     w2, 7f
    ldrb    w1, [x23, #TP5_OFF_COMMAND]
    cmp     w1, #TP5_RSP_ACK
    b.ne    8f
    ldrb    w2, [x23, #TP5_OFF_PAYLOAD]
    cmp     w2, w20
    b.ne    9f
    mov     w0, #TP5_ERR_NONE
    b       5f
    // NACK/BUSY carregam o codigo de erro no primeiro byte do payload.
8:
    cmp     w1, #TP5_RSP_NACK
    b.eq    10f
    cmp     w1, #TP5_RSP_BUSY
    b.ne    9f
10:
    ldrb    w0, [x23, #TP5_OFF_PAYLOAD]
    cbnz    w0, 5f
    mov     w0, #TP5_ERR_UNKNOWN_COMMAND
    b       5f
6:
    mov     w0, #TP5_ERR_SEQUENCE
    b       5f
7:
    mov     w0, #TP5_ERR_LENGTH
    b       5f
9:
    mov     w0, #TP5_ERR_UNKNOWN_COMMAND
5:
    ldp     x23, x24, [sp, #48]
    ldp     x21, x22, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #80
    ret
.size tp5_exchange, .-tp5_exchange

// tp5_read_sensor_frame(x0=fd, x1=legacy destination[14]) -> w0=0/-1.
// Requests the complete sensor snapshot through two validated TP5 commands and
// reconstructs the legacy byte layout consumed by capture_all_sensors.
.type tp5_read_sensor_frame, %function
tp5_read_sensor_frame:
    stp     x29, x30, [sp, #-80]!
    stp     x19, x20, [sp, #16]
    stp     x21, x22, [sp, #32]
    stp     x23, x24, [sp, #48]
    mov     x29, sp
    mov     x19, x0
    mov     x20, x1
    TP5_GLOBAL_ADDR x21, tp5_sensor_synced
    TP5_GLOBAL_ADDR x22, tp5_sensor_sequence

    ldrb    w0, [x21]
    cbnz    w0, tp5_sensor_read_values

    // RESET_STATE is accepted independently of the FPGA's previous sequence.
    mov     x0, x19
    mov     w1, #TP5_CMD_RESET_STATE
    mov     w2, #0
    mov     w3, #0
    TP5_GLOBAL_ADDR x4, tp5_sensor_response_a
    bl      tp5_exchange
    cbnz    w0, tp5_sensor_read_failed
    mov     w0, #1
    strb    w0, [x21]
    strb    wzr, [x22]

tp5_sensor_read_values:
    // Temperatures, percentage and LM35 raw ADC.
    ldrb    w2, [x22]
    mov     x0, x19
    mov     w1, #TP5_CMD_READ_SENSORS
    mov     w3, #0
    TP5_GLOBAL_ADDR x4, tp5_sensor_response_a
    bl      tp5_exchange
    cbnz    w0, tp5_sensor_read_failed
    ldrb    w0, [x22]
    add     w0, w0, #1
    strb    w0, [x22]

    // Pressure and potentiometer raw ADC.
    mov     w2, w0
    mov     x0, x19
    mov     w1, #TP5_CMD_GET_TELEMETRY
    mov     w3, #0
    TP5_GLOBAL_ADDR x4, tp5_sensor_response_b
    bl      tp5_exchange
    cbnz    w0, tp5_sensor_read_failed
    ldrb    w0, [x22]
    add     w0, w0, #1
    strb    w0, [x22]

    // Legacy frame: A5, BMP temp, LM35 temp, pot %, LM35 raw, pot raw, pressure.
    mov     w0, #TP5_SOF
    strb    w0, [x20, #0]
    TP5_GLOBAL_ADDR x23, tp5_sensor_response_a
    ldrb    w0, [x23, #(TP5_OFF_PAYLOAD + 1)]
    strb    w0, [x20, #1]
    ldrb    w0, [x23, #(TP5_OFF_PAYLOAD + 2)]
    strb    w0, [x20, #2]
    ldrb    w0, [x23, #(TP5_OFF_PAYLOAD + 3)]
    strb    w0, [x20, #3]
    ldrb    w0, [x23, #(TP5_OFF_PAYLOAD + 4)]
    strb    w0, [x20, #4]
    ldrb    w0, [x23, #(TP5_OFF_PAYLOAD + 5)]
    strb    w0, [x20, #5]
    ldrb    w0, [x23, #(TP5_OFF_PAYLOAD + 6)]
    strb    w0, [x20, #6]
    ldrb    w0, [x23, #(TP5_OFF_PAYLOAD + 7)]
    strb    w0, [x20, #7]

    TP5_GLOBAL_ADDR x24, tp5_sensor_response_b
    ldrb    w0, [x24, #(TP5_OFF_PAYLOAD + 5)]
    strb    w0, [x20, #8]
    ldrb    w0, [x24, #(TP5_OFF_PAYLOAD + 6)]
    strb    w0, [x20, #9]
    ldrb    w0, [x24, #(TP5_OFF_PAYLOAD + 1)]
    strb    w0, [x20, #10]
    ldrb    w0, [x24, #(TP5_OFF_PAYLOAD + 2)]
    strb    w0, [x20, #11]
    ldrb    w0, [x24, #(TP5_OFF_PAYLOAD + 3)]
    strb    w0, [x20, #12]
    ldrb    w0, [x24, #(TP5_OFF_PAYLOAD + 4)]
    strb    w0, [x20, #13]
    mov     w0, #0
    b       tp5_sensor_read_done

tp5_sensor_read_failed:
    strb    wzr, [x21]
    mov     w0, #-1
tp5_sensor_read_done:
    ldp     x23, x24, [sp, #48]
    ldp     x21, x22, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #80
    ret
.size tp5_read_sensor_frame, .-tp5_read_sensor_frame

// tp5_stability_mode(x0=transaction count) -> w0=0 or -1.
// Numbers are real only when this routine is executed against actual hardware.
.type tp5_stability_mode, %function
tp5_stability_mode:
    stp     x29, x30, [sp, #-96]!
    stp     x19, x20, [sp, #16]
    stp     x21, x22, [sp, #32]
    stp     x23, x24, [sp, #48]
    stp     x25, x26, [sp, #64]
    mov     x29, sp
    mov     x19, x0
    cbnz    x19, 1f
    mov     x19, #100
1:
    bl      spi_open
    cmp     x0, #0
    b.lt    9f
    mov     x20, x0
    TP5_GLOBAL_ADDR x1, active_spi_fd
    str     x20, [x1]
    mov     x0, x20
    bl      spi_configure
    cmp     x0, #0
    b.lt    9f

    TP5_GLOBAL_ADDR x0, tp5_stats
    bl      tp5_stats_reset
    bl      tp5_log_csv_header

    // Reset is deliberately accepted independent of the previous sequence.
    mov     x0, x20
    mov     w1, #TP5_CMD_RESET_STATE
    mov     w2, #0
    mov     w3, #0
    TP5_GLOBAL_ADDR x4, tp5_rx_frame
    bl      tp5_exchange
    cbnz    w0, 9f

    mov     x21, #0
2:
    cmp     x21, x19
    b.hs    7f
    bl      clock_monotonic_ns
    cmp     x0, #0
    b.lt    6f
    mov     x22, x0

    mov     x0, x20
    mov     w1, #TP5_CMD_PING
    and     w2, w21, #0xff
    mov     w3, #0
    TP5_GLOBAL_ADDR x4, tp5_rx_frame
    bl      tp5_exchange
    mov     w23, w0
    mov     w3, #0xff
    cmp     w23, #0
    b.lt    13f
    TP5_GLOBAL_ADDR x6, tp5_rx_frame
    ldrb    w3, [x6, #TP5_OFF_COMMAND]
13:
    strb    w3, [sp, #80]

    bl      clock_monotonic_ns
    cmp     x0, #0
    b.lt    6f
    mov     x25, x0
    sub     x24, x0, x22
    cmp     w23, #0
    cset    w2, eq
    TP5_GLOBAL_ADDR x0, tp5_stats
    mov     x1, x24
    bl      tp5_stats_add

    mov     x0, x25
    and     w1, w21, #0xff
    mov     w2, #TP5_CMD_PING
    ldrb    w3, [sp, #80]
    mov     x4, x24
    mov     w5, w23
    bl      tp5_log_csv_row
    b       8f
6:
    mov     w23, #-1
    TP5_GLOBAL_ADDR x0, tp5_stats
    mov     x1, #0
    mov     w2, #0
    bl      tp5_stats_add
8:
    add     x21, x21, #1
    b       2b
7:
    TP5_GLOBAL_ADDR x0, tp5_summary_begin
    mov     x1, #tp5_summary_begin_end-tp5_summary_begin
    bl      write_str
    mov     w0, w19
    bl      print_u32
    TP5_GLOBAL_ADDR x0, tp5_summary_average
    mov     x1, #tp5_summary_average_end-tp5_summary_average
    bl      write_str
    TP5_GLOBAL_ADDR x0, tp5_stats
    bl      tp5_average_ns
    mov     w0, w0
    bl      print_u32
    TP5_GLOBAL_ADDR x0, tp5_summary_minimum
    mov     x1, #tp5_summary_minimum_end-tp5_summary_minimum
    bl      write_str
    TP5_GLOBAL_ADDR x1, tp5_stats
    ldr     w0, [x1, #24]
    bl      print_u32
    TP5_GLOBAL_ADDR x0, tp5_summary_maximum
    mov     x1, #tp5_summary_maximum_end-tp5_summary_maximum
    bl      write_str
    TP5_GLOBAL_ADDR x1, tp5_stats
    ldr     w0, [x1, #32]
    bl      print_u32
    TP5_GLOBAL_ADDR x0, tp5_summary_failures
    mov     x1, #tp5_summary_failures_end-tp5_summary_failures
    bl      write_str
    TP5_GLOBAL_ADDR x1, tp5_stats
    ldr     w0, [x1, #8]
    mov     w26, w0
    bl      print_u32
    TP5_GLOBAL_ADDR x0, tp5_summary_throughput
    mov     x1, #tp5_summary_throughput_end-tp5_summary_throughput
    bl      write_str
    TP5_GLOBAL_ADDR x1, tp5_stats
    ldr     x2, [x1, #0]
    ldr     x3, [x1, #16]
    cbz     x3, tp5_summary_zero_time
    ldr     x4, =1000000000
    mul     x2, x2, x4
    udiv    x0, x2, x3
    b       tp5_summary_print_throughput
tp5_summary_zero_time:
    mov     x0, #0
tp5_summary_print_throughput:
    mov     w0, w0
    bl      print_u32
    TP5_GLOBAL_ADDR x0, tp5_summary_end
    mov     x1, #tp5_summary_end_end-tp5_summary_end
    bl      write_str
    cmp     w26, #0
    cset    w0, ne
    neg     w0, w0
    b       10f
9:
    mov     w0, #-1
10:
    ldp     x25, x26, [sp, #64]
    ldp     x23, x24, [sp, #48]
    ldp     x21, x22, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #96
    ret
.size tp5_stability_mode, .-tp5_stability_mode

// CSV header written to stderr.
.type tp5_log_csv_header, %function
tp5_log_csv_header:
    mov     x0, #2
    TP5_GLOBAL_ADDR x1, tp5_csv_header
    mov     x2, #tp5_csv_header_end-tp5_csv_header
    b       tp5_write_all
.size tp5_log_csv_header, .-tp5_log_csv_header

// tp5_log_csv_row(x0=timestamp_ns, w1=seq, w2=command, w3=success,
//                 x4=latency_ns, w5=error).
// Compact fixed-width hexadecimal fields keep the logger bounded and freestanding.
.type tp5_log_csv_row, %function
tp5_log_csv_row:
    TP5_GLOBAL_ADDR x6, tp5_csv_row
    // Template: timestamp(16),seq(2),command(2),status(2),latency(16),error(8).
    mov     x7, x0
    add     x8, x6, #15
    mov     x9, #16
1:
    and     w10, w7, #0xf
    cmp     w10, #9
    add     w11, w10, #'0'
    add     w12, w10, #('A'-10)
    csel    w10, w11, w12, ls
    strb    w10, [x8], #-1
    lsr     x7, x7, #4
    subs    x9, x9, #1
    b.ne    1b

    uxtw    x7, w1
    add     x8, x6, #18
    mov     x9, #2
2:
    and     w10, w7, #0xf
    cmp     w10, #9
    add     w11, w10, #'0'
    add     w12, w10, #('A'-10)
    csel    w10, w11, w12, ls
    strb    w10, [x8], #-1
    lsr     x7, x7, #4
    subs    x9, x9, #1
    b.ne    2b

    uxtw    x7, w2
    add     x8, x6, #21
    mov     x9, #2
3:
    and     w10, w7, #0xf
    cmp     w10, #9
    add     w11, w10, #'0'
    add     w12, w10, #('A'-10)
    csel    w10, w11, w12, ls
    strb    w10, [x8], #-1
    lsr     x7, x7, #4
    subs    x9, x9, #1
    b.ne    3b

    uxtw    x7, w3
    add     x8, x6, #24
    mov     x9, #2
4:
    and     w10, w7, #0xf
    cmp     w10, #9
    add     w11, w10, #'0'
    add     w12, w10, #('A'-10)
    csel    w10, w11, w12, ls
    strb    w10, [x8], #-1
    lsr     x7, x7, #4
    subs    x9, x9, #1
    b.ne    4b

    mov     x7, x4
    add     x8, x6, #41
    mov     x9, #16
6:
    and     w10, w7, #0xf
    cmp     w10, #9
    add     w11, w10, #'0'
    add     w12, w10, #('A'-10)
    csel    w10, w11, w12, ls
    strb    w10, [x8], #-1
    lsr     x7, x7, #4
    subs    x9, x9, #1
    b.ne    6b

    uxtw    x7, w5
    add     x8, x6, #50
    mov     x9, #8
7:
    and     w10, w7, #0xf
    cmp     w10, #9
    add     w11, w10, #'0'
    add     w12, w10, #('A'-10)
    csel    w10, w11, w12, ls
    strb    w10, [x8], #-1
    lsr     x7, x7, #4
    subs    x9, x9, #1
    b.ne    7b

    mov     x0, #2
    mov     x1, x6
    mov     x2, #52
    b       tp5_write_all
.size tp5_log_csv_row, .-tp5_log_csv_row

.section .rodata
.align 3
tp5_csv_header:
    .ascii "timestamp_ns,seq,command,status,response_time_ns,error\n"
tp5_csv_header_end:
tp5_summary_begin:
    .ascii "TP5 TEST END\nTransactions: "
tp5_summary_begin_end:
tp5_summary_average:
    .ascii "\nAverage response (ns): "
tp5_summary_average_end:
tp5_summary_minimum:
    .ascii "\nMinimum response (ns): "
tp5_summary_minimum_end:
tp5_summary_maximum:
    .ascii "\nMaximum response (ns): "
tp5_summary_maximum_end:
tp5_summary_failures:
    .ascii "\nFailures: "
tp5_summary_failures_end:
tp5_summary_throughput:
    .ascii "\nThroughput (transactions/s): "
tp5_summary_throughput_end:
tp5_summary_end:
    .ascii "\n"
tp5_summary_end_end:

.data
.align 3
tp5_csv_row:
    .ascii "0000000000000000,00,00,00,0000000000000000,00000000\n"

.bss
.align 3
tp5_tx_frame:
    .skip TP5_FRAME_SIZE
tp5_rx_frame:
    .skip TP5_FRAME_SIZE
tp5_stats:
    .skip 40
tp5_sensor_synced:
    .skip 1
tp5_sensor_sequence:
    .skip 1
.align 3
tp5_sensor_response_a:
    .skip TP5_FRAME_SIZE
tp5_sensor_response_b:
    .skip TP5_FRAME_SIZE
