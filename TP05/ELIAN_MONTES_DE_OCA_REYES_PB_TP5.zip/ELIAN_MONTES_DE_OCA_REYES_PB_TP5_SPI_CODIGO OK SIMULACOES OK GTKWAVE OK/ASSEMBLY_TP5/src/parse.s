// TP5 bounded parsing and buffer utilities.
.include "tp5_macros.inc"
.text
.align 2

.global tp5_parse_u64
.global tp5_strnlen
.global tp5_buffer_copy
.global tp5_u64_to_buffer

// tp5_parse_u64(x0=text, x1=length, x2=out_u64) -> w0:
// 0 success, -1 empty/invalid character, -2 overflow.
.type tp5_parse_u64, %function
tp5_parse_u64:
    cbz     x1, 4f
    mov     x3, #0
    mov     x4, #0
    mov     x7, #10
1:
    cmp     x4, x1
    b.hs    3f
    ldrb    w5, [x0, x4]
    cmp     w5, #'0'
    b.lo    4f
    cmp     w5, #'9'
    b.hi    4f
    sub     w5, w5, #'0'

    // MAX_UINT64 / 10 = 1844674407370955161; remainder = 5.
    ldr     x6, =1844674407370955161
    cmp     x3, x6
    b.hi    5f
    b.ne    2f
    cmp     w5, #5
    b.hi    5f
2:
    madd    x3, x3, x7, x5
    add     x4, x4, #1
    b       1b
3:
    str     x3, [x2]
    mov     w0, #0
    ret
4:
    mov     w0, #-1
    ret
5:
    mov     w0, #-2
    ret
.size tp5_parse_u64, .-tp5_parse_u64

// tp5_strnlen(x0=string, x1=maximum) -> x0=length; -1 if no terminator.
.type tp5_strnlen, %function
tp5_strnlen:
    mov     x2, #0
1:
    cmp     x2, x1
    b.hs    3f
    ldrb    w3, [x0, x2]
    cbz     w3, 2f
    add     x2, x2, #1
    b       1b
2:
    mov     x0, x2
    ret
3:
    mov     x0, #-1
    ret
.size tp5_strnlen, .-tp5_strnlen

// tp5_buffer_copy(x0=dst, x1=capacity, x2=src, x3=count) -> x0=count/-1.
// No byte is written when count exceeds capacity.
.type tp5_buffer_copy, %function
tp5_buffer_copy:
    cmp     x3, x1
    b.hi    3f
    mov     x4, #0
1:
    cmp     x4, x3
    b.hs    2f
    ldrb    w5, [x2, x4]
    strb    w5, [x0, x4]
    add     x4, x4, #1
    b       1b
2:
    mov     x0, x3
    ret
3:
    mov     x0, #-1
    ret
.size tp5_buffer_copy, .-tp5_buffer_copy

// tp5_u64_to_buffer(x0=value, x1=buffer, x2=capacity) -> x0=start, x1=len;
// x0=0,x1=0 when capacity is insufficient. No terminator is appended.
.type tp5_u64_to_buffer, %function
tp5_u64_to_buffer:
    cbz     x2, 5f
    mov     x4, x0
    mov     x5, #1
    cbz     x4, 2f
    mov     x5, #0
    mov     x6, x4
1:
    mov     x7, #10
    udiv    x6, x6, x7
    add     x5, x5, #1
    cbnz    x6, 1b
2:
    cmp     x5, x2
    b.hi    5f
    add     x3, x1, x2
    mov     x6, x4
    cbnz    x6, 3f
    sub     x3, x3, #1
    mov     w7, #'0'
    strb    w7, [x3]
    mov     x0, x3
    mov     x1, x5
    ret
3:
    mov     x7, #10
    udiv    x8, x6, x7
    msub    x9, x8, x7, x6
    add     w9, w9, #'0'
    sub     x3, x3, #1
    strb    w9, [x3]
    mov     x6, x8
    cbnz    x6, 3b
    mov     x0, x3
    mov     x1, x5
    ret
5:
    mov     x0, #0
    mov     x1, #0
    ret
.size tp5_u64_to_buffer, .-tp5_u64_to_buffer
