// TP5 fixed-point extensions. Existing TP4 numeric routines remain unchanged.
.text
.align 2

.global q16_16_mul_sat

// q16_16_mul_sat(w0=a, w1=b) -> x0=signed Q16.16 clamped to int32.
// The 32x32 product is exact in signed 64 bits; ASR implements truncation
// toward negative infinity for negative non-integral products.
.type q16_16_mul_sat, %function
q16_16_mul_sat:
    sxtw    x0, w0
    sxtw    x1, w1
    mul     x2, x0, x1
    asr     x2, x2, #16
    ldr     x3, =2147483647
    cmp     x2, x3
    b.gt    1f
    ldr     x3, =-2147483648
    cmp     x2, x3
    b.lt    2f
    mov     x0, x2
    ret
1:
    ldr     x0, =2147483647
    ret
2:
    ldr     x0, =-2147483648
    ret
.size q16_16_mul_sat, .-q16_16_mul_sat
