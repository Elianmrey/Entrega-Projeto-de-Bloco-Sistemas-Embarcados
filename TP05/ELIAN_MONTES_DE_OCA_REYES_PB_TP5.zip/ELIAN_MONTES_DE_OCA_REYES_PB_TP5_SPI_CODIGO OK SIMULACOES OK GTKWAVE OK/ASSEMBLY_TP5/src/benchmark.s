// TP5 benchmark/statistics helpers.
// Structure layout (40 bytes): count, failures, total_ns, min_ns, max_ns.
.text
.align 2

.global tp5_stats_reset
.global tp5_stats_add
.global tp5_elapsed_us
.global tp5_average_ns

.type tp5_stats_reset, %function
tp5_stats_reset:
    str     xzr, [x0, #0]
    str     xzr, [x0, #8]
    str     xzr, [x0, #16]
    mov     x1, #-1
    str     x1, [x0, #24]
    str     xzr, [x0, #32]
    ret
.size tp5_stats_reset, .-tp5_stats_reset

// tp5_stats_add(x0=stats, x1=latency_ns, w2=success[0/1]).
.type tp5_stats_add, %function
tp5_stats_add:
    ldr     x3, [x0, #0]
    add     x3, x3, #1
    str     x3, [x0, #0]
    cbnz    w2, 1f
    ldr     x3, [x0, #8]
    add     x3, x3, #1
    str     x3, [x0, #8]
1:
    ldr     x3, [x0, #16]
    add     x3, x3, x1
    str     x3, [x0, #16]
    ldr     x3, [x0, #24]
    cmp     x1, x3
    csel    x3, x1, x3, lo
    str     x3, [x0, #24]
    ldr     x3, [x0, #32]
    cmp     x1, x3
    csel    x3, x1, x3, hi
    str     x3, [x0, #32]
    ret
.size tp5_stats_add, .-tp5_stats_add

// tp5_elapsed_us(x0=start_ns, x1=end_ns) -> x0=elapsed_us; 0 if end<start.
.type tp5_elapsed_us, %function
tp5_elapsed_us:
    cmp     x1, x0
    b.lo    1f
    sub     x0, x1, x0
    mov     x2, #1000
    udiv    x0, x0, x2
    ret
1:
    mov     x0, #0
    ret
.size tp5_elapsed_us, .-tp5_elapsed_us

// tp5_average_ns(x0=stats) -> x0=average; zero for empty set.
.type tp5_average_ns, %function
tp5_average_ns:
    ldr     x1, [x0, #0]
    cbz     x1, 1f
    ldr     x2, [x0, #16]
    udiv    x0, x2, x1
    ret
1:
    mov     x0, #0
    ret
.size tp5_average_ns, .-tp5_average_ns
