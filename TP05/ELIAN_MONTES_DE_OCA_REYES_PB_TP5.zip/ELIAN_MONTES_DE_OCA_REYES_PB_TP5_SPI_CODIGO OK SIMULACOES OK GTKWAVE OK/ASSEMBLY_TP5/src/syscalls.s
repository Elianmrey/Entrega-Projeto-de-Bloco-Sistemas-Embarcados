// TP5 direct-syscall I/O helpers. No libc dependency.
.include "common.inc"
.include "tp5_macros.inc"
.text
.align 2

.global tp5_write_all
.global tp5_read_exact
.global tp5_close

// tp5_write_all(x0=fd, x1=buffer, x2=count) -> x0=bytes or negative errno.
.type tp5_write_all, %function
tp5_write_all:
    stp     x29, x30, [sp, #-48]!
    stp     x19, x20, [sp, #16]
    str     x21, [sp, #32]
    mov     x29, sp
    mov     x19, x0
    mov     x20, x1
    mov     x21, x2
    mov     x3, #0
1:
    cmp     x3, x21
    b.hs    4f
    mov     x0, x19
    add     x1, x20, x3
    sub     x2, x21, x3
    TP5_SYSCALL SYS_write
    cmp     x0, #-4                 // -EINTR
    b.eq    1b
    cmp     x0, #0
    b.lt    5f
    cbz     x0, 5f
    add     x3, x3, x0
    b       1b
4:
    mov     x0, x3
    b       6f
5:
    // Preserve the negative syscall result; zero means short/no-progress.
    cbnz    x0, 6f
    mov     x0, #-5                 // -EIO
6:
    ldr     x21, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #48
    ret
.size tp5_write_all, .-tp5_write_all

// tp5_read_exact(x0=fd, x1=buffer, x2=count) -> x0=bytes or negative errno.
.type tp5_read_exact, %function
tp5_read_exact:
    stp     x29, x30, [sp, #-48]!
    stp     x19, x20, [sp, #16]
    str     x21, [sp, #32]
    mov     x29, sp
    mov     x19, x0
    mov     x20, x1
    mov     x21, x2
    mov     x3, #0
1:
    cmp     x3, x21
    b.hs    4f
    mov     x0, x19
    add     x1, x20, x3
    sub     x2, x21, x3
    TP5_SYSCALL SYS_read
    cmp     x0, #-4
    b.eq    1b
    cmp     x0, #0
    b.lt    5f
    cbz     x0, 5f
    add     x3, x3, x0
    b       1b
4:
    mov     x0, x3
    b       6f
5:
    cbnz    x0, 6f
    mov     x0, #-5
6:
    ldr     x21, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #48
    ret
.size tp5_read_exact, .-tp5_read_exact

.type tp5_close, %function
tp5_close:
    TP5_SYSCALL SYS_close
    ret
.size tp5_close, .-tp5_close
