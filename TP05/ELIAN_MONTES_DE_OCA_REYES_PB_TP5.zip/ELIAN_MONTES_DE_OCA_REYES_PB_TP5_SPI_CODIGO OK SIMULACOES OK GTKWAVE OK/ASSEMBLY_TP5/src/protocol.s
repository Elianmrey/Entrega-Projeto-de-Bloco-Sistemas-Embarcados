// TP5 protocol primitives for the fixed 14-byte SPI transaction.
.include "common.inc"
.include "tp5_macros.inc"
.text
.align 2

.global tp5_checksum
.global tp5_build_frame
.global tp5_validate_frame
.global tp5_is_response_frame
.global tp5_validate_sequence
.global tp5_reset_sequence

// tp5_checksum(x0=frame) -> w0 = XOR of bytes 0..12.
.type tp5_checksum, %function
tp5_checksum:
    mov     w1, #0
    mov     x2, #0
1:
    cmp     x2, #TP5_OFF_CHECKSUM
    b.ge    2f
    ldrb    w3, [x0, x2]
    eor     w1, w1, w3
    add     x2, x2, #1
    b       1b
2:
    and     w0, w1, #0xff
    ret
.size tp5_checksum, .-tp5_checksum

// tp5_build_frame(x0=dst, w1=command, w2=sequence, w3=length,
//                 x4=payload pointer or zero) -> x0=dst, w1=14.
// Payload is zero-filled and at most eight bytes are copied.
.type tp5_build_frame, %function
tp5_build_frame:
    stp     x29, x30, [sp, #-64]!
    stp     x19, x20, [sp, #16]
    stp     x21, x22, [sp, #32]
    str     x23, [sp, #48]
    mov     x29, sp
    mov     x19, x0
    mov     w20, w1
    mov     w21, w2
    mov     w22, w3
    mov     x23, x4

    cmp     w22, #TP5_MAX_PAYLOAD
    b.ls    1f
    mov     w22, #TP5_MAX_PAYLOAD
1:
    mov     x1, #TP5_FRAME_SIZE
    bl      tp5_zero_buffer

    mov     w0, #TP5_SOF
    TP5_STORE_BYTE w0, x19, TP5_OFF_SOF
    mov     w0, #TP5_VERSION
    TP5_STORE_BYTE w0, x19, TP5_OFF_VERSION
    TP5_STORE_BYTE w20, x19, TP5_OFF_COMMAND
    TP5_STORE_BYTE w21, x19, TP5_OFF_SEQUENCE
    TP5_STORE_BYTE w22, x19, TP5_OFF_LENGTH

    cbz     x23, 4f
    mov     w5, #0
2:
    cmp     w5, w22
    b.ge    4f
    ldrb    w6, [x23, w5, uxtw]
    add     w7, w5, #TP5_OFF_PAYLOAD
    strb    w6, [x19, w7, uxtw]
    add     w5, w5, #1
    b       2b
4:
    mov     x0, x19
    bl      tp5_checksum
    TP5_STORE_BYTE w0, x19, TP5_OFF_CHECKSUM
    mov     x0, x19
    mov     w1, #TP5_FRAME_SIZE

    ldr     x23, [sp, #48]
    ldp     x21, x22, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #64
    ret
.size tp5_build_frame, .-tp5_build_frame

// tp5_validate_frame(x0=frame, x1=available length) -> w0=TP5_ERR_*.
.type tp5_validate_frame, %function
tp5_validate_frame:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp
    mov     x19, x0

    cmp     x1, #TP5_FRAME_SIZE
    b.ne    5f
    TP5_LOAD_BYTE w2, x19, TP5_OFF_SOF
    cmp     w2, #TP5_SOF
    b.ne    6f
    TP5_LOAD_BYTE w2, x19, TP5_OFF_VERSION
    cmp     w2, #TP5_VERSION
    b.ne    7f
    TP5_LOAD_BYTE w2, x19, TP5_OFF_LENGTH
    cmp     w2, #TP5_MAX_PAYLOAD
    b.hi    5f

    mov     x0, x19
    bl      tp5_checksum
    TP5_LOAD_BYTE w2, x19, TP5_OFF_CHECKSUM
    cmp     w0, w2
    b.ne    8f
    mov     w0, #TP5_ERR_NONE
    b       9f
5:
    mov     w0, #TP5_ERR_LENGTH
    b       9f
6:
    mov     w0, #TP5_ERR_SOF
    b       9f
7:
    mov     w0, #TP5_ERR_VERSION
    b       9f
8:
    mov     w0, #TP5_ERR_CHECKSUM
9:
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret
.size tp5_validate_frame, .-tp5_validate_frame

// tp5_is_response_frame(x0=frame, x1=available length) -> w0=1 only for a
// structurally valid TP5 response (ACK/NACK/BUSY/LEGACY); otherwise w0=0.
// This prevents a protocol response from being parsed as legacy sensor data.
.type tp5_is_response_frame, %function
tp5_is_response_frame:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp
    mov     x19, x0
    bl      tp5_validate_frame
    cbnz    w0, 1f
    ldrb    w1, [x19, #TP5_OFF_COMMAND]
    cmp     w1, #TP5_RSP_ACK
    b.lo    1f
    cmp     w1, #TP5_RSP_LEGACY
    b.hi    1f
    mov     w0, #1
    b       2f
1:
    mov     w0, #0
2:
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret
.size tp5_is_response_frame, .-tp5_is_response_frame

// tp5_validate_sequence(w0=received) -> w0=0 accepted, TP5_ERR_SEQUENCE rejected.
// The first sequence is accepted; subsequent values must increment modulo 256.
.type tp5_validate_sequence, %function
tp5_validate_sequence:
    TP5_GLOBAL_ADDR x1, tp5_sequence_initialized
    ldrb    w2, [x1]
    cbz     w2, 1f
    TP5_GLOBAL_ADDR x2, tp5_last_sequence
    ldrb    w3, [x2]
    add     w3, w3, #1
    and     w3, w3, #0xff
    cmp     w0, w3
    b.ne    2f
    strb    w0, [x2]
    mov     w0, #TP5_ERR_NONE
    ret
1:
    mov     w2, #1
    strb    w2, [x1]
    TP5_GLOBAL_ADDR x2, tp5_last_sequence
    strb    w0, [x2]
    mov     w0, #TP5_ERR_NONE
    ret
2:
    mov     w0, #TP5_ERR_SEQUENCE
    ret
.size tp5_validate_sequence, .-tp5_validate_sequence

.type tp5_reset_sequence, %function
tp5_reset_sequence:
    TP5_GLOBAL_ADDR x0, tp5_sequence_initialized
    strb    wzr, [x0]
    TP5_GLOBAL_ADDR x0, tp5_last_sequence
    strb    wzr, [x0]
    ret
.size tp5_reset_sequence, .-tp5_reset_sequence

// Private bounded zeroing helper: x0=buffer, x1=length.
.type tp5_zero_buffer, %function
tp5_zero_buffer:
    cbz     x1, 2f
    mov     x2, #0
1:
    strb    wzr, [x0, x2]
    add     x2, x2, #1
    cmp     x2, x1
    b.lo    1b
2:
    ret
.size tp5_zero_buffer, .-tp5_zero_buffer

.bss
.align 3
tp5_sequence_initialized:
    .skip 1
tp5_last_sequence:
    .skip 1
