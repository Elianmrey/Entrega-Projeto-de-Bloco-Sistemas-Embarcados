`timescale 1ns/1ps
module tb_tp5_integration;
    reg sys_clk = 1'b0;
    reg rst_n = 1'b0;
    reg mcp_miso = 1'b0;
    reg arm_spi_sclk = 1'b0;
    reg arm_spi_mosi = 1'b0;
    reg arm_spi_cs_n = 1'b1;
    tri bmp_sda, bmp_scl;
    wire mcp_cs_n, mcp_sclk, mcp_mosi, arm_spi_miso;
    wire [2:0] led;

    reg [111:0] rx_first;
    reg [111:0] rx_ack;
    reg sampled_miso;
    integer i;
    reg saw_frame_valid = 1'b0;
    reg saw_crc_valid = 1'b0;
    reg saw_ready = 1'b0;
    reg saw_busy = 1'b0;
    reg saw_command_accepted = 1'b0;
    reg saw_action_trigger = 1'b0;
    reg saw_action_done = 1'b0;
    reg saw_response_valid = 1'b0;

    always #5 sys_clk = ~sys_clk;
    pullup(bmp_sda);
    pullup(bmp_scl);

    tang_nano_4k_top #(
        .CLK_HZ(1000),
        .SPI_SAMPLE_PERIOD(1000000),
        .I2C_HZ(10),
        .TP5_ACTION_CYCLES(8),
        .TP5_TIMEOUT_CYCLES(500)
    ) dut (
        .sys_clk(sys_clk), .rst_n(rst_n),
        .mcp_cs_n(mcp_cs_n), .mcp_sclk(mcp_sclk), .mcp_mosi(mcp_mosi),
        .mcp_miso(mcp_miso), .bmp_sda(bmp_sda), .bmp_scl(bmp_scl),
        .arm_spi_sclk(arm_spi_sclk), .arm_spi_mosi(arm_spi_mosi),
        .arm_spi_miso(arm_spi_miso), .arm_spi_cs_n(arm_spi_cs_n),
        .led(led)
    );

    always @(posedge sys_clk) begin
        if (dut.pi_frame_valid) saw_frame_valid <= 1'b1;
        if (dut.tp5_crc_valid) saw_crc_valid <= 1'b1;
        if (dut.tp5_ready) saw_ready <= 1'b1;
        if (dut.tp5_busy) saw_busy <= 1'b1;
        if (dut.tp5_command_accepted) saw_command_accepted <= 1'b1;
        if (dut.tp5_action_trigger) saw_action_trigger <= 1'b1;
        if (dut.tp5_action_done) saw_action_done <= 1'b1;
        if (dut.tp5_response_valid) saw_response_valid <= 1'b1;
    end

    function [7:0] checksum13;
        input [111:0] f;
        begin
            checksum13 = f[111:104] ^ f[103:96] ^ f[95:88] ^ f[87:80] ^
                         f[79:72] ^ f[71:64] ^ f[63:56] ^ f[55:48] ^
                         f[47:40] ^ f[39:32] ^ f[31:24] ^ f[23:16] ^ f[15:8];
        end
    endfunction

    function [111:0] make_command;
        input [7:0] command_value;
        input [7:0] seq_value;
        input [7:0] length_value;
        input [63:0] payload;
        reg [111:0] f;
        begin
            f = {8'hA5, 8'h01, command_value, seq_value,
                 length_value, payload, 8'h00};
            f[7:0] = checksum13(f);
            make_command = f;
        end
    endfunction

    task transfer_bit;
        input mosi_bit;
        output miso_bit;
        begin
            arm_spi_mosi = mosi_bit;
            #80;
            arm_spi_sclk = 1'b1;
            #30;
            miso_bit = arm_spi_miso;
            #70;
            arm_spi_sclk = 1'b0;
            #100;
        end
    endtask

    task transfer_frame;
        input [111:0] tx;
        output [111:0] rx;
        begin
            rx = 112'd0;
            arm_spi_cs_n = 1'b0;
            #160;
            for (i = 0; i < 112; i = i + 1) begin
                transfer_bit(tx[111-i], sampled_miso);
                rx[111-i] = sampled_miso;
            end
            #100;
            arm_spi_cs_n = 1'b1;
            #240;
        end
    endtask

    initial begin
        $dumpfile("build/tb_tp5_integration.vcd");
        $dumpvars(0, tb_tp5_integration);

        #40 rst_n = 1'b1;
        #100;

        // 1) ARM envia SET_OUTPUT=5. A primeira leitura ainda e o frame TP4.
        transfer_frame(make_command(8'h10, 8'h00, 8'd1, {8'h05,56'd0}), rx_first);
        if (rx_first[111:104] !== 8'hA5)
            $fatal(1, "Frame legado inicial perdeu o SOF: %h", rx_first);

        #300;
        if (dut.tp5_output_control !== 8'h05)
            $fatal(1, "Comando recebido nao alterou output_control");
        if (led !== 3'b010)
            $fatal(1, "Acao observavel nos LEDs incorreta: led=%b", led);

        // 2) A transacao seguinte recebe o ACK preparado para SET_OUTPUT.
        transfer_frame(make_command(8'h02, 8'h01, 8'd0, 64'd0), rx_ack);
        if (rx_ack[111:104] !== 8'hA5 || rx_ack[103:96] !== 8'h01)
            $fatal(1, "Cabecalho de resposta TP5 invalido: %h", rx_ack);
        if (rx_ack[95:88] !== 8'h80 || rx_ack[87:80] !== 8'h00)
            $fatal(1, "ACK/sequence incorretos: %h", rx_ack);
        if (rx_ack[71:64] !== 8'h10)
            $fatal(1, "ACK nao corresponde a SET_OUTPUT: %h", rx_ack);
        if (checksum13(rx_ack) !== rx_ack[7:0])
            $fatal(1, "CRC/checksum de resposta incorreto: %h", rx_ack);

        if (!saw_frame_valid || !saw_crc_valid || !saw_ready || !saw_busy ||
            !saw_command_accepted || !saw_action_trigger || !saw_action_done ||
            !saw_response_valid)
            $fatal(1, "Handshake incompleto: fv=%b crc=%b rdy=%b busy=%b acc=%b trig=%b done=%b rsp=%b",
                   saw_frame_valid, saw_crc_valid, saw_ready, saw_busy,
                   saw_command_accepted, saw_action_trigger, saw_action_done,
                   saw_response_valid);

        $display("PASS tb_tp5_integration: ARM envia -> FPGA valida -> executa -> responde");
        $finish;
    end
endmodule
