`timescale 1ns/1ps
module tb_tp5_protocol_controller;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg frame_event = 1'b0;
    reg timeout_event = 1'b0;
    reg truncated_event = 1'b0;
    reg response_consumed = 1'b0;
    reg [7:0] legacy_command = 8'd0;
    reg [111:0] rx_frame = 112'd0;

    reg signed [15:0] bmp_temp = 16'sd251;
    reg [31:0] bmp_pressure_pa = 32'd101325;
    reg [15:0] lm35_temp_x10 = 16'd248;
    reg [7:0] pot_percent = 8'd50;
    reg [15:0] lm35_raw = 16'd77;
    reg [15:0] pot_raw = 16'd512;
    reg [15:0] tp4_signature = 16'h55AA;
    reg mcp_valid = 1'b0;
    reg bmp_valid = 1'b0;
    reg dsp_valid = 1'b0;
    reg bmp_error = 1'b0;
    reg mcp_busy = 1'b0;
    reg bmp_busy = 1'b0;

    wire ready, busy, command_accepted, response_valid, response_available;
    wire error, crc_valid, action_trigger, action_done;
    wire [7:0] status, sequence, output_control;
    wire [111:0] response_frame;
    wire [31:0] transaction_count, error_count, sample_count;

    reg [111:0] observed_response;
    integer response_count = 0;
    integer accepted_count = 0;
    integer action_count = 0;

    localparam [7:0] RSP_ACK  = 8'h80;
    localparam [7:0] RSP_NACK = 8'h81;
    localparam [7:0] RSP_BUSY = 8'h82;

    localparam [7:0] ERR_SOF         = 8'h01;
    localparam [7:0] ERR_LENGTH      = 8'h03;
    localparam [7:0] ERR_CRC         = 8'h04;
    localparam [7:0] ERR_SEQUENCE    = 8'h05;
    localparam [7:0] ERR_UNKNOWN_CMD = 8'h06;
    localparam [7:0] ERR_TIMEOUT     = 8'h07;
    localparam [7:0] ERR_TRUNCATED   = 8'h08;
    localparam [7:0] ERR_BUSY        = 8'h09;

    always #5 clk = ~clk;

    always @(posedge clk) begin
        if (response_valid) begin
            observed_response <= response_frame;
            response_count <= response_count + 1;
        end
        if (command_accepted)
            accepted_count <= accepted_count + 1;
        if (action_trigger)
            action_count <= action_count + 1;
    end

    tp5_protocol_controller #(.ACTION_CYCLES(20)) dut (
        .clk(clk), .rst_n(rst_n),
        .frame_event(frame_event), .timeout_event(timeout_event),
        .truncated_event(truncated_event),
        .mosi_overrun_event(1'b0),
        .response_consumed(response_consumed),
        .legacy_command(legacy_command), .rx_frame(rx_frame),
        .bmp_temp(bmp_temp), .bmp_pressure_pa(bmp_pressure_pa),
        .lm35_temp_x10(lm35_temp_x10), .pot_percent(pot_percent),
        .lm35_raw(lm35_raw), .pot_raw(pot_raw),
        .tp4_signature(tp4_signature),
        .mcp_valid(mcp_valid), .bmp_valid(bmp_valid), .dsp_valid(dsp_valid),
        .bmp_error(bmp_error), .mcp_busy(mcp_busy), .bmp_busy(bmp_busy),
        .ready(ready), .busy(busy), .command_accepted(command_accepted),
        .response_valid(response_valid), .response_available(response_available),
        .error(error), .crc_valid(crc_valid),
        .action_trigger(action_trigger), .action_done(action_done),
        .status(status), .sequence_number(sequence), .output_control(output_control),
        .response_frame(response_frame),
        .transaction_count(transaction_count), .error_count(error_count),
        .sample_count(sample_count)
    );

    function [7:0] checksum13;
        input [111:0] f;
        begin
            checksum13 = f[111:104] ^ f[103:96] ^ f[95:88] ^ f[87:80] ^
                         f[79:72] ^ f[71:64] ^ f[63:56] ^ f[55:48] ^
                         f[47:40] ^ f[39:32] ^ f[31:24] ^ f[23:16] ^ f[15:8];
        end
    endfunction

    function [111:0] make_command;
        input [7:0] sof;
        input [7:0] version;
        input [7:0] command_value;
        input [7:0] seq_value;
        input [7:0] length_value;
        input [63:0] payload;
        reg [111:0] f;
        begin
            f = {sof, version, command_value, seq_value, length_value, payload, 8'h00};
            f[7:0] = checksum13(f);
            make_command = f;
        end
    endfunction

    task send_frame;
        input [111:0] f;
        begin
            @(negedge clk);
            rx_frame = f;
            frame_event = 1'b1;
            @(negedge clk);
            frame_event = 1'b0;
        end
    endtask

    task pulse_consumed;
        begin
            @(negedge clk);
            response_consumed = 1'b1;
            @(negedge clk);
            response_consumed = 1'b0;
        end
    endtask

    task expect_response;
        input integer expected_count;
        input [7:0] expected_status;
        input [7:0] expected_seq;
        input [7:0] expected_payload0;
        integer guard;
        begin
            guard = 0;
            while ((response_count < expected_count) && (guard < 30)) begin
                @(posedge clk);
                guard = guard + 1;
            end
            #1;
            if (response_count != expected_count)
                $fatal(1, "Resposta %0d nao observada", expected_count);
            if (observed_response[95:88] !== expected_status)
                $fatal(1, "Status incorreto: obtido=%h esperado=%h",
                       observed_response[95:88], expected_status);
            if (observed_response[87:80] !== expected_seq)
                $fatal(1, "Sequencia incorreta: obtida=%h esperada=%h",
                       observed_response[87:80], expected_seq);
            if (observed_response[71:64] !== expected_payload0)
                $fatal(1, "Payload[0] incorreto: obtido=%h esperado=%h",
                       observed_response[71:64], expected_payload0);
            if (checksum13(observed_response) !== observed_response[7:0])
                $fatal(1, "Checksum de resposta invalido");
        end
    endtask

    initial begin
        $dumpfile("build/tb_tp5_protocol_controller.vcd");
        $dumpvars(0, tb_tp5_protocol_controller);

        #30 rst_n = 1'b1;
        @(posedge clk);
        if (!ready || busy || output_control != 0)
            $fatal(1, "RESET: estado inicial invalido");

        // PING valido, primeira sequencia livre.
        send_frame(make_command(8'hA5, 8'h01, 8'h01, 8'h00, 8'd0, 64'd0));
        expect_response(1, RSP_ACK, 8'h00, 8'h01);
        pulse_consumed();

        // Sequencia repetida.
        send_frame(make_command(8'hA5, 8'h01, 8'h01, 8'h00, 8'd0, 64'd0));
        expect_response(2, RSP_NACK, 8'h00, ERR_SEQUENCE);
        pulse_consumed();

        // Comando desconhecido com a proxima sequencia valida.
        send_frame(make_command(8'hA5, 8'h01, 8'h66, 8'h01, 8'd0, 64'd0));
        expect_response(3, RSP_NACK, 8'h01, ERR_UNKNOWN_CMD);
        pulse_consumed();

        // CRC invalido: a sequencia 2 nao deve ser consumida.
        rx_frame = make_command(8'hA5, 8'h01, 8'h01, 8'h02, 8'd0, 64'd0);
        rx_frame[7:0] = rx_frame[7:0] ^ 8'h01;
        send_frame(rx_frame);
        expect_response(4, RSP_NACK, 8'h02, ERR_CRC);
        pulse_consumed();

        // SOF invalido explicitamente reconhecido como erro TP5.
        send_frame(make_command(8'h5A, 8'h01, 8'h01, 8'h02, 8'd0, 64'd0));
        expect_response(5, RSP_NACK, 8'h02, ERR_SOF);
        pulse_consumed();

        // Comprimento maior que os oito bytes de payload disponiveis.
        send_frame(make_command(8'hA5, 8'h01, 8'h01, 8'h02, 8'd9, 64'd0));
        expect_response(6, RSP_NACK, 8'h02, ERR_LENGTH);
        pulse_consumed();

        // SET_OUTPUT exige exatamente um byte de payload.
        send_frame(make_command(8'hA5, 8'h01, 8'h10, 8'h02, 8'd0, 64'd0));
        expect_response(7, RSP_NACK, 8'h02, ERR_LENGTH);
        pulse_consumed();

        // Acao real: controle de LEDs. Durante BUSY, outro comando e rejeitado.
        send_frame(make_command(8'hA5, 8'h01, 8'h10, 8'h02, 8'd1,
                                {8'h05, 56'd0}));
        expect_response(8, RSP_ACK, 8'h02, 8'h10);
        if (observed_response[47:40] !== 8'h05)
            $fatal(1, "ACK nao refletiu output_control novo: %h", observed_response);
        if (!busy || output_control !== 8'h05 || action_count != 1)
            $fatal(1, "SET_OUTPUT nao iniciou a acao observavel");
        pulse_consumed();

        send_frame(make_command(8'hA5, 8'h01, 8'h01, 8'h03, 8'd0, 64'd0));
        expect_response(9, RSP_BUSY, 8'h03, ERR_BUSY);
        pulse_consumed();
        wait(action_done === 1'b1);
        @(posedge clk);
        if (busy || !ready)
            $fatal(1, "Handshake nao retornou a READY apos ACTION_DONE");

        // Telemetria usa valores reais entregues pelos blocos de sensores.
        send_frame(make_command(8'hA5, 8'h01, 8'h03, 8'h03, 8'd0, 64'd0));
        expect_response(11, RSP_ACK, 8'h03, 8'h03);
        if (observed_response[63:56] !== 8'h00 ||
            observed_response[55:48] !== 8'hFB ||
            observed_response[47:40] !== 8'h00 ||
            observed_response[39:32] !== 8'hF8 ||
            observed_response[31:24] !== 8'd50)
            $fatal(1, "Telemetria de sensores incorreta: %h", observed_response);
        pulse_consumed();

        // Eventos de timeout e truncamento geram NACK rastreavel.
        @(negedge clk); timeout_event = 1'b1;
        @(negedge clk); timeout_event = 1'b0;
        expect_response(12, RSP_NACK, 8'h03, ERR_TIMEOUT);
        pulse_consumed();

        @(negedge clk); truncated_event = 1'b1;
        @(negedge clk); truncated_event = 1'b0;
        expect_response(13, RSP_NACK, 8'h03, ERR_TRUNCATED);
        pulse_consumed();

        // RESET durante BUSY deve restaurar estado seguro e cancelar a acao.
        send_frame(make_command(8'hA5, 8'h01, 8'h10, 8'h04, 8'd1,
                                {8'h07, 56'd0}));
        expect_response(14, RSP_ACK, 8'h04, 8'h10);
        if (!busy) $fatal(1, "Acao deveria estar BUSY antes do reset");
        #2 rst_n = 1'b0;
        #12;
        if (busy || !ready || output_control != 0 || response_available)
            $fatal(1, "RESET durante operacao nao restaurou estado seguro");
        rst_n = 1'b1;
        @(posedge clk);
        #1;
        if (!ready || busy || output_control != 0)
            $fatal(1, "READY nao restaurado depois do reset");

        // A sequencia e modular: 255 deve ser seguida por 0.
        send_frame(make_command(8'hA5, 8'h01, 8'h01, 8'hFF, 8'd0, 64'd0));
        expect_response(15, RSP_ACK, 8'hFF, 8'h01);
        pulse_consumed();
        send_frame(make_command(8'hA5, 8'h01, 8'h01, 8'h00, 8'd0, 64'd0));
        expect_response(16, RSP_ACK, 8'h00, 8'h01);
        pulse_consumed();

        $display("PASS tb_tp5_protocol_controller: comandos, CRC, sequencia/wrap, busy, telemetria, timeout, truncamento e reset");
        $finish;
    end
endmodule
