`timescale 1ns/1ps
module tb_spi_slave_pi4_tp5;
    reg sys_clk = 1'b0;
    reg rst_n = 1'b0;
    reg sclk = 1'b0;
    reg mosi = 1'b0;
    reg cs_n = 1'b1;
    wire miso;

    reg [111:0] response_frame = 112'hA5018000080102030405060708AA;
    reg response_available = 1'b1;
    wire frame_valid;
    wire [7:0] command_byte;
    wire [111:0] rx_frame;
    wire timeout_event, truncated_event, response_consumed;

    reg saw_frame_valid = 1'b0;
    reg saw_timeout = 1'b0;
    reg saw_truncated = 1'b0;
    reg saw_consumed = 1'b0;
    reg [111:0] received;
    reg sampled_miso;
    reg [111:0] command_frame;
    integer i;

    always #5 sys_clk = ~sys_clk;
    always @(posedge sys_clk) begin
        if (frame_valid) saw_frame_valid <= 1'b1;
        if (timeout_event) saw_timeout <= 1'b1;
        if (truncated_event) saw_truncated <= 1'b1;
        if (response_consumed) saw_consumed <= 1'b1;
    end

    spi_slave_pi4 #(.FRAME_TIMEOUT_CYCLES(20)) dut (
        .sys_clk(sys_clk), .rst_n(rst_n),
        .arm_spi_sclk(sclk), .arm_spi_mosi(mosi),
        .arm_spi_miso(miso), .arm_spi_cs_n(cs_n),
        .bmp_temp(16'h1234), .bmp_pressure_pa(32'd101325),
        .lm35_temp_x10(16'h00FB), .pot_percent(8'd50),
        .lm35_raw(16'h0055), .pot_raw(16'h0200),
        .response_frame(response_frame),
        .response_available(response_available),
        .mosi_sample_ready(1'b1), .mosi_sample_valid(),
        .mosi_sampled_bit(), .mosi_overrun_event(),
        .frame_valid(frame_valid), .command_byte(command_byte),
        .rx_frame(rx_frame), .timeout_event(timeout_event),
        .truncated_event(truncated_event),
        .response_consumed(response_consumed)
    );

    task transfer_bit;
        input tx_bit;
        output rx_bit;
        begin
            mosi = tx_bit;
            #80; sclk = 1'b1;
            #30; rx_bit = miso;
            #70; sclk = 1'b0;
            #100;
        end
    endtask

    initial begin
        $dumpfile("build/tb_spi_slave_pi4_tp5.vcd");
        $dumpvars(0, tb_spi_slave_pi4_tp5);
        command_frame = 112'hA5011000010500000000000000B0;
        received = 112'd0;

        #30 rst_n = 1'b1;
        #100;

        // Resposta pendente e carregada no CS; MOSI completo e publicado.
        cs_n = 1'b0;
        #160;
        for (i = 0; i < 112; i = i + 1) begin
            transfer_bit(command_frame[111-i], sampled_miso);
            received[111-i] = sampled_miso;
        end
        #100; cs_n = 1'b1;
        #180;

        if (received !== response_frame)
            $fatal(1, "Resposta SPI incorreta: obtida=%h esperada=%h",
                   received, response_frame);
        if (!saw_consumed || !saw_frame_valid)
            $fatal(1, "Handshake de transporte ausente: consumed=%b valid=%b",
                   saw_consumed, saw_frame_valid);
        if (rx_frame !== command_frame || command_byte !== 8'hA5)
            $fatal(1, "Frame RX completo incorreto: %h cmd=%h", rx_frame, command_byte);

        // Limite exato: 111 bits ainda e truncado; somente 112 formam frame.
        response_available = 1'b0;
        saw_truncated = 1'b0;
        saw_frame_valid = 1'b0;
        cs_n = 1'b0;
        #160;
        for (i = 0; i < 111; i = i + 1)
            transfer_bit(1'b0, sampled_miso);
        #50; cs_n = 1'b1;
        #180;
        if (!saw_truncated || saw_frame_valid)
            $fatal(1, "Limite 111 bits incorreto: truncated=%b valid=%b",
                   saw_truncated, saw_frame_valid);

        // CS ativo sem clock excede o watchdog de frame.
        saw_timeout = 1'b0;
        cs_n = 1'b0;
        #400;
        if (!saw_timeout)
            $fatal(1, "Timeout SPI nao detectado");
        cs_n = 1'b1;
        #100;
        if (miso !== 1'b0)
            $fatal(1, "MISO deve permanecer em zero quando CS esta inativo");

        $display("PASS tb_spi_slave_pi4_tp5: RX/TX, truncamento, CS e timeout");
        $finish;
    end
endmodule
