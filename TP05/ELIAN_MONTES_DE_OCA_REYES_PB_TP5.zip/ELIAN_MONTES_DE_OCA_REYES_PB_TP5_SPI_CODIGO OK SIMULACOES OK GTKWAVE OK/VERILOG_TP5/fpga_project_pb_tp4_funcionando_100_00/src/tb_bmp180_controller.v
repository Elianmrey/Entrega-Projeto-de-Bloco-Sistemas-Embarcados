`timescale 1ns/1ps
// Testbench para bmp180_controller.v.
// Modela um escravo BMP180 em I2C open-drain com coeficientes de calibração
// e vetores de referência do datasheet (OSS=0): UT=27898, UP=23843.
// Não altera o RTL do controlador; usa parâmetros acelerados apenas na instância.
module tb_bmp180_controller;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    tri1 bmp_sda;
    tri1 bmp_scl;

    wire [31:0] pressure_pa;
    wire signed [15:0] temperature_x10;
    wire data_valid;
    wire busy;
    wire error;

    reg slave_sda_low;
    assign bmp_sda = slave_sda_low ? 1'b0 : 1'bz;

    reg [7:0] calibration [0:21];
    reg [7:0] rx_byte;
    reg [7:0] pointer_byte;
    reg [7:0] control_byte;
    reg [7:0] last_conversion;
    reg master_ack;
    reg failed;
    integer i;
    integer temperature_start_count;
    integer pressure_start_count;

    // Parametrização somente para reduzir o tempo de simulação.
    bmp180_controller #(
        .CLK_HZ(1_000),
        .I2C_HZ(250),
        .TEMP_WAIT_MS(1),
        .PRESS_WAIT_MS(1)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .bmp_sda(bmp_sda),
        .bmp_scl(bmp_scl),
        .pressure_pa(pressure_pa),
        .temperature_x10(temperature_x10),
        .data_valid(data_valid),
        .busy(busy),
        .error(error)
    );

    always #5 clk = ~clk;

    task wait_start;
        begin : wait_start_loop
            forever begin
                @(negedge bmp_sda);
                if (bmp_scl === 1'b1)
                    disable wait_start_loop;
            end
        end
    endtask

    task wait_stop;
        begin : wait_stop_loop
            forever begin
                @(posedge bmp_sda);
                if (bmp_scl === 1'b1)
                    disable wait_stop_loop;
            end
        end
    endtask

    task slave_receive_byte;
        output [7:0] value;
        integer bit_index;
        begin
            value = 8'd0;
            for (bit_index = 7; bit_index >= 0; bit_index = bit_index - 1) begin
                @(posedge bmp_scl);
                value[bit_index] = bmp_sda;
            end
        end
    endtask

    task slave_ack;
        begin
            // Fim do oitavo bit: o mestre reduz SCL; o escravo passa a reconhecer.
            @(negedge bmp_scl);
            slave_sda_low = 1'b1;
            @(posedge bmp_scl);
            @(negedge bmp_scl);
            slave_sda_low = 1'b0;
        end
    endtask

    task slave_send_byte;
        input [7:0] value;
        output acked_by_master;
        integer bit_index;
        begin
            // Primeiro bit deve estar estável antes da subida de SCL.
            slave_sda_low = ~value[7];
            for (bit_index = 7; bit_index >= 0; bit_index = bit_index - 1) begin
                @(posedge bmp_scl);
                @(negedge bmp_scl);
                if (bit_index > 0)
                    slave_sda_low = ~value[bit_index-1];
                else
                    slave_sda_low = 1'b0;
            end
            // Nono pulso: ACK (0) para continuar ou NACK (1) para encerrar.
            @(posedge bmp_scl);
            acked_by_master = (bmp_sda === 1'b0);
            @(negedge bmp_scl);
            slave_sda_low = 1'b0;
        end
    endtask

    task expect_byte;
        input [7:0] observed;
        input [7:0] expected;
        input [255:0] label_text;
        begin
            if (observed !== expected) begin
                $display("FAIL BMP180 I2C %0s: observado=%02h esperado=%02h", label_text, observed, expected);
                failed = 1'b1;
            end
        end
    endtask

    task serve_read;
        input [7:0] pointer_value;
        integer read_index;
        begin
            wait_start;
            slave_receive_byte(rx_byte);
            expect_byte(rx_byte, 8'hEF, "endereco de leitura");
            slave_ack;
            if (pointer_value == 8'hAA) begin
                for (read_index = 0; read_index < 22; read_index = read_index + 1)
                    slave_send_byte(calibration[read_index], master_ack);
                if (master_ack !== 1'b0)
                    $display("FAIL BMP180 I2C: ultimo byte de calibracao deveria receber NACK");
            end else if (pointer_value == 8'hF6) begin
                if (last_conversion == 8'h2E) begin
                    slave_send_byte(8'h6C, master_ack); // UT = 27898 = 0x6CFA
                    slave_send_byte(8'hFA, master_ack);
                end else if (last_conversion == 8'h34) begin
                    slave_send_byte(8'h5D, master_ack); // UP = 23843 = 0x5D23
                    slave_send_byte(8'h23, master_ack);
                end else begin
                    $display("FAIL BMP180 I2C: leitura F6 sem conversao anterior valida=%02h", last_conversion);
                    failed = 1'b1;
                end
            end else begin
                $display("FAIL BMP180 I2C: ponteiro de leitura inesperado=%02h", pointer_value);
                failed = 1'b1;
            end
            wait_stop;
        end
    endtask

    // Modelo transacional de escravo BMP180. O controlador sempre começa lendo
    // calibração e então alterna: escrita de conversão -> espera -> leitura.
    initial begin : bmp180_i2c_model
        slave_sda_low = 1'b0;
        failed = 1'b0;
        temperature_start_count = 0;
        pressure_start_count = 0;
        last_conversion = 8'h00;

        // Coeficientes de calibração do exemplo BMP180 do datasheet.
        calibration[0]  = 8'h01; calibration[1]  = 8'h98; // AC1 = 408
        calibration[2]  = 8'hFF; calibration[3]  = 8'hB8; // AC2 = -72
        calibration[4]  = 8'hC7; calibration[5]  = 8'hD1; // AC3 = -14383
        calibration[6]  = 8'h7F; calibration[7]  = 8'hE5; // AC4 = 32741
        calibration[8]  = 8'h7F; calibration[9]  = 8'hF5; // AC5 = 32757
        calibration[10] = 8'h5A; calibration[11] = 8'h71; // AC6 = 23153
        calibration[12] = 8'h18; calibration[13] = 8'h2E; // B1 = 6190
        calibration[14] = 8'h00; calibration[15] = 8'h04; // B2 = 4
        calibration[16] = 8'h80; calibration[17] = 8'h00; // MB = -32768
        calibration[18] = 8'hDD; calibration[19] = 8'hF9; // MC = -8711
        calibration[20] = 8'h0B; calibration[21] = 8'h34; // MD = 2868

        forever begin
            wait_start;
            slave_receive_byte(rx_byte);
            expect_byte(rx_byte, 8'hEE, "endereco de escrita");
            slave_ack;

            slave_receive_byte(pointer_byte);
            slave_ack;

            if (pointer_byte == 8'hAA) begin
                serve_read(pointer_byte);
            end else if (pointer_byte == 8'hF4) begin
                slave_receive_byte(control_byte);
                slave_ack;
                wait_stop;
                if (control_byte == 8'h2E)
                    temperature_start_count = temperature_start_count + 1;
                else if (control_byte == 8'h34)
                    pressure_start_count = pressure_start_count + 1;
                else begin
                    $display("FAIL BMP180 I2C: comando de conversao inesperado=%02h", control_byte);
                    failed = 1'b1;
                end
                last_conversion = control_byte;
            end else if (pointer_byte == 8'hF6) begin
                serve_read(pointer_byte);
            end else begin
                $display("FAIL BMP180 I2C: ponteiro de escrita inesperado=%02h", pointer_byte);
                failed = 1'b1;
            end
        end
    end

    initial begin
        $dumpfile("build/tb_bmp180_controller.vcd");
        $dumpvars(0, tb_bmp180_controller);
        #40 rst_n = 1'b1;

        // Vetor de referência BMP180 (datasheet, OSS=0): T=15,0 °C; P=69964 Pa.
        @(posedge data_valid);
        // O bloco após #20 evita uma instrução vazia (Gowin EX3012).
        #20 begin
        if (error !== 1'b0) begin
            $display("FAIL BMP180: erro I2C inesperado");
            failed = 1'b1;
        end
        if (temperature_x10 !== 16'sd150) begin
            $display("FAIL BMP180: temperature_x10=%0d esperado=150", temperature_x10);
            failed = 1'b1;
        end
        if (pressure_pa !== 32'd69964) begin
            $display("FAIL BMP180: pressure_pa=%0d esperado=69964", pressure_pa);
            failed = 1'b1;
        end
        if (temperature_start_count < 1 || pressure_start_count < 1) begin
            $display("FAIL BMP180: sequencia de conversao incompleta temp=%0d press=%0d",
                     temperature_start_count, pressure_start_count);
            failed = 1'b1;
        end
        if (!busy) begin
            $display("FAIL BMP180: busy deveria permanecer alto na aquisicao continua");
            failed = 1'b1;
        end
        if (failed)
            $fatal(1, "tb_bmp180_controller: falha");
        $display("PASS tb_bmp180_controller: I2C, calibracao, UT/UP e compensacao validados");
        $finish;
        end
    end
endmodule
