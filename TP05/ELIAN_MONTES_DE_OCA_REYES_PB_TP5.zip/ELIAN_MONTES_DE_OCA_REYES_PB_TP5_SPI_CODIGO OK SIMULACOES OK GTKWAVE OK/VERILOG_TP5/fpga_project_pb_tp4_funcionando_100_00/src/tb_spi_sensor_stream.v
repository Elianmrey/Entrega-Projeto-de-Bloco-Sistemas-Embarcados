`timescale 1ns/1ps
// Regressao da falha fisica observada: o clock de leitura legado envia zeros no
// MOSI e deve receber telemetria em todas as transferencias, sem RSP_LEGACY.
module tb_spi_sensor_stream;
    reg sys_clk = 1'b0;
    reg rst_n = 1'b0;
    reg sclk = 1'b0;
    reg mosi = 1'b0;
    reg cs_n = 1'b1;
    wire miso;

    wire frame_valid, timeout_event, truncated_event, response_consumed;
    wire mosi_overrun_event;
    wire [7:0] command_byte;
    wire [111:0] rx_frame;
    wire [111:0] response_frame;
    wire response_available;
    wire ready, busy, command_accepted, response_valid, error, crc_valid;
    wire action_trigger, action_done;
    wire [7:0] status, sequence_number, output_control;
    wire [31:0] transaction_count, error_count, sample_count;

    reg sampled_miso;
    reg [111:0] first_rx, second_rx, third_rx;
    reg [111:0] command_phase_rx, ack_rx;
    integer i;
    localparam [111:0] SENSOR_FRAME =
        112'hA5_0123_0456_32_0077_0200_00018BCD;

    always #5 sys_clk = ~sys_clk;

    function [7:0] checksum13;
        input [111:0] f;
        begin
            checksum13 = f[111:104] ^ f[103:96] ^ f[95:88] ^ f[87:80] ^
                         f[79:72] ^ f[71:64] ^ f[63:56] ^ f[55:48] ^
                         f[47:40] ^ f[39:32] ^ f[31:24] ^ f[23:16] ^ f[15:8];
        end
    endfunction

    function [111:0] make_command;
        input [7:0] command_value;
        input [7:0] seq_value;
        reg [111:0] f;
        begin
            f = {8'hA5, 8'h01, command_value, seq_value, 8'd0, 64'd0, 8'h00};
            f[7:0] = checksum13(f);
            make_command = f;
        end
    endfunction

    spi_slave_pi4 #(.FRAME_TIMEOUT_CYCLES(500)) u_spi (
        .sys_clk(sys_clk), .rst_n(rst_n),
        .arm_spi_sclk(sclk), .arm_spi_mosi(mosi),
        .arm_spi_miso(miso), .arm_spi_cs_n(cs_n),
        .bmp_temp(16'h0123), .bmp_pressure_pa(32'h00018BCD),
        .lm35_temp_x10(16'h0456), .pot_percent(8'h32),
        .lm35_raw(16'h0077), .pot_raw(16'h0200),
        .response_frame(response_frame),
        .response_available(response_available),
        .mosi_sample_ready(1'b1), .mosi_sample_valid(),
        .mosi_sampled_bit(), .mosi_overrun_event(mosi_overrun_event),
        .frame_valid(frame_valid), .command_byte(command_byte),
        .rx_frame(rx_frame), .timeout_event(timeout_event),
        .truncated_event(truncated_event),
        .response_consumed(response_consumed)
    );

    tp5_protocol_controller #(.ACTION_CYCLES(8)) u_protocol (
        .clk(sys_clk), .rst_n(rst_n), .frame_event(frame_valid),
        .timeout_event(timeout_event), .truncated_event(truncated_event),
        .mosi_overrun_event(mosi_overrun_event),
        .response_consumed(response_consumed),
        .legacy_command(command_byte), .rx_frame(rx_frame),
        .bmp_temp(16'h0123), .bmp_pressure_pa(32'h00018BCD),
        .lm35_temp_x10(16'h0456), .pot_percent(8'h32),
        .lm35_raw(16'h0077), .pot_raw(16'h0200),
        .tp4_signature(16'h55AA), .mcp_valid(1'b0),
        .bmp_valid(1'b0), .dsp_valid(1'b0), .bmp_error(1'b0),
        .mcp_busy(1'b0), .bmp_busy(1'b0),
        .ready(ready), .busy(busy), .command_accepted(command_accepted),
        .response_valid(response_valid),
        .response_available(response_available), .error(error),
        .crc_valid(crc_valid), .action_trigger(action_trigger),
        .action_done(action_done), .status(status),
        .sequence_number(sequence_number), .output_control(output_control),
        .response_frame(response_frame),
        .transaction_count(transaction_count), .error_count(error_count),
        .sample_count(sample_count)
    );

    task transfer_bit;
        input tx_bit;
        output rx_bit;
        begin
            mosi = tx_bit;
            #80; sclk = 1'b1;
            #30; rx_bit = miso;
            #70; sclk = 1'b0;
            #100;
        end
    endtask

    task transfer_frame;
        input [111:0] tx;
        output [111:0] rx;
        begin
            rx = 112'd0;
            cs_n = 1'b0;
            #160;
            for (i = 0; i < 112; i = i + 1) begin
                transfer_bit(tx[111-i], sampled_miso);
                rx[111-i] = sampled_miso;
            end
            #100; cs_n = 1'b1;
            #300;
        end
    endtask

    task read_sensors;
        output [111:0] rx;
        begin
            transfer_frame(112'd0, rx);
        end
    endtask

    initial begin
        $dumpfile("build/tb_spi_sensor_stream.vcd");
        $dumpvars(0, tb_spi_sensor_stream);
        #40 rst_n = 1'b1;
        #100;

        read_sensors(first_rx);
        read_sensors(second_rx);
        read_sensors(third_rx);

        if (first_rx !== SENSOR_FRAME || second_rx !== SENSOR_FRAME ||
            third_rx !== SENSOR_FRAME)
            $fatal(1, "Fluxo contaminado: first=%h second=%h third=%h",
                   first_rx, second_rx, third_rx);
        if (response_available || response_valid)
            $fatal(1, "Leitura passiva deixou resposta TP5 pendente");
        if (transaction_count !== 32'd0 || error_count !== 32'd0)
            $fatal(1, "Leitura passiva alterou contadores: tx=%0d err=%0d",
                   transaction_count, error_count);

        // Caminho ativo usado pelo Assembly corrigido: comando + clocks neutros.
        transfer_frame(make_command(8'h7F, 8'h00), command_phase_rx);
        transfer_frame(112'd0, ack_rx);
        if (ack_rx[95:88] !== 8'h80 || ack_rx[87:80] !== 8'h00 ||
            ack_rx[71:64] !== 8'h7F || checksum13(ack_rx) !== ack_rx[7:0])
            $fatal(1, "ACK RESET_STATE invalido: %h", ack_rx);

        transfer_frame(make_command(8'h03, 8'h00), command_phase_rx);
        transfer_frame(112'd0, ack_rx);
        if (ack_rx[95:88] !== 8'h80 || ack_rx[87:80] !== 8'h00 ||
            ack_rx[71:64] !== 8'h03 || ack_rx[63:56] !== 8'h01 ||
            ack_rx[55:48] !== 8'h23 || ack_rx[47:40] !== 8'h04 ||
            ack_rx[39:32] !== 8'h56 || ack_rx[31:24] !== 8'h32 ||
            ack_rx[23:16] !== 8'h00 || ack_rx[15:8] !== 8'h77 ||
            checksum13(ack_rx) !== ack_rx[7:0])
            $fatal(1, "READ_SENSORS incorreto: %h", ack_rx);

        transfer_frame(make_command(8'h04, 8'h01), command_phase_rx);
        transfer_frame(112'd0, ack_rx);
        if (ack_rx[95:88] !== 8'h80 || ack_rx[87:80] !== 8'h01 ||
            ack_rx[71:64] !== 8'h04 || ack_rx[63:56] !== 8'h00 ||
            ack_rx[55:48] !== 8'h01 || ack_rx[47:40] !== 8'h8B ||
            ack_rx[39:32] !== 8'hCD || ack_rx[31:24] !== 8'h02 ||
            ack_rx[23:16] !== 8'h00 || checksum13(ack_rx) !== ack_rx[7:0])
            $fatal(1, "GET_TELEMETRY incorreto: %h", ack_rx);

        $display("PASS tb_spi_sensor_stream: fluxo passivo e aquisicao TP5 ativa preservam sensores");
        $finish;
    end
endmodule
