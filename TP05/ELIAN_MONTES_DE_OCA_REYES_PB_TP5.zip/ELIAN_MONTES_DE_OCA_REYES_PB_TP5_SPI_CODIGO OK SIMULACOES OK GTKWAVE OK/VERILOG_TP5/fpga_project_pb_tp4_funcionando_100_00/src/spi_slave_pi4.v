`timescale 1ns/1ps
// ============================================================================
// SPI slave dedicado a Raspberry Pi 4 / Raspberry Pi Zero 2W.
// Modo SPI 0: Raspberry Pi = master; Tang Nano 4K = slave.
//
// FRAME_SIZE = 14 bytes (112 bits):
//   [0]     = 0xA5
//   [1:2]   = BMP180 temperatura em 0,1 C (16 bits, signed)
//   [3:4]   = LM35 processado em 0,1 C (16 bits)
//   [5]     = potenciometro processado em % (8 bits)
//   [6:7]   = LM35 ADC bruto (16 bits; apenas 10 LSB validos)
//   [8:9]   = POT ADC bruto (16 bits; apenas 10 LSB validos)
//   [10:13] = BMP180 pressao compensada em Pa (32 bits, unsigned)
// A pressao e anexada ao final para nao modificar nenhum campo existente.
//
// TP5 adiciona recepcao integral, resposta protocolada e diagnostico de
// truncamento/timeout sem remover o frame legado de telemetria.
// A interface SPI externa continua totalmente independente do SPI do MCP3008.
//
// Handshake interno de amostragem MOSI:
//   mosi_sample_valid + mosi_sampled_bit apresentam cada bit capturado;
//   mosi_sample_ready confirma que o consumidor aceitou o bit;
//   mosi_overrun_event denuncia uma borda SPI enquanto ready estava baixo.
// Esse handshake e interno ao FPGA: o SPI fisico nao possui uma linha READY.
// ============================================================================
module spi_slave_pi4 #(
    // 30 ms a 27 MHz: margem sobre 11,2 ms do frame legado a 10 kHz.
    parameter integer FRAME_TIMEOUT_CYCLES = 810000
) (
    input  wire        sys_clk,
    input  wire        rst_n,
    input  wire        arm_spi_sclk,
    input  wire        arm_spi_mosi,
    output wire        arm_spi_miso,
    input  wire        arm_spi_cs_n,
    input  wire [15:0] bmp_temp,
    input  wire [31:0] bmp_pressure_pa,

    input  wire [15:0] lm35_temp_x10,
    input  wire [7:0]  pot_percent,
    input  wire [15:0] lm35_raw,
    input  wire [15:0] pot_raw,
    input  wire [111:0] response_frame,
    input  wire         response_available,
    input  wire         mosi_sample_ready,
    output reg          mosi_sample_valid,
    output reg          mosi_sampled_bit,
    output reg          mosi_overrun_event,
    output reg          frame_valid,
    output reg [7:0]    command_byte,
    output reg [111:0]  rx_frame,
    output reg          timeout_event,
    output reg          truncated_event,
    output reg          response_consumed
);
    reg sclk_meta, sclk_sync, sclk_prev;
    reg mosi_meta, mosi_sync;
    reg cs_meta, cs_sync, cs_prev;
    reg [111:0] tx_shift;
    reg [111:0] rx_shift;
    reg [7:0] bit_count;

    localparam integer TIMEOUT_W =
        (FRAME_TIMEOUT_CYCLES <= 2) ? 1 : $clog2(FRAME_TIMEOUT_CYCLES);
    reg [TIMEOUT_W-1:0] timeout_count;
    reg timeout_reported;

    reg miso_reg;

    wire cs_fall   = cs_prev && !cs_sync;
    wire cs_rise   = !cs_prev && cs_sync;
    wire sclk_rise = !sclk_prev && sclk_sync;
    wire sclk_fall = sclk_prev && !sclk_sync;

    assign arm_spi_miso = miso_reg;

    always @(posedge sys_clk or negedge rst_n) begin
        if (!rst_n) begin
            sclk_meta   <= 1'b0;
            sclk_sync   <= 1'b0;
            sclk_prev   <= 1'b0;
            mosi_meta   <= 1'b0;
            mosi_sync   <= 1'b0;
            cs_meta     <= 1'b1;
            cs_sync     <= 1'b1;
            cs_prev     <= 1'b1;
            tx_shift    <= 112'd0;
            rx_shift    <= 112'd0;
            bit_count   <= 8'd0;
            timeout_count <= {TIMEOUT_W{1'b0}};
            timeout_reported <= 1'b0;
            miso_reg    <= 1'b0;
            mosi_sample_valid <= 1'b0;
            mosi_sampled_bit <= 1'b0;
            mosi_overrun_event <= 1'b0;
            frame_valid <= 1'b0;
            command_byte <= 8'd0;
            rx_frame <= 112'd0;
            timeout_event <= 1'b0;
            truncated_event <= 1'b0;
            response_consumed <= 1'b0;
        end else begin
            sclk_meta <= arm_spi_sclk;
            sclk_sync <= sclk_meta;
            sclk_prev <= sclk_sync;

            mosi_meta <= arm_spi_mosi;
            mosi_sync <= mosi_meta;

            cs_meta <= arm_spi_cs_n;
            cs_sync <= cs_meta;
            cs_prev <= cs_sync;

            frame_valid <= 1'b0;
            timeout_event <= 1'b0;
            truncated_event <= 1'b0;
            response_consumed <= 1'b0;
            mosi_sample_valid <= 1'b0;
            mosi_overrun_event <= 1'b0;

            if (cs_sync) begin
                timeout_count <= {TIMEOUT_W{1'b0}};
                timeout_reported <= 1'b0;
            end else if (sclk_rise || sclk_fall) begin
                timeout_count <= {TIMEOUT_W{1'b0}};
            end else if (!timeout_reported) begin
                if ((FRAME_TIMEOUT_CYCLES <= 1) ||
                    (timeout_count == FRAME_TIMEOUT_CYCLES-1)) begin
                    timeout_event <= 1'b1;
                    timeout_reported <= 1'b1;
                end else begin
                    timeout_count <= timeout_count + 1'b1;
                end
            end

            if (cs_fall) begin
                // Frame de 112 bits transmitido MSB-first.
                if (response_available) begin
                    tx_shift <= response_frame;
                    miso_reg <= response_frame[111];
                    response_consumed <= 1'b1;
                end else begin
                    tx_shift <= {
                        8'hA5,
                        bmp_temp,
                        lm35_temp_x10,
                        pot_percent,
                        lm35_raw,
                        pot_raw,
                        bmp_pressure_pa
                    };
                    // MSB do 0xA5 pronto antes da primeira subida.
                    miso_reg <= 1'b1;
                end
                rx_shift  <= 112'd0;
                bit_count <= 8'd0;
            end else if (cs_rise) begin
                command_byte <= rx_shift[111:104];
                rx_frame <= rx_shift;
                frame_valid <= (bit_count == 8'd112);
                if ((bit_count != 8'd0) && (bit_count != 8'd112))
                    truncated_event <= 1'b1;

                miso_reg <= 1'b0;
            end else if (!cs_sync) begin
                if (sclk_rise) begin
                    // Internal valid/ready contract for each MOSI sample.
                    mosi_sample_valid <= 1'b1;
                    mosi_sampled_bit <= mosi_sync;
                    if (mosi_sample_ready) begin
                        rx_shift <= {rx_shift[110:0], mosi_sync};
                        if (bit_count != 8'd113)
                            bit_count <= bit_count + 1'b1;
                    end else begin
                        // A bit arrived while the consumer was not ready.
                        // Do not accept it; the protocol receives an error pulse.
                        mosi_overrun_event <= 1'b1;
                    end
                end

                if (sclk_fall) begin
                    tx_shift <= {tx_shift[110:0], 1'b0};
                    miso_reg <= tx_shift[110];
                end
            end
        end
    end
endmodule
