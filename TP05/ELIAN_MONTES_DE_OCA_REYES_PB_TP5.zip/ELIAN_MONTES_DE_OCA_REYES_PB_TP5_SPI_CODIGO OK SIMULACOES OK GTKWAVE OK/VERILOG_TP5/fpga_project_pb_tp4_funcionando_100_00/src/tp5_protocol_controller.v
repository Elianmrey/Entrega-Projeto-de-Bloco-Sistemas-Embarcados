`timescale 1ns/1ps
// ============================================================================
// TP5 protocol controller.
// Extensao aditiva do TP4: valida frames, controla handshake, executa comandos
// e prepara respostas. O frame fisico continua com 14 bytes para preservar a
// transferencia SPI e o frame de telemetria legado.
// ============================================================================
module tp5_protocol_controller #(
    parameter integer ACTION_CYCLES = 270000
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        frame_event,
    input  wire        timeout_event,
    input  wire        truncated_event,
    input  wire        mosi_overrun_event,
    input  wire        response_consumed,
    input  wire [7:0]  legacy_command,
    input  wire [111:0] rx_frame,

    input  wire signed [15:0] bmp_temp,
    input  wire [31:0] bmp_pressure_pa,
    input  wire [15:0] lm35_temp_x10,
    input  wire [7:0]  pot_percent,
    input  wire [15:0] lm35_raw,
    input  wire [15:0] pot_raw,
    input  wire [15:0] tp4_signature,
    input  wire        mcp_valid,
    input  wire        bmp_valid,
    input  wire        dsp_valid,
    input  wire        bmp_error,
    input  wire        mcp_busy,
    input  wire        bmp_busy,

    output reg         ready,
    output reg         busy,
    output reg         command_accepted,
    output reg         response_valid,
    output reg         response_available,
    output reg         error,
    output reg         crc_valid,
    output reg         action_trigger,
    output reg         action_done,
    output reg [7:0]   status,
    output reg [7:0]   sequence_number,
    output reg [7:0]   output_control,
    output reg [111:0] response_frame,
    output reg [31:0]  transaction_count,
    output reg [31:0]  error_count,
    output reg [31:0]  sample_count
);
    localparam [7:0] SOF = 8'hA5;
    localparam [7:0] VERSION = 8'h01;

    localparam [7:0] CMD_PING          = 8'h01;
    localparam [7:0] CMD_GET_STATUS    = 8'h02;
    localparam [7:0] CMD_READ_SENSORS  = 8'h03;
    localparam [7:0] CMD_GET_TELEMETRY = 8'h04;
    localparam [7:0] CMD_SET_OUTPUT    = 8'h10;
    localparam [7:0] CMD_CONTROL_MOTOR = 8'h11;
    localparam [7:0] CMD_RESET_STATE   = 8'h7F;

    localparam [7:0] RSP_ACK           = 8'h80;
    localparam [7:0] RSP_NACK          = 8'h81;
    localparam [7:0] RSP_BUSY          = 8'h82;
    localparam [7:0] RSP_LEGACY        = 8'h83;

    localparam [7:0] ERR_NONE          = 8'h00;
    localparam [7:0] ERR_SOF           = 8'h01;
    localparam [7:0] ERR_VERSION       = 8'h02;
    localparam [7:0] ERR_LENGTH        = 8'h03;
    localparam [7:0] ERR_CRC           = 8'h04;
    localparam [7:0] ERR_SEQUENCE      = 8'h05;
    localparam [7:0] ERR_UNKNOWN_CMD   = 8'h06;
    localparam [7:0] ERR_TIMEOUT       = 8'h07;
    localparam [7:0] ERR_TRUNCATED     = 8'h08;
    localparam [7:0] ERR_BUSY          = 8'h09;
    localparam [7:0] ERR_MOSI_OVERRUN  = 8'h0A;

    localparam [2:0] ST_READY    = 3'd0;
    localparam [2:0] ST_ACCEPTED = 3'd1;
    localparam [2:0] ST_BUSY     = 3'd2;
    localparam [2:0] ST_DONE     = 3'd3;
    localparam [2:0] ST_RESPONSE = 3'd4;
    localparam [2:0] ST_ERROR    = 3'd5;

    localparam integer ACTION_W = (ACTION_CYCLES <= 2) ? 1 : $clog2(ACTION_CYCLES);

    reg [2:0] state;
    reg [ACTION_W-1:0] action_count;
    reg [7:0] active_command;
    reg [7:0] active_sequence;
    reg [7:0] last_sequence;
    reg       sequence_initialized;
    reg       mcp_valid_d;
    reg       bmp_valid_d;
    reg       dsp_valid_d;

    wire [7:0] rx_sof     = rx_frame[111:104];
    wire [7:0] rx_version = rx_frame[103:96];
    wire [7:0] rx_command = rx_frame[95:88];
    wire [7:0] rx_sequence= rx_frame[87:80];
    wire [7:0] rx_length  = rx_frame[79:72];
    wire [7:0] rx_payload0= rx_frame[71:64];
    wire [7:0] rx_crc     = rx_frame[7:0];

    wire [7:0] sensor_flags = {
        2'b00, bmp_busy, mcp_busy, bmp_error, dsp_valid, bmp_valid, mcp_valid
    };

    function [7:0] checksum13;
        input [111:0] frame_value;
        integer i;
        reg [7:0] sum;
        begin
            sum = 8'd0;
            for (i = 13; i >= 1; i = i - 1)
                sum = sum ^ frame_value[i*8 +: 8];
            checksum13 = sum;
        end
    endfunction

    function [111:0] make_response;
        input [7:0] rsp_status;
        input [7:0] rsp_sequence;
        input [7:0] rsp_length;
        input [7:0] p0;
        input [7:0] p1;
        input [7:0] p2;
        input [7:0] p3;
        input [7:0] p4;
        input [7:0] p5;
        input [7:0] p6;
        input [7:0] p7;
        reg [111:0] f;
        reg [7:0] c;
        begin
            f = {SOF, VERSION, rsp_status, rsp_sequence, rsp_length,
                 p0, p1, p2, p3, p4, p5, p6, p7, 8'h00};
            c = f[111:104] ^ f[103:96] ^ f[95:88] ^ f[87:80] ^
                f[79:72] ^ f[71:64] ^ f[63:56] ^ f[55:48] ^
                f[47:40] ^ f[39:32] ^ f[31:24] ^ f[23:16] ^ f[15:8];
            f[7:0] = c;
            make_response = f;
        end
    endfunction

    task prepare_error;
        input [7:0] seq_value;
        input [7:0] error_code;
        begin
            status             <= RSP_NACK;
            sequence_number    <= seq_value;
            error              <= 1'b1;
            response_valid     <= 1'b1;
            response_available <= 1'b1;
            error_count        <= error_count + 1'b1;
            response_frame     <= make_response(
                RSP_NACK, seq_value, 8'd4,
                error_code, state, sensor_flags, output_control,
                8'd0, 8'd0, 8'd0, 8'd0
            );
        end
    endtask

    task prepare_ack;
        input [7:0] command_value;
        input [7:0] seq_value;
        input [7:0] control_value;
        begin
            status             <= RSP_ACK;
            sequence_number    <= seq_value;
            error              <= 1'b0;
            response_valid     <= 1'b1;
            response_available <= 1'b1;
            response_frame     <= make_response(
                RSP_ACK, seq_value, 8'd8,
                command_value, sensor_flags, {5'd0,state}, control_value,
                transaction_count[7:0], error_count[7:0], sample_count[7:0],
                tp4_signature[7:0]
            );
        end
    endtask

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state                <= ST_READY;
            action_count         <= {ACTION_W{1'b0}};
            active_command       <= 8'd0;
            active_sequence      <= 8'd0;
            last_sequence        <= 8'd0;
            sequence_initialized <= 1'b0;
            ready                <= 1'b1;
            busy                 <= 1'b0;
            command_accepted     <= 1'b0;
            response_valid       <= 1'b0;
            response_available   <= 1'b0;
            error                <= 1'b0;
            crc_valid            <= 1'b0;
            action_trigger       <= 1'b0;
            action_done          <= 1'b0;
            status               <= RSP_ACK;
            sequence_number      <= 8'd0;
            output_control       <= 8'd0;
            response_frame       <= 112'd0;
            transaction_count    <= 32'd0;
            error_count          <= 32'd0;
            sample_count         <= 32'd0;
            mcp_valid_d          <= 1'b0;
            bmp_valid_d          <= 1'b0;
            dsp_valid_d          <= 1'b0;
        end else begin
            command_accepted <= 1'b0;
            response_valid   <= 1'b0;
            action_trigger   <= 1'b0;
            action_done      <= 1'b0;
            crc_valid        <= 1'b0;
            mcp_valid_d      <= mcp_valid;
            bmp_valid_d      <= bmp_valid;
            dsp_valid_d      <= dsp_valid;

            if (response_consumed)
                response_available <= 1'b0;

            if ((mcp_valid && !mcp_valid_d) ||
                (bmp_valid && !bmp_valid_d) ||
                (dsp_valid && !dsp_valid_d))
                sample_count <= sample_count + 1'b1;

            if (timeout_event) begin
                prepare_error(active_sequence, ERR_TIMEOUT);
                ready <= !busy;
                state <= busy ? ST_BUSY : ST_ERROR;
            end else if (truncated_event) begin
                prepare_error(active_sequence, ERR_TRUNCATED);
                ready <= !busy;
                state <= busy ? ST_BUSY : ST_ERROR;
            end else if (mosi_overrun_event) begin
                // Handshake interno MOSI: uma amostra chegou sem ready.
                prepare_error(active_sequence, ERR_MOSI_OVERRUN);
                ready <= !busy;
                state <= busy ? ST_BUSY : ST_ERROR;
            end else if (frame_event && (rx_frame == 112'd0)) begin
                // O monitor legado le os sensores transmitindo 14 bytes zero.
                // Isso e clock de leitura, nao um comando: nunca enfileirar uma
                // resposta TP5, pois ela substituiria a telemetria na proxima
                // transferencia full-duplex.
                ready <= !busy;
            end else if (frame_event) begin
                crc_valid <= (checksum13(rx_frame) == rx_crc);

                if (busy) begin
                    status             <= RSP_BUSY;
                    sequence_number    <= rx_sequence;
                    error              <= 1'b1;
                    response_valid     <= 1'b1;
                    response_available <= 1'b1;
                    error_count        <= error_count + 1'b1;
                    response_frame     <= make_response(
                        RSP_BUSY, rx_sequence, 8'd4,
                        ERR_BUSY, active_command, {5'd0,state}, output_control,
                        8'd0, 8'd0, 8'd0, 8'd0
                    );
                end else if ((rx_sof != SOF) && (rx_version == VERSION)) begin
                    prepare_error(rx_sequence, ERR_SOF);
                    ready <= 1'b1;
                    state <= ST_ERROR;
                end else if ((rx_sof == SOF) && (rx_version != VERSION)) begin
                    prepare_error(rx_sequence, ERR_VERSION);
                    ready <= 1'b1;
                    state <= ST_ERROR;
                end else if ((rx_sof != SOF) || (rx_version != VERSION)) begin
                    // Compatibilidade TP4 para comandos legados nao nulos.
                    status             <= RSP_LEGACY;
                    sequence_number    <= 8'd0;
                    error              <= 1'b0;
                    response_valid     <= 1'b1;
                    response_available <= 1'b1;
                    transaction_count  <= transaction_count + 1'b1;
                    response_frame     <= make_response(
                        RSP_LEGACY, 8'd0, 8'd2,
                        legacy_command, ERR_NONE, 8'd0, 8'd0,
                        8'd0, 8'd0, 8'd0, 8'd0
                    );
                    ready <= 1'b1;
                    state <= ST_RESPONSE;
                end else if (rx_length > 8) begin
                    prepare_error(rx_sequence, ERR_LENGTH);
                    ready <= 1'b1;
                    state <= ST_ERROR;
                end else if (((rx_command == CMD_SET_OUTPUT) ||
                              (rx_command == CMD_CONTROL_MOTOR)) &&
                             (rx_length != 8'd1)) begin
                    prepare_error(rx_sequence, ERR_LENGTH);
                    ready <= 1'b1;
                    state <= ST_ERROR;
                end else if (((rx_command == CMD_PING) ||
                              (rx_command == CMD_GET_STATUS) ||
                              (rx_command == CMD_READ_SENSORS) ||
                              (rx_command == CMD_GET_TELEMETRY) ||
                              (rx_command == CMD_RESET_STATE)) &&
                             (rx_length != 8'd0)) begin
                    prepare_error(rx_sequence, ERR_LENGTH);
                    ready <= 1'b1;
                    state <= ST_ERROR;
                end else if (checksum13(rx_frame) != rx_crc) begin
                    prepare_error(rx_sequence, ERR_CRC);
                    ready <= 1'b1;
                    state <= ST_ERROR;
                end else if ((rx_command != CMD_RESET_STATE) &&
                             sequence_initialized &&
                             (rx_sequence != (last_sequence + 1'b1))) begin
                    prepare_error(rx_sequence, ERR_SEQUENCE);
                    ready <= 1'b1;
                    state <= ST_ERROR;
                end else begin
                    command_accepted     <= 1'b1;
                    transaction_count    <= transaction_count + 1'b1;
                    last_sequence        <= rx_sequence;
                    sequence_initialized <= 1'b1;
                    active_command       <= rx_command;
                    active_sequence      <= rx_sequence;
                    error                <= 1'b0;
                    state                <= ST_ACCEPTED;

                    case (rx_command)
                        CMD_PING: begin
                            prepare_ack(rx_command, rx_sequence, output_control);
                            ready <= 1'b1;
                            busy  <= 1'b0;
                            state <= ST_RESPONSE;
                        end

                        CMD_GET_STATUS: begin
                            status             <= RSP_ACK;
                            sequence_number    <= rx_sequence;
                            response_valid     <= 1'b1;
                            response_available <= 1'b1;
                            response_frame     <= make_response(
                                RSP_ACK, rx_sequence, 8'd8,
                                rx_command, sensor_flags, {5'd0,state}, output_control,
                                transaction_count[15:8], transaction_count[7:0],
                                error_count[7:0], last_sequence
                            );
                            ready <= 1'b1;
                            busy  <= 1'b0;
                            state <= ST_RESPONSE;
                        end

                        CMD_READ_SENSORS: begin
                            status             <= RSP_ACK;
                            sequence_number    <= rx_sequence;
                            response_valid     <= 1'b1;
                            response_available <= 1'b1;
                            response_frame     <= make_response(
                                RSP_ACK, rx_sequence, 8'd8,
                                rx_command, bmp_temp[15:8], bmp_temp[7:0],
                                lm35_temp_x10[15:8], lm35_temp_x10[7:0],
                                pot_percent, lm35_raw[15:8], lm35_raw[7:0]
                            );
                            ready <= 1'b1;
                            busy  <= 1'b0;
                            state <= ST_RESPONSE;
                        end

                        CMD_GET_TELEMETRY: begin
                            status             <= RSP_ACK;
                            sequence_number    <= rx_sequence;
                            response_valid     <= 1'b1;
                            response_available <= 1'b1;
                            response_frame     <= make_response(
                                RSP_ACK, rx_sequence, 8'd8,
                                rx_command, bmp_pressure_pa[31:24],
                                bmp_pressure_pa[23:16], bmp_pressure_pa[15:8],
                                bmp_pressure_pa[7:0], pot_raw[15:8],
                                pot_raw[7:0], tp4_signature[7:0]
                            );
                            ready <= 1'b1;
                            busy  <= 1'b0;
                            state <= ST_RESPONSE;
                        end

                        CMD_SET_OUTPUT,
                        CMD_CONTROL_MOTOR: begin
                            output_control <= rx_payload0;
                            action_trigger <= 1'b1;
                            action_count   <= {ACTION_W{1'b0}};
                            ready          <= 1'b0;
                            busy           <= 1'b1;
                            prepare_ack(rx_command, rx_sequence, rx_payload0);
                            state          <= ST_BUSY;
                        end

                        CMD_RESET_STATE: begin
                            output_control       <= 8'd0;
                            action_trigger       <= 1'b1;
                            action_done          <= 1'b1;
                            sequence_initialized <= 1'b0;
                            prepare_ack(rx_command, rx_sequence, 8'd0);
                            ready <= 1'b1;
                            busy  <= 1'b0;
                            state <= ST_DONE;
                        end

                        default: begin
                            prepare_error(rx_sequence, ERR_UNKNOWN_CMD);
                            ready <= 1'b1;
                            busy  <= 1'b0;
                            state <= ST_ERROR;
                        end
                    endcase
                end
            end else begin
                case (state)
                    ST_BUSY: begin
                        ready <= 1'b0;
                        busy  <= 1'b1;
                        if ((ACTION_CYCLES <= 1) ||
                            (action_count == ACTION_CYCLES-1)) begin
                            action_done      <= 1'b1;
                            action_count     <= {ACTION_W{1'b0}};
                            ready            <= 1'b1;
                            busy             <= 1'b0;
                            if (!response_available) begin
                                response_valid   <= 1'b1;
                                response_available <= 1'b1;
                                response_frame   <= make_response(
                                    RSP_ACK, active_sequence, 8'd4,
                                    active_command, output_control, ERR_NONE, 8'h01,
                                    8'd0, 8'd0, 8'd0, 8'd0
                                );
                            end
                            state <= ST_DONE;
                        end else begin
                            action_count <= action_count + 1'b1;
                        end
                    end
                    ST_ACCEPTED: state <= ST_RESPONSE;
                    ST_DONE:     state <= ST_RESPONSE;
                    ST_ERROR: begin
                        ready <= 1'b1;
                        state <= ST_RESPONSE;
                    end
                    ST_RESPONSE: begin
                        ready <= 1'b1;
                        state <= ST_READY;
                    end
                    default: begin
                        ready <= 1'b1;
                        busy  <= 1'b0;
                        state <= ST_READY;
                    end
                endcase
            end
        end
    end
endmodule
