# TP5 timing constraints — GW1NSR-LV4CQN48PC6/I5
#
# Fonte principal: os parâmetros do RTL e SPI_SPEED_HZ=10000 no Assembly.
# sys_clk: 27 MHz => T=37.037 ns.
# TP4 PLL: 27 MHz -> 54 MHz => T=18.5185 ns.
# SPI externo: 10 kHz => T=100000 ns.
#
# Importante: 20 ns e o periodo de 50 MHz, nao uma defasagem configurada
# neste projeto. O PLL possui FDLY=0 e nao ha phase shift de 20 ns declarado.

create_clock -name sys_clk -period 37.037 -waveform {0.000 18.5185} [get_ports {sys_clk}]

# arm_spi_sclk e um clock externo amostrado por sincronizadores no dominio
# sys_clk; a constraint permite analisar as entradas/saidas do barramento.
create_clock -name arm_spi_sclk -period 100000.000 -waveform {0.000 50000.000} [get_ports {arm_spi_sclk}]
# Gowin SDC: -clock recebe o nome diretamente, seguido do atraso e das portas.
# A forma [get_clocks arm_spi_sclk] nao e aceita neste argumento pelo TA2000.
set_input_delay -clock arm_spi_sclk 10.000 [get_ports {arm_spi_mosi}]
set_input_delay -clock arm_spi_sclk 10.000 [get_ports {arm_spi_cs_n}]
set_output_delay -clock arm_spi_sclk 10.000 [get_ports {arm_spi_miso}]

# O PLL TP4 e instanciado no RTL com o primitivo PLLVR e possui clock interno
# reconhecido pelo fluxo Gowin. Nao criamos aqui uma generated clock manual:
# o pino interno u_pllvr/CLKOUT nao e um objeto constraintavel pelo TA2000 neste
# projeto e gerava TA2003/TA1052. O clock principal continua explicitamente
# constrangido acima, sem modificar o RTL ou o funcionamento do PLL.
#
# SPI externo nao e derivado de sys_clk; as entradas sao sincronizadas
# explicitamente no dominio sys_clk.
set_clock_groups -asynchronous -group [get_clocks {arm_spi_sclk}] -group [get_clocks {sys_clk}]

# Margem conservadora para jitter/variação de implementação no clock principal.
set_clock_uncertainty -setup -from sys_clk -to sys_clk 0.500
set_clock_uncertainty -hold -from sys_clk -to sys_clk 0.200
