`timescale 1ns/1ps
// Testbench de handshake MOSI:
// 1) ready=1 aceita 112 amostras validas;
// 2) ready=0 durante uma borda gera overrun;
// 3) o protocolo converte o overrun em NACK com ERR_MOSI_OVERRUN=0x0A.
module tb_mosi_handshake_fault;
    reg sys_clk = 1'b0;
    reg rst_n = 1'b0;
    reg sclk = 1'b0;
    reg mosi = 1'b0;
    reg cs_n = 1'b1;
    reg mosi_sample_ready = 1'b1;

    wire miso;
    wire mosi_sample_valid;
    wire mosi_sampled_bit;
    wire mosi_overrun_event;
    wire frame_valid, timeout_event, truncated_event, response_consumed;
    wire [7:0] command_byte;
    wire [111:0] rx_frame;

    wire [111:0] response_frame;
    wire response_available;
    wire ready, busy, command_accepted, response_valid, error, crc_valid;
    wire action_trigger, action_done;
    wire [7:0] status, sequence_number, output_control;
    wire [31:0] transaction_count, error_count, sample_count;

    integer i;
    integer accepted_samples;
    reg saw_overrun;
    reg saw_nack_overrun;
    reg sampled_miso;

    always #5 sys_clk = ~sys_clk;

    spi_slave_pi4 #(.FRAME_TIMEOUT_CYCLES(500)) u_spi (
        .sys_clk(sys_clk), .rst_n(rst_n),
        .arm_spi_sclk(sclk), .arm_spi_mosi(mosi),
        .arm_spi_miso(miso), .arm_spi_cs_n(cs_n),
        .bmp_temp(16'h0123), .bmp_pressure_pa(32'h00018BCD),
        .lm35_temp_x10(16'h0456), .pot_percent(8'h32),
        .lm35_raw(16'h0077), .pot_raw(16'h0200),
        .response_frame(response_frame),
        .response_available(response_available),
        .mosi_sample_ready(mosi_sample_ready),
        .mosi_sample_valid(mosi_sample_valid),
        .mosi_sampled_bit(mosi_sampled_bit),
        .mosi_overrun_event(mosi_overrun_event),
        .frame_valid(frame_valid), .command_byte(command_byte),
        .rx_frame(rx_frame), .timeout_event(timeout_event),
        .truncated_event(truncated_event),
        .response_consumed(response_consumed)
    );

    tp5_protocol_controller #(.ACTION_CYCLES(8)) u_protocol (
        .clk(sys_clk), .rst_n(rst_n), .frame_event(frame_valid),
        .timeout_event(timeout_event), .truncated_event(truncated_event),
        .mosi_overrun_event(mosi_overrun_event),
        .response_consumed(response_consumed),
        .legacy_command(command_byte), .rx_frame(rx_frame),
        .bmp_temp(16'h0123), .bmp_pressure_pa(32'h00018BCD),
        .lm35_temp_x10(16'h0456), .pot_percent(8'h32),
        .lm35_raw(16'h0077), .pot_raw(16'h0200),
        .tp4_signature(16'h55AA), .mcp_valid(1'b0),
        .bmp_valid(1'b0), .dsp_valid(1'b0), .bmp_error(1'b0),
        .mcp_busy(1'b0), .bmp_busy(1'b0),
        .ready(ready), .busy(busy), .command_accepted(command_accepted),
        .response_valid(response_valid), .response_available(response_available),
        .error(error), .crc_valid(crc_valid),
        .action_trigger(action_trigger), .action_done(action_done),
        .status(status), .sequence_number(sequence_number),
        .output_control(output_control), .response_frame(response_frame),
        .transaction_count(transaction_count), .error_count(error_count),
        .sample_count(sample_count)
    );

    always @(posedge sys_clk) begin
        if (mosi_sample_valid && mosi_sample_ready)
            accepted_samples <= accepted_samples + 1;
        if (mosi_overrun_event)
            saw_overrun <= 1'b1;
        if (response_valid && response_frame[95:88] == 8'h81 &&
            response_frame[71:64] == 8'h0A)
            saw_nack_overrun <= 1'b1;
    end

    task transfer_bit;
        input tx_bit;
        output rx_bit;
        begin
            mosi = tx_bit;
            #80; sclk = 1'b1;
            #30; rx_bit = miso;
            #70; sclk = 1'b0;
            #100;
        end
    endtask

    initial begin
        $dumpfile("build/tb_mosi_handshake_fault.vcd");
        $dumpvars(0, tb_mosi_handshake_fault);
        accepted_samples = 0;
        saw_overrun = 1'b0;
        saw_nack_overrun = 1'b0;

        #40 rst_n = 1'b1;
        #100;

        // Caminho normal: todas as amostras sao aceitas pelo handshake.
        cs_n = 1'b0;
        #160;
        for (i = 0; i < 112; i = i + 1)
            transfer_bit((i == 0) ? 1'b1 : 1'b0, sampled_miso);
        #100;
        cs_n = 1'b1;
        #180;

        if (accepted_samples !== 112)
            $fatal(1, "Handshake normal perdeu amostras: aceitas=%0d", accepted_samples);
        if (!frame_valid && !u_spi.frame_valid)
            $display("INFO: frame_valid e pulso; caminho normal concluido");

        // Falha injetada: uma borda chega com ready=0.
        mosi_sample_ready = 1'b0;
        saw_overrun = 1'b0;
        saw_nack_overrun = 1'b0;
        cs_n = 1'b0;
        #160;
        transfer_bit(1'b1, sampled_miso);
        #100;
        cs_n = 1'b1;
        #240;

        if (!saw_overrun)
            $fatal(1, "Falha: overrun MOSI nao foi detectado");
        if (!saw_nack_overrun)
            $fatal(1, "Falha: protocolo nao gerou NACK ERR_MOSI_OVERRUN=0x0A");

        $display("PASS tb_mosi_handshake_fault: valid/ready, overrun MOSI e NACK 0x0A");
        $finish;
    end
endmodule
