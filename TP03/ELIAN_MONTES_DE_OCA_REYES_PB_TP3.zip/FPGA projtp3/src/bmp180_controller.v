`timescale 1ns/1ps
// Controlador I2C para a leitura da temperatura não compensada (UT) do BMP180.
// Sequência: START, 0xEE, 0xF4, 0x2E, STOP, espera,
// START, 0xEF, MSB/ACK, LSB/NACK, STOP.
// SDA e SCL são open-drain: 0 conduz ao GND; 1 libera a linha.
module bmp180_controller #(
    parameter integer CLK_HZ = 27_000_000,
    parameter integer I2C_HZ = 100_000,
    parameter integer PERIOD_TICKS = 27_000_000,
    parameter integer CONVERSION_TICKS = 121_500
)(
    input  wire        clk,
    input  wire        rst_n,
    inout  wire        sda,
    inout  wire        scl,
    output reg  [15:0] temp_out,
    output reg         data_valid,
    output reg         busy,
    output reg         error
);
    localparam integer DIV_TICK = (CLK_HZ / (4 * I2C_HZ) < 1) ? 1 : (CLK_HZ / (4 * I2C_HZ));
    localparam integer DIV_W = (DIV_TICK <= 2) ? 1 : $clog2(DIV_TICK);
    localparam integer MAX_TICKS = (PERIOD_TICKS > CONVERSION_TICKS) ? PERIOD_TICKS : CONVERSION_TICKS;
    localparam integer TIMER_W = (MAX_TICKS <= 2) ? 1 : $clog2(MAX_TICKS);

    localparam [4:0]
        S_IDLE         = 5'd0,
        S_START        = 5'd1,
        S_SEND         = 5'd2,
        S_ACK          = 5'd3,
        S_STOP         = 5'd4,
        S_WAIT_CONV    = 5'd5,
        S_RECV_MSB     = 5'd6,
        S_MASTER_ACK   = 5'd7,
        S_RECV_LSB     = 5'd8,
        S_MASTER_NACK  = 5'd9;

    localparam [2:0]
        ACK_ADDR_W   = 3'd0,
        ACK_REG      = 3'd1,
        ACK_CMD      = 3'd2,
        ACK_ADDR_PTR = 3'd3,
        ACK_REG_PTR  = 3'd4,
        ACK_ADDR_R   = 3'd5;

    localparam [1:0]
        STOP_TO_WAIT = 2'd0,
        STOP_TO_IDLE = 2'd1;

    reg [4:0] state;
    reg [1:0] phase;
    reg [2:0] ack_action;
    reg [1:0] stop_target;
    reg ack_ok;
    reg [3:0] bit_cnt;
    reg [7:0] tx_byte;
    reg [7:0] rx_msb;
    reg [7:0] rx_lsb;
    reg [DIV_W-1:0] div_cnt;
    reg [TIMER_W-1:0] timer;
    reg sda_low;
    reg scl_low;

    wire tick = (div_cnt == DIV_TICK - 1);

    assign sda = sda_low ? 1'b0 : 1'bz;
    assign scl = scl_low ? 1'b0 : 1'bz;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state       <= S_IDLE;
            phase       <= 2'd0;
            ack_action  <= ACK_ADDR_W;
            stop_target <= STOP_TO_WAIT;
            ack_ok      <= 1'b0;
            bit_cnt     <= 4'd0;
            tx_byte     <= 8'd0;
            rx_msb      <= 8'd0;
            rx_lsb      <= 8'd0;
            div_cnt     <= {DIV_W{1'b0}};
            timer       <= {TIMER_W{1'b0}};
            sda_low     <= 1'b0;
            scl_low     <= 1'b0;
            temp_out    <= 16'd0;
            data_valid  <= 1'b0;
            busy        <= 1'b0;
            error       <= 1'b0;
        end else begin
            data_valid <= 1'b0;

            if (state == S_IDLE) begin
                div_cnt <= {DIV_W{1'b0}};
                phase   <= 2'd0;
                sda_low <= 1'b0;
                scl_low <= 1'b0;
                busy    <= 1'b0;
                if (timer == PERIOD_TICKS - 1) begin
                    timer      <= {TIMER_W{1'b0}};
                    busy       <= 1'b1;
                    error      <= 1'b0;
                    tx_byte    <= 8'hEE;
                    bit_cnt    <= 4'd7;
                    ack_action <= ACK_ADDR_W;
                    state      <= S_START;
                end else begin
                    timer <= timer + 1'b1;
                end
            end else if (state == S_WAIT_CONV) begin
                div_cnt <= {DIV_W{1'b0}};
                phase   <= 2'd0;
                sda_low <= 1'b0;
                scl_low <= 1'b0;
                if (timer == CONVERSION_TICKS - 1) begin
                    timer      <= {TIMER_W{1'b0}};
                    // Após a conversão, posicione o ponteiro em F6 antes da leitura.
                    tx_byte    <= 8'hEE;
                    bit_cnt    <= 4'd7;
                    ack_action <= ACK_ADDR_PTR;
                    state      <= S_START;
                end else begin
                    timer <= timer + 1'b1;
                end
            end else if (tick) begin
                div_cnt <= {DIV_W{1'b0}};
                case (state)
                    // START: SDA é puxado para baixo enquanto SCL está alto.
                    S_START: begin
                        case (phase)
                            2'd0: begin sda_low <= 1'b0; scl_low <= 1'b0; phase <= 2'd1; end
                            2'd1: begin sda_low <= 1'b1; scl_low <= 1'b0; phase <= 2'd2; end
                            2'd2: begin sda_low <= 1'b1; scl_low <= 1'b1; phase <= 2'd3; end
                            default: begin phase <= 2'd0; state <= S_SEND; end
                        endcase
                    end

                    // Envia um byte MSB primeiro. O dado só muda com SCL baixo.
                    S_SEND: begin
                        case (phase)
                            2'd0: begin sda_low <= ~tx_byte[bit_cnt]; scl_low <= 1'b1; phase <= 2'd1; end
                            2'd1: begin sda_low <= ~tx_byte[bit_cnt]; scl_low <= 1'b0; phase <= 2'd2; end
                            2'd2: begin sda_low <= ~tx_byte[bit_cnt]; scl_low <= 1'b0; phase <= 2'd3; end
                            default: begin
                                scl_low <= 1'b1;
                                phase <= 2'd0;
                                if (bit_cnt == 0) state <= S_ACK;
                                else bit_cnt <= bit_cnt - 1'b1;
                            end
                        endcase
                    end

                    // Libera SDA e verifica o ACK durante SCL alto.
                    S_ACK: begin
                        case (phase)
                            2'd0: begin sda_low <= 1'b0; scl_low <= 1'b1; phase <= 2'd1; end
                            2'd1: begin sda_low <= 1'b0; scl_low <= 1'b0; phase <= 2'd2; end
                            2'd2: begin sda_low <= 1'b0; scl_low <= 1'b0; ack_ok <= (sda === 1'b0); phase <= 2'd3; end
                            default: begin
                                scl_low <= 1'b1;
                                phase <= 2'd0;
                                if (!ack_ok) begin
                                    error       <= 1'b1;
                                    stop_target <= STOP_TO_IDLE;
                                    state       <= S_STOP;
                                end else begin
                                    case (ack_action)
                                        ACK_ADDR_W: begin tx_byte <= 8'hF4; bit_cnt <= 4'd7; ack_action <= ACK_REG; state <= S_SEND; end
                                        ACK_REG:    begin tx_byte <= 8'h2E; bit_cnt <= 4'd7; ack_action <= ACK_CMD; state <= S_SEND; end
                                        ACK_CMD:    begin stop_target <= STOP_TO_WAIT; state <= S_STOP; end
                                        // Nova transação: escrita do ponteiro F6.
                                        ACK_ADDR_PTR: begin tx_byte <= 8'hF6; bit_cnt <= 4'd7; ack_action <= ACK_REG_PTR; state <= S_SEND; end
                                        // Repeated START seguido do endereço de leitura 0xEF.
                                        ACK_REG_PTR: begin tx_byte <= 8'hEF; bit_cnt <= 4'd7; ack_action <= ACK_ADDR_R; state <= S_START; end
                                        ACK_ADDR_R: begin bit_cnt <= 4'd7; rx_msb <= 8'd0; state <= S_RECV_MSB; end
                                        default: begin error <= 1'b1; stop_target <= STOP_TO_IDLE; state <= S_STOP; end
                                    endcase
                                end
                            end
                        endcase
                    end

                    // Recebe o MSB e amostra SDA enquanto SCL permanece alto.
                    S_RECV_MSB: begin
                        case (phase)
                            2'd0: begin sda_low <= 1'b0; scl_low <= 1'b1; phase <= 2'd1; end
                            2'd1: begin sda_low <= 1'b0; scl_low <= 1'b0; phase <= 2'd2; end
                            2'd2: begin sda_low <= 1'b0; scl_low <= 1'b0; rx_msb[bit_cnt] <= sda; phase <= 2'd3; end
                            default: begin
                                scl_low <= 1'b1;
                                phase <= 2'd0;
                                if (bit_cnt == 0) state <= S_MASTER_ACK;
                                else bit_cnt <= bit_cnt - 1'b1;
                            end
                        endcase
                    end

                    // ACK do mestre após o MSB, requisitando o LSB.
                    S_MASTER_ACK: begin
                        case (phase)
                            2'd0: begin sda_low <= 1'b1; scl_low <= 1'b1; phase <= 2'd1; end
                            2'd1: begin sda_low <= 1'b1; scl_low <= 1'b0; phase <= 2'd2; end
                            2'd2: begin sda_low <= 1'b1; scl_low <= 1'b0; phase <= 2'd3; end
                            default: begin scl_low <= 1'b1; phase <= 2'd0; bit_cnt <= 4'd7; rx_lsb <= 8'd0; state <= S_RECV_LSB; end
                        endcase
                    end

                    // Recebe o LSB e amostra SDA enquanto SCL permanece alto.
                    S_RECV_LSB: begin
                        case (phase)
                            2'd0: begin sda_low <= 1'b0; scl_low <= 1'b1; phase <= 2'd1; end
                            2'd1: begin sda_low <= 1'b0; scl_low <= 1'b0; phase <= 2'd2; end
                            2'd2: begin sda_low <= 1'b0; scl_low <= 1'b0; rx_lsb[bit_cnt] <= sda; phase <= 2'd3; end
                            default: begin
                                scl_low <= 1'b1;
                                phase <= 2'd0;
                                if (bit_cnt == 0) state <= S_MASTER_NACK;
                                else bit_cnt <= bit_cnt - 1'b1;
                            end
                        endcase
                    end

                    // NACK após o LSB encerra a leitura.
                    S_MASTER_NACK: begin
                        case (phase)
                            2'd0: begin sda_low <= 1'b0; scl_low <= 1'b1; phase <= 2'd1; end
                            2'd1: begin sda_low <= 1'b0; scl_low <= 1'b0; phase <= 2'd2; end
                            2'd2: begin sda_low <= 1'b0; scl_low <= 1'b0; phase <= 2'd3; end
                            default: begin scl_low <= 1'b1; phase <= 2'd0; stop_target <= STOP_TO_IDLE; state <= S_STOP; end
                        endcase
                    end

                    // STOP: SDA sobe enquanto SCL está alto.
                    S_STOP: begin
                        case (phase)
                            2'd0: begin sda_low <= 1'b1; scl_low <= 1'b1; phase <= 2'd1; end
                            2'd1: begin sda_low <= 1'b1; scl_low <= 1'b0; phase <= 2'd2; end
                            2'd2: begin sda_low <= 1'b0; scl_low <= 1'b0; phase <= 2'd3; end
                            default: begin
                                sda_low <= 1'b0;
                                scl_low <= 1'b0;
                                phase <= 2'd0;
                                if (stop_target == STOP_TO_WAIT) begin
                                    timer <= {TIMER_W{1'b0}};
                                    state <= S_WAIT_CONV;
                                end else begin
                                    if (!error) begin
                                        temp_out <= {rx_msb, rx_lsb};
                                        data_valid <= 1'b1;
                                    end
                                    state <= S_IDLE;
                                end
                            end
                        endcase
                    end

                    default: begin state <= S_IDLE; phase <= 2'd0; sda_low <= 1'b0; scl_low <= 1'b0; end
                endcase
            end else begin
                div_cnt <= div_cnt + 1'b1;
            end
        end
    end
endmodule
