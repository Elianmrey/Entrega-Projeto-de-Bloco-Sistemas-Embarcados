`timescale 1ns/1ps
// Controlador SPI Mode 0 para MCP3008.
// Cada conversão utiliza 16 ciclos de SCLK:
// cinco bits de comando, um bit nulo e dez bits de resultado D9..D0.
module mcp3008_controller #(
    parameter integer CLK_HZ = 27_000_000,
    parameter integer SPI_HZ = 500_000,
    parameter integer SAMPLE_PERIOD = 1_350_000
)(
    input  wire clk,
    input  wire rst_n,
    output reg  spi_cs_n,
    output reg  spi_sclk,
    output reg  spi_mosi,
    input  wire spi_miso,
    output reg [9:0] ch0_data,
    output reg [9:0] ch7_data,
    output reg       data_valid,
    output reg       busy
);
    localparam integer DIV_HALF = (CLK_HZ/(2*SPI_HZ) < 1) ? 1 : CLK_HZ/(2*SPI_HZ);
    localparam integer DIV_W = (DIV_HALF <= 2) ? 1 : $clog2(DIV_HALF);
    localparam integer TIMER_W = (SAMPLE_PERIOD <= 2) ? 1 : $clog2(SAMPLE_PERIOD+1);

    // A primeira amostra útil, D9, ocorre na sétima borda de subida:
    // bordas 1..5 = comando; borda 6 = bit nulo; bordas 7..16 = D9..D0.
    localparam [4:0] ADC_DATA_FIRST_RISE = 5'd6;
    localparam [4:0] ADC_LAST_RISE       = 5'd15;

    localparam [2:0] IDLE     = 3'd0,
                     START    = 3'd1,
                     TRANSFER = 3'd2,
                     FINISH   = 3'd3;

    reg [2:0] state;
    reg [DIV_W-1:0] div_cnt;
    reg [TIMER_W-1:0] sample_timer;
    reg [4:0] edge_count;
    reg [15:0] tx_shift;
    reg [9:0] rx_shift;
    reg channel;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state        <= IDLE;
            div_cnt      <= 0;
            sample_timer <= 0;
            edge_count   <= 0;
            tx_shift     <= 0;
            rx_shift     <= 0;
            channel      <= 1'b0;
            spi_cs_n     <= 1'b1;
            spi_sclk     <= 1'b0;
            spi_mosi     <= 1'b0;
            ch0_data     <= 10'd0;
            ch7_data     <= 10'd0;
            data_valid   <= 1'b0;
            busy         <= 1'b0;
        end else begin
            data_valid <= 1'b0;

            case (state)
                IDLE: begin
                    spi_cs_n <= 1'b1;
                    spi_sclk <= 1'b0;
                    busy     <= 1'b0;
                    if (sample_timer == SAMPLE_PERIOD-1) begin
                        sample_timer <= 0;
                        state        <= START;
                        busy         <= 1'b1;
                    end else begin
                        sample_timer <= sample_timer + 1'b1;
                    end
                end

                START: begin
                    spi_cs_n   <= 1'b0;
                    spi_sclk   <= 1'b0;
                    edge_count <= 0;
                    rx_shift   <= 10'd0;
                    div_cnt    <= 0;

                    // Comando MCP3008: START=1, SGL/DIFF=1, D2..D0.
                    // CH0: 11000; CH7: 11111. O primeiro bit já fica
                    // disponível antes da primeira borda de subida de SCLK.
                    if (channel == 1'b0)
                        tx_shift <= {5'b11000, 11'b0};
                    else
                        tx_shift <= {5'b11111, 11'b0};
                    spi_mosi <= 1'b1;
                    state    <= TRANSFER;
                end

                TRANSFER: begin
                    if (div_cnt == DIV_HALF-1) begin
                        div_cnt <= 0;

                        if (spi_sclk == 1'b0) begin
                            // SPI Mode 0: MOSI e MISO são amostrados na subida.
                            spi_sclk <= 1'b1;

                            // Ignora os cinco clocks de comando e o bit nulo.
                            // rx_shift recebe exatamente D9..D0, eliminando
                            // deslocamentos e perda do bit mais significativo.
                            if ((edge_count >= ADC_DATA_FIRST_RISE) &&
                                (edge_count <= ADC_LAST_RISE))
                                rx_shift <= {rx_shift[8:0], spi_miso};

                            edge_count <= edge_count + 1'b1;
                        end else begin
                            // Na descida, prepara o próximo bit MOSI.
                            spi_sclk <= 1'b0;
                            tx_shift <= {tx_shift[14:0], 1'b0};
                            spi_mosi <= tx_shift[14];

                            // Após a 16ª borda de subida, encerra o frame.
                            if (edge_count == ADC_LAST_RISE + 1'b1)
                                state <= FINISH;
                        end
                    end else begin
                        div_cnt <= div_cnt + 1'b1;
                    end
                end

                FINISH: begin
                    spi_cs_n <= 1'b1;
                    spi_sclk <= 1'b0;
                    busy     <= 1'b0;

                    if (channel == 1'b0) begin
                        ch0_data <= rx_shift;
                    end else begin
                        ch7_data   <= rx_shift;
                        data_valid <= 1'b1;
                    end

                    channel <= ~channel;
                    state   <= IDLE;
                end

                default: state <= IDLE;
            endcase
        end
    end
endmodule
