`timescale 1ns/1ps
// Testbench do escravo SPI externo da Tang Nano, operando em Mode 0.
module tb_spi_slave_pi4;
    reg sys_clk = 1'b0;
    reg rst_n = 1'b0;
    reg arm_spi_sclk = 1'b0;
    reg arm_spi_mosi = 1'b0;
    reg arm_spi_cs_n = 1'b1;
    wire arm_spi_miso;
    reg [15:0] bmp_temp = 16'h1234;
    reg [9:0] lm35_raw = 10'h155;
    reg [9:0] pot_raw = 10'h2AA;
    wire frame_valid;
    wire [7:0] command_byte;
    reg [63:0] rx_frame;
    reg [63:0] tx_frame;
    reg sampled_miso;
    reg saw_frame_valid;
    integer i;

    always #5 sys_clk = ~sys_clk;
    always @(posedge sys_clk) if (frame_valid) saw_frame_valid <= 1'b1;

    spi_slave_pi4 dut (
        .sys_clk(sys_clk), .rst_n(rst_n), .arm_spi_sclk(arm_spi_sclk),
        .arm_spi_mosi(arm_spi_mosi), .arm_spi_miso(arm_spi_miso),
        .arm_spi_cs_n(arm_spi_cs_n), .bmp_temp(bmp_temp), .lm35_raw(lm35_raw),
        .pot_raw(pot_raw), .frame_valid(frame_valid), .command_byte(command_byte)
    );

    // No Mode 0, o mestre define MOSI antes da subida e amostra MISO na subida.
    task automatic transfer_bit;
        input mosi_bit;
        output miso_bit;
        begin
            arm_spi_mosi = mosi_bit;
            #80;
            arm_spi_sclk = 1'b1;
            #30;
            miso_bit = arm_spi_miso;
            #70;
            arm_spi_sclk = 1'b0;
            #100;
        end
    endtask

    initial begin
        $dumpfile("build/tb_spi_slave_pi4.vcd");
        $dumpvars(0, tb_spi_slave_pi4);
        tx_frame = {8'h3C, 56'h0};
        rx_frame = 64'd0;
        saw_frame_valid = 1'b0;
        #40 rst_n = 1'b1;
        #100;

        arm_spi_cs_n = 1'b0;
        #160;
        for (i = 0; i < 64; i = i + 1) begin
            transfer_bit(tx_frame[63-i], sampled_miso);
            rx_frame[63-i] = sampled_miso;
        end
        #100;
        arm_spi_cs_n = 1'b1;
        #160;

        if (rx_frame !== 64'hA5_12_34_01_55_02_AA_00)
            $fatal(1, "SPI slave: frame incorreto: %h", rx_frame);
        if (command_byte !== 8'h3C)
            $fatal(1, "SPI slave: comando incorreto: %h", command_byte);
        if (!saw_frame_valid)
            $fatal(1, "SPI slave: frame_valid nao foi emitido");
        if (arm_spi_miso !== 1'b0)
            $fatal(1, "SPI slave: MISO deveria estar baixo com CS inativo");
        $display("PASS tb_spi_slave_pi4: frame=%h comando=%h", rx_frame, command_byte);
        $finish;
    end
endmodule
