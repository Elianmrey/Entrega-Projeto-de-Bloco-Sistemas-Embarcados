`timescale 1ns/1ps
// Testbench do caminho de falha: o barramento é liberado e nenhum ACK é fornecido.
module tb_bmp180_nack;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    tri sda;
    tri scl;
    wire [15:0] temp_out;
    wire data_valid, busy, error;
    integer valid_count;
    reg saw_error;

    always #5 clk = ~clk;
    pullup(sda);
    pullup(scl);
    always @(posedge clk) begin
        if (data_valid) valid_count = valid_count + 1;
        if (error) saw_error <= 1'b1;
    end

    bmp180_controller #(
        .CLK_HZ(100), .I2C_HZ(10), .PERIOD_TICKS(30), .CONVERSION_TICKS(20)
    ) dut (
        .clk(clk), .rst_n(rst_n), .sda(sda), .scl(scl), .temp_out(temp_out),
        .data_valid(data_valid), .busy(busy), .error(error)
    );

    initial begin
        $dumpfile("build/tb_bmp180_nack.vcd");
        $dumpvars(0, tb_bmp180_nack);
        valid_count = 0;
        saw_error = 1'b0;
        #30 rst_n = 1'b1;
        #9000;
        if (valid_count != 0) $fatal(1, "BMP180 NACK: data_valid indevido");
        if (!saw_error) $fatal(1, "BMP180 NACK: erro nao foi sinalizado");
        if (sda !== 1'b1 || scl !== 1'b1) $fatal(1, "BMP180 NACK: I2C nao voltou ao repouso");
        $display("PASS tb_bmp180_nack: NACK detectado e ciclo encerrado");
        $finish;
    end
endmodule
