`timescale 1ns/1ps
// Testbench autoverificável da FSM SPI do MCP3008.
module tb_mcp3008;
    reg clk = 1'b0;
    reg rst_n = 1'b0;
    reg miso = 1'b0;
    wire cs_n, sclk, mosi;
    wire [9:0] ch0_data, ch7_data;
    wire data_valid, busy;

    reg [4:0] edge_count;
    reg [9:0] response;
    integer transaction_count;
    reg saw_data_valid;

    always #5 clk = ~clk;

    // A primeira transação responde ao canal 0; a segunda, ao canal 7.
    always @(negedge cs_n) begin
        edge_count <= 0;
        if (transaction_count == 0) response <= 10'b1010101010;
        else response <= 10'b0101010101;
        transaction_count <= transaction_count + 1;
    end

    // O valor é preparado antes da borda que será usada pelo controlador.
    always @(posedge sclk) begin
        if (!cs_n) begin
            if (edge_count >= 5 && edge_count <= 14)
                miso <= response[14-edge_count];
            else
                miso <= 1'b0;
            edge_count <= edge_count + 1'b1;
        end
    end

    always @(posedge clk) if (data_valid) saw_data_valid <= 1'b1;

    mcp3008_controller #(
        .CLK_HZ(100), .SPI_HZ(5), .SAMPLE_PERIOD(20)
    ) dut (
        .clk(clk), .rst_n(rst_n), .spi_cs_n(cs_n), .spi_sclk(sclk),
        .spi_mosi(mosi), .spi_miso(miso), .ch0_data(ch0_data),
        .ch7_data(ch7_data), .data_valid(data_valid), .busy(busy)
    );

    initial begin
        $dumpfile("build/tb_mcp3008.vcd");
        $dumpvars(0, tb_mcp3008);
        transaction_count = 0;
        edge_count = 0;
        saw_data_valid = 1'b0;
        #30 rst_n = 1'b1;
        // O primeiro pulso de data_valid ocorre após a aquisição do canal 7.
        @(posedge data_valid);
        #20;
        if (transaction_count < 2) $fatal(1, "MCP3008: menos de duas transacoes");
        if (ch0_data !== 10'b1010101010) $fatal(1, "MCP3008: CH0 incorreto: %b", ch0_data);
        if (ch7_data !== 10'b0101010101) $fatal(1, "MCP3008: CH7 incorreto: %b", ch7_data);
        if (!saw_data_valid) $fatal(1, "MCP3008: data_valid nao foi observado");
        if (cs_n !== 1'b1 || sclk !== 1'b0) $fatal(1, "MCP3008: barramento nao retornou ao repouso");
        $display("PASS tb_mcp3008: CH0=%b CH7=%b transacoes=%0d", ch0_data, ch7_data, transaction_count);
        $finish;
    end
endmodule
