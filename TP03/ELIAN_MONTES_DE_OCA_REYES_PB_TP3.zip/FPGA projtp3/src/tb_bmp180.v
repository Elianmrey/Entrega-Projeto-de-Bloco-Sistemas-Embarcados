`timescale 1ns/1ps
// Testbench autoverificável do fluxo I2C de leitura do BMP180.
module tb_bmp180;
    localparam [4:0] S_ACK      = 5'd3;
    localparam [4:0] S_RECV_MSB = 5'd6;
    localparam [4:0] S_RECV_LSB = 5'd8;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    tri sda;
    tri scl;
    reg sda_slave_low;
    reg [15:0] sensor_temp;
    wire [15:0] temp_out;
    wire data_valid, busy, error;
    integer valid_count;

    always #5 clk = ~clk;
    pullup(sda);
    pullup(scl);
    assign sda = sda_slave_low ? 1'b0 : 1'bz;

    // Modelo simplificado do BMP180: responde ACK e disponibiliza 0xABCD.
    always @* begin
        sda_slave_low = 1'b0;
        if (dut.state == S_ACK && dut.phase >= 2)
            sda_slave_low = 1'b1;
        else if (dut.state == S_RECV_MSB && dut.phase >= 1)
            sda_slave_low = ~sensor_temp[dut.bit_cnt + 8];
        else if (dut.state == S_RECV_LSB && dut.phase >= 1)
            sda_slave_low = ~sensor_temp[dut.bit_cnt];
    end

    always @(posedge clk) if (data_valid) valid_count = valid_count + 1;

    bmp180_controller #(
        .CLK_HZ(100), .I2C_HZ(10), .PERIOD_TICKS(30), .CONVERSION_TICKS(20)
    ) dut (
        .clk(clk), .rst_n(rst_n), .sda(sda), .scl(scl), .temp_out(temp_out),
        .data_valid(data_valid), .busy(busy), .error(error)
    );

    initial begin
        $dumpfile("build/tb_bmp180.vcd");
        $dumpvars(0, tb_bmp180);
        sensor_temp = 16'hABCD;
        valid_count = 0;
        #30 rst_n = 1'b1;
        @(posedge data_valid);
        #20;
        if (valid_count < 1) $fatal(1, "BMP180: a FSM nao concluiu a leitura");
        if (temp_out !== 16'hABCD) $fatal(1, "BMP180: valor incorreto: %h", temp_out);
        if (error !== 1'b0) $fatal(1, "BMP180: erro indevido em transacao com ACK");
        if (sda !== 1'b1 || scl !== 1'b1) $fatal(1, "BMP180: I2C nao retornou ao repouso");
        $display("PASS tb_bmp180: UT=%h leituras=%0d", temp_out, valid_count);
        $finish;
    end
endmodule
