`timescale 1ns/1ps
module tang_nano_4k_top #(
    parameter integer CLK_HZ = 27_000_000,
    parameter integer SPI_SAMPLE_PERIOD = 1_350_000,
    parameter integer I2C_PERIOD = 27_000_000,
    parameter integer I2C_CONVERSION = 121_500
)(
    input wire sys_clk, input wire rst_n,
    output wire mcp_cs_n, output wire mcp_sclk, output wire mcp_mosi,
    input wire mcp_miso,
    inout wire bmp_sda, inout wire bmp_scl,
    // SPI slave dedicado a Raspberry Pi 4 Model B — SPI0, Mode 0
    input wire arm_spi_sclk,
    input wire arm_spi_mosi,
    output wire arm_spi_miso,
    input wire arm_spi_cs_n,
    output wire [2:0] led
);
    wire [9:0] lm35_raw, pot_raw;
    wire mcp_valid, bmp_valid, mcp_busy, bmp_busy, bmp_error;
    wire [15:0] bmp_temp;
    wire pi_frame_valid;
    wire [7:0] pi_command_byte;
    reg [2:0] led_reg;
    mcp3008_controller #(.CLK_HZ(CLK_HZ),.SAMPLE_PERIOD(SPI_SAMPLE_PERIOD)) u_mcp (
        .clk(sys_clk),.rst_n(rst_n),.spi_cs_n(mcp_cs_n),.spi_sclk(mcp_sclk),.spi_mosi(mcp_mosi),.spi_miso(mcp_miso),
        .ch0_data(lm35_raw),.ch7_data(pot_raw),.data_valid(mcp_valid),.busy(mcp_busy));
    bmp180_controller #(.CLK_HZ(CLK_HZ),.PERIOD_TICKS(I2C_PERIOD),.CONVERSION_TICKS(I2C_CONVERSION)) u_bmp (
        .clk(sys_clk),.rst_n(rst_n),.sda(bmp_sda),.scl(bmp_scl),.temp_out(bmp_temp),.data_valid(bmp_valid),.busy(bmp_busy),.error(bmp_error));
    // Interface independente: o MCP3008 continua sendo master SPI interno da FPGA.
    // A Raspberry Pi e master SPI externo e recebe uma moldura de 8 bytes.
    spi_slave_pi4 u_pi_spi (
        .sys_clk(sys_clk), .rst_n(rst_n),
        .arm_spi_sclk(arm_spi_sclk), .arm_spi_mosi(arm_spi_mosi),
        .arm_spi_miso(arm_spi_miso), .arm_spi_cs_n(arm_spi_cs_n),
        .bmp_temp(bmp_temp), .lm35_raw(lm35_raw), .pot_raw(pot_raw),
        .frame_valid(pi_frame_valid), .command_byte(pi_command_byte)
    );

    // LEDs ativos em nivel baixo: cada evento alterna o indicador correspondente.
    always @(posedge sys_clk or negedge rst_n) begin
        if(!rst_n) led_reg<=3'b000;
        else begin
            if(bmp_valid) led_reg[0]<=~led_reg[0];
            if(mcp_valid) begin led_reg[1]<=~led_reg[1]; led_reg[2]<=~led_reg[2]; end
        end
    end
    assign led=~led_reg;
endmodule
