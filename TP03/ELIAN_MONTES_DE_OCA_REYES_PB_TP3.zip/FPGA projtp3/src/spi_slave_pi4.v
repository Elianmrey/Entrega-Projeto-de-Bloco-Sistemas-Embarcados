`timescale 1ns/1ps
// SPI slave dedicado a Raspberry Pi 4.
// Modo SPI 0: Raspberry Pi e master; FPGA e slave.
// A Raspberry envia 8 bytes (podem ser zeros) e recebe:
// [0] status 0xA5, [1:2] BMP180, [3:4] LM35, [5:6] potenciometro, [7] reservado.
// O barramento SPI e amostrado no clock sys_clk para evitar multiplos clocks na logica.
module spi_slave_pi4 (
    input  wire       sys_clk,
    input  wire       rst_n,
    input  wire       arm_spi_sclk,
    input  wire       arm_spi_mosi,
    output wire       arm_spi_miso,
    input  wire       arm_spi_cs_n,
    input  wire [15:0] bmp_temp,
    input  wire [9:0]  lm35_raw,
    input  wire [9:0]  pot_raw,
    output reg        frame_valid,
    output reg [7:0]  command_byte
);
    reg sclk_meta, sclk_sync, sclk_prev;
    reg mosi_meta, mosi_sync;
    reg cs_meta, cs_sync, cs_prev;
    reg [63:0] tx_shift;
    reg [63:0] rx_shift;
    reg [5:0] bit_count;
    reg miso_reg;
    wire cs_fall = cs_prev && !cs_sync;
    wire cs_rise = !cs_prev && cs_sync;
    wire sclk_rise = !sclk_prev && sclk_sync;
    wire sclk_fall = sclk_prev && !sclk_sync;
    assign arm_spi_miso = miso_reg;

    always @(posedge sys_clk or negedge rst_n) begin
        if(!rst_n) begin
            sclk_meta<=0; sclk_sync<=0; sclk_prev<=0;
            mosi_meta<=0; mosi_sync<=0;
            cs_meta<=1; cs_sync<=1; cs_prev<=1;
            tx_shift<=0; rx_shift<=0; bit_count<=0; miso_reg<=0;
            frame_valid<=0; command_byte<=0;
        end else begin
            // Sincronizadores de entrada do barramento SPI.
            sclk_meta <= arm_spi_sclk; sclk_sync <= sclk_meta; sclk_prev <= sclk_sync;
            mosi_meta <= arm_spi_mosi; mosi_sync <= mosi_meta;
            cs_meta <= arm_spi_cs_n; cs_sync <= cs_meta; cs_prev <= cs_sync;
            frame_valid <= 1'b0;

            if(cs_fall) begin
                // Primeiro bit ja fica disponivel antes da primeira subida de SCLK.
                tx_shift <= {8'hA5, bmp_temp, 6'b0, lm35_raw, 6'b0, pot_raw, 8'h00};
                rx_shift <= 64'd0;
                bit_count <= 0;
                // Primeiro bit deve estar pronto antes da primeira subida de SCLK.
                miso_reg <= 1'b1; // MSB do status 0xA5

            end else if(cs_rise) begin
                command_byte <= rx_shift[63:56];
                frame_valid <= (bit_count >= 6'd63);
                miso_reg <= 1'b0;
            end else if(!cs_sync) begin
                if(sclk_rise) begin
                    rx_shift <= {rx_shift[62:0], mosi_sync};
                    if(bit_count != 6'd63) bit_count <= bit_count + 1'b1;
                end
                if(sclk_fall) begin
                    tx_shift <= {tx_shift[62:0],1'b0};
                    miso_reg <= tx_shift[62];
                end
            end
        end
    end
endmodule
