.arch armv8-a
.text

// ============================================================================
// TP3 — Raspberry Pi 4 Model B <-> Tang Nano 4K
// Autor: Elian Montes de Oca Reyes
//
// A Raspberry Pi é mestre SPI e a Tang Nano é escrava SPI em Mode 0.
// O frame de oito bytes recebido é:
// [0] 0xA5, [1:2] BMP180, [3:4] LM35, [5:6] potenciômetro, [7] reservado.
//
// Uso:
//   ./tp3_program       (ou ./tp3_program s) : leitura contínua dos sensores
//   ./tp3_program g                         : executa a demonstração GPIO simulada
//   ./tp3_program h                         : exibe ajuda
//   ./tp3_program q                         : encerra sem iniciar o SPI
// ============================================================================

.global _start
.global spi_open
.global spi_configure
.global spi_read_frame
.global capture_bmp180
.global capture_lm35
.global capture_potentiometer
.global capture_all_sensors
.global copy_frame_for
.global parse_startup_command
.global dispatch_command
.global gpio_shadow_demo
.global print_sensor_values
.global print_u32

.equ AT_FDCWD,                  -100
.equ O_RDWR,                    2
.equ SYS_write,                 64
.equ SYS_close,                 57
.equ SYS_exit,                  93
.equ SYS_openat,                56
.equ SYS_ioctl,                 29
.equ SYS_nanosleep,             101

.equ SPI_IOC_WR_MODE,           0x40016b01
.equ SPI_IOC_WR_BITS_PER_WORD,  0x40016b03
.equ SPI_IOC_WR_MAX_SPEED_HZ,   0x40046b04
.equ SPI_IOC_MESSAGE_1,         0x40206b00

// 10 kHz é a frequência inicial de validação elétrica da interface externa.
.equ SPI_SPEED_HZ,              10000
.equ FRAME_SIZE,                8

// BCM2711 — valores documentados para a Raspberry Pi 4 Model B.
.equ BCM2711_GPIO_BASE,         0xFE200000
.equ GPIO_GPFSEL0,              0x00
.equ GPIO_GPSET0,               0x1C
.equ GPIO_GPCLR0,               0x28
.equ GPIO_GPLEV0,               0x34
.equ GPIO_DEMO_PIN_MASK,        (1 << 17)

.equ CMD_STATUS,                0
.equ CMD_GPIO,                  1
.equ CMD_HELP,                  2
.equ CMD_QUIT,                  3
.equ CMD_INVALID,               4

// -----------------------------------------------------------------------------
// _start — interpreta o argumento opcional, configura o SPI e inicia o loop.
// -----------------------------------------------------------------------------
_start:
    bl      parse_startup_command

    // Cadeia if–elseif–else de seleção do modo de operação.
    cmp     w0, #CMD_QUIT
    b.eq    exit_success
    cmp     w0, #CMD_HELP
    b.eq    show_help_and_exit
    cmp     w0, #CMD_GPIO
    b.ne    command_is_status_or_invalid
    bl      gpio_shadow_demo
    b       program_initialize

command_is_status_or_invalid:
    cmp     w0, #CMD_INVALID
    b.ne    program_initialize
    adrp    x0, invalid_command_msg
    add     x0, x0, :lo12:invalid_command_msg
    mov     x1, #invalid_command_msg_end-invalid_command_msg
    bl      write_str

program_initialize:
    bl      spi_open
    cmp     x0, #0
    b.lt    exit_error
    mov     x19, x0                         // fd de /dev/spidev0.0

    mov     x0, x19
    bl      spi_configure
    cmp     x0, #0
    b.lt    close_error

main_loop:
    mov     x0, x19
    bl      capture_all_sensors
    cmp     w0, #0xA5
    b.ne    print_invalid_frame

    bl      print_sensor_values
    bl      sleep_200ms
    b       main_loop

print_invalid_frame:
    bl      print_invalid_frame_panel
    bl      sleep_200ms
    b       main_loop

show_help_and_exit:
    adrp    x0, help_msg
    add     x0, x0, :lo12:help_msg
    mov     x1, #help_msg_end-help_msg
    bl      write_str
    b       exit_success

close_error:
    mov     x0, x19
    mov     x8, #SYS_close
    svc     #0
exit_error:
    mov     w0, #1
    mov     x8, #SYS_exit
    svc     #0

exit_success:
    mov     w0, #0
    mov     x8, #SYS_exit
    svc     #0

// -----------------------------------------------------------------------------
// parse_startup_command — extrai argv[1][0] da pilha inicial Linux.
// Sem argumento, seleciona o modo de monitoramento de sensores ('s').
// Retorno: enumeração CMD_*.
// -----------------------------------------------------------------------------
parse_startup_command:
    ldr     x1, [sp]                         // argc
    cmp     x1, #2
    b.lt    parser_default
    ldr     x1, [sp, #16]                    // argv[1]
    ldrb    w0, [x1]
    b       dispatch_command

parser_default:
    mov     w0, #'s'
    b       dispatch_command

// -----------------------------------------------------------------------------
// dispatch_command — decisão múltipla por tabela de saltos. São aceitos os
// comandos 'g', 'h', 'q' e 's'; qualquer lacuna da tabela é inválida.
// Entrada: w0 = caractere. Retorno: enumeração CMD_*.
// -----------------------------------------------------------------------------
dispatch_command:
    cmp     w0, #'g'
    b.lt    command_invalid
    cmp     w0, #'s'
    b.gt    command_invalid
    sub     w0, w0, #'g'
    adrp    x1, command_jump_table
    add     x1, x1, :lo12:command_jump_table
    ldr     x2, [x1, w0, uxtw #3]
    cbz     x2, command_invalid
    br      x2

command_status:
    mov     w0, #CMD_STATUS
    ret
command_gpio:
    mov     w0, #CMD_GPIO
    ret
command_help:
    mov     w0, #CMD_HELP
    ret
command_quit:
    mov     w0, #CMD_QUIT
    ret
command_invalid:
    mov     w0, #CMD_INVALID
    ret

// -----------------------------------------------------------------------------
// spi_open — abre /dev/spidev0.0 em leitura/escrita.
// Retorno: x0 = descritor; negativo indica erro do kernel.
// -----------------------------------------------------------------------------
spi_open:
    mov     x0, #AT_FDCWD
    adrp    x1, spi_device
    add     x1, x1, :lo12:spi_device
    mov     x2, #O_RDWR
    mov     x3, #0
    mov     x8, #SYS_openat
    svc     #0
    ret

// -----------------------------------------------------------------------------
// spi_configure — seleciona Mode 0, palavra de 8 bits e 10 kHz.
// Entrada: x0 = descritor. Retorno: x0 = 0 ou erro negativo.
// -----------------------------------------------------------------------------
spi_configure:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp
    mov     x19, x0

    mov     x0, x19
    ldr     x1, =SPI_IOC_WR_MODE
    adrp    x2, spi_mode
    add     x2, x2, :lo12:spi_mode
    mov     x8, #SYS_ioctl
    svc     #0
    cmp     x0, #0
    b.lt    configure_done

    mov     x0, x19
    ldr     x1, =SPI_IOC_WR_BITS_PER_WORD
    adrp    x2, spi_bits
    add     x2, x2, :lo12:spi_bits
    mov     x8, #SYS_ioctl
    svc     #0
    cmp     x0, #0
    b.lt    configure_done

    mov     x0, x19
    ldr     x1, =SPI_IOC_WR_MAX_SPEED_HZ
    adrp    x2, spi_speed
    add     x2, x2, :lo12:spi_speed
    mov     x8, #SYS_ioctl
    svc     #0

configure_done:
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

// -----------------------------------------------------------------------------
// spi_read_frame — transmite oito bytes dummy e recebe o frame da FPGA.
// Entrada: x0 = fd; x1 = buffer de recepção. Retorno: 0 ou erro negativo.
// -----------------------------------------------------------------------------
spi_read_frame:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp
    mov     x19, x0

    adrp    x2, spi_transfer
    add     x2, x2, :lo12:spi_transfer
    adrp    x3, tx_dummy
    add     x3, x3, :lo12:tx_dummy
    str     x3, [x2, #0]
    str     x1, [x2, #8]

    mov     x0, x19
    ldr     x1, =SPI_IOC_MESSAGE_1
    mov     x8, #SYS_ioctl
    svc     #0
    cmp     x0, #0
    b.lt    frame_done
    mov     x0, #0

frame_done:
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

// -----------------------------------------------------------------------------
// copy_frame_for — loop for explícito que copia os oito bytes do frame para uma
// área de snapshot antes do parsing. Entrada: x0=origem, x1=destino.
// -----------------------------------------------------------------------------
copy_frame_for:
    mov     w2, #0
copy_frame_for_loop:
    cmp     w2, #FRAME_SIZE
    b.ge    copy_frame_for_done
    ldrb    w3, [x0, w2, uxtw]
    strb    w3, [x1, w2, uxtw]
    add     w2, w2, #1
    b       copy_frame_for_loop
copy_frame_for_done:
    ret

// -----------------------------------------------------------------------------
// capture_bmp180 — extrai BMP180 big-endian dos bytes 1 e 2.
// -----------------------------------------------------------------------------
capture_bmp180:
    ldrb    w1, [x0, #1]
    ldrb    w2, [x0, #2]
    lsl     w1, w1, #8
    orr     w0, w1, w2
    ret

// -----------------------------------------------------------------------------
// capture_lm35 — extrai o valor ADC de 10 bits dos bytes 3 e 4.
// -----------------------------------------------------------------------------
capture_lm35:
    ldrb    w1, [x0, #3]
    ldrb    w2, [x0, #4]
    lsl     w1, w1, #8
    orr     w0, w1, w2
    and     w0, w0, #0x03ff
    ret

// -----------------------------------------------------------------------------
// capture_potentiometer — extrai o valor ADC de 10 bits dos bytes 5 e 6.
// -----------------------------------------------------------------------------
capture_potentiometer:
    ldrb    w1, [x0, #5]
    ldrb    w2, [x0, #6]
    lsl     w1, w1, #8
    orr     w0, w1, w2
    and     w0, w0, #0x03ff
    ret

// -----------------------------------------------------------------------------
// capture_all_sensors — lê, valida, copia e faz parsing da moldura completa.
// Entrada: x0 = fd. Retorno: 0xA5 em sucesso ou -1 em erro.
// -----------------------------------------------------------------------------
capture_all_sensors:
    stp     x29, x30, [sp, #-48]!
    stp     x19, x20, [sp, #16]
    str     x21, [sp, #32]
    mov     x29, sp
    mov     x19, x0

    adrp    x1, frame_buffer
    add     x1, x1, :lo12:frame_buffer
    bl      spi_read_frame
    cmp     x0, #0
    b.lt    capture_error

    adrp    x20, frame_buffer
    add     x20, x20, :lo12:frame_buffer
    ldrb    w0, [x20, #0]
    cmp     w0, #0xA5
    b.ne    capture_error

    mov     x0, x20
    adrp    x1, frame_snapshot
    add     x1, x1, :lo12:frame_snapshot
    bl      copy_frame_for

    mov     x0, x20
    bl      capture_bmp180
    adrp    x1, bmp180_value
    add     x1, x1, :lo12:bmp180_value
    strh    w0, [x1]

    mov     x0, x20
    bl      capture_lm35
    adrp    x1, lm35_value
    add     x1, x1, :lo12:lm35_value
    strh    w0, [x1]

    mov     x0, x20
    bl      capture_potentiometer
    adrp    x1, potentiometer_value
    add     x1, x1, :lo12:potentiometer_value
    strh    w0, [x1]

    mov     w0, #0xA5
    b       capture_done

capture_error:
    mov     w0, #-1
capture_done:
    ldr     x21, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #48
    ret

// -----------------------------------------------------------------------------
// gpio_shadow_demo — demonstra leitura, escrita e teste de bit com LDR/STR nas
// mesmas posições relativas usadas pelos registradores GPIO. A rotina usa uma
// área shadow em RAM e não altera pinos físicos; a base física BCM2711 e os
// offsets estão declarados no cabeçalho para integração futura.
// -----------------------------------------------------------------------------
gpio_shadow_demo:
    adrp    x0, gpio_shadow_registers
    add     x0, x0, :lo12:gpio_shadow_registers
    mov     w1, #GPIO_DEMO_PIN_MASK
    str     w1, [x0, #GPIO_GPSET0]           // escrita simulada em GPSET0
    ldr     w2, [x0, #GPIO_GPSET0]           // leitura por LDR
    str     w2, [x0, #GPIO_GPLEV0]           // espelha o nível lógico
    ldr     w3, [x0, #GPIO_GPLEV0]
    tst     w3, w1
    b.eq    gpio_shadow_error
    str     wzr, [x0, #GPIO_GPCLR0]          // limpeza simulada em GPCLR0
    adrp    x0, gpio_demo_ok_msg
    add     x0, x0, :lo12:gpio_demo_ok_msg
    mov     x1, #gpio_demo_ok_msg_end-gpio_demo_ok_msg
    b       write_str

gpio_shadow_error:
    adrp    x0, gpio_demo_error_msg
    add     x0, x0, :lo12:gpio_demo_error_msg
    mov     x1, #gpio_demo_error_msg_end-gpio_demo_error_msg
    b       write_str

// -----------------------------------------------------------------------------
// print_sensor_values — redesenha o painel ANSI com fundo azul claro. Os valores
// exibidos são exatamente os campos já validados do frame 0xA5:
// BMP180 em 16 bits; LM35 e potenciômetro em ADC de 10 bits. A apresentação usa
// dados brutos para não supor VREF ou compensação de temperatura inexistente.
// -----------------------------------------------------------------------------
print_sensor_values:
    // A rotina chama write_str e print_u32 diversas vezes; preserve LR para que
    // o retorno final volte ao main_loop, e não a uma chamada interna anterior.
    stp     x29, x30, [sp, #-16]!
    mov     x29, sp

    adrp    x0, panel_begin
    add     x0, x0, :lo12:panel_begin
    mov     x1, #panel_begin_end-panel_begin
    bl      write_str

    adrp    x0, panel_bmp_label
    add     x0, x0, :lo12:panel_bmp_label
    mov     x1, #panel_bmp_label_end-panel_bmp_label
    bl      write_str
    adrp    x1, bmp180_value
    add     x1, x1, :lo12:bmp180_value
    ldrh    w0, [x1]
    bl      print_u32
    adrp    x0, panel_value_suffix
    add     x0, x0, :lo12:panel_value_suffix
    mov     x1, #panel_value_suffix_end-panel_value_suffix
    bl      write_str

    adrp    x0, panel_lm35_label
    add     x0, x0, :lo12:panel_lm35_label
    mov     x1, #panel_lm35_label_end-panel_lm35_label
    bl      write_str
    adrp    x1, lm35_value
    add     x1, x1, :lo12:lm35_value
    ldrh    w0, [x1]
    bl      print_u32
    adrp    x0, panel_adc_suffix
    add     x0, x0, :lo12:panel_adc_suffix
    mov     x1, #panel_adc_suffix_end-panel_adc_suffix
    bl      write_str

    adrp    x0, panel_pot_label
    add     x0, x0, :lo12:panel_pot_label
    mov     x1, #panel_pot_label_end-panel_pot_label
    bl      write_str
    adrp    x1, potentiometer_value
    add     x1, x1, :lo12:potentiometer_value
    ldrh    w0, [x1]
    bl      print_u32
    adrp    x0, panel_adc_suffix
    add     x0, x0, :lo12:panel_adc_suffix
    mov     x1, #panel_adc_suffix_end-panel_adc_suffix
    bl      write_str

    adrp    x0, panel_end
    add     x0, x0, :lo12:panel_end
    mov     x1, #panel_end_end-panel_end
    bl      write_str

    ldp     x29, x30, [sp], #16
    ret

// -----------------------------------------------------------------------------
// print_invalid_frame_panel — mantém a mesma tela azul e informa que a moldura
// recebida não continha o marcador 0xA5. O próximo ciclo é tentado em 200 ms.
// -----------------------------------------------------------------------------
print_invalid_frame_panel:
    adrp    x0, panel_invalid
    add     x0, x0, :lo12:panel_invalid
    mov     x1, #panel_invalid_end-panel_invalid
    b       write_str

// -----------------------------------------------------------------------------
// print_u32 — converte w0 para decimal sem biblioteca C e escreve no stdout.
// -----------------------------------------------------------------------------
print_u32:
    stp     x29, x30, [sp, #-80]!
    stp     x19, x20, [sp, #16]
    stp     x21, x22, [sp, #32]
    mov     x29, sp
    mov     w19, w0
    add     x21, sp, #64
    mov     w22, #0

    cbnz    w19, convert_digit
    sub     x21, x21, #1
    mov     w0, #'0'
    strb    w0, [x21]
    mov     w22, #1
    b       write_number

convert_digit:
    mov     w0, #10
    udiv    w1, w19, w0
    msub    w2, w1, w0, w19
    add     w2, w2, #'0'
    sub     x21, x21, #1
    strb    w2, [x21]
    mov     w19, w1
    add     w22, w22, #1
    cbnz    w19, convert_digit

write_number:
    mov     x0, #1
    mov     x1, x21
    mov     w2, w22
    mov     x8, #SYS_write
    svc     #0
    ldp     x21, x22, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #80
    ret

// -----------------------------------------------------------------------------
// write_str — escreve x1 bytes do endereço x0 no stdout.
// -----------------------------------------------------------------------------
write_str:
    mov     x2, x1
    mov     x1, x0
    mov     x0, #1
    mov     x8, #SYS_write
    svc     #0
    ret

// -----------------------------------------------------------------------------
// sleep_200ms — pausa entre ciclos por meio de nanosleep.
// -----------------------------------------------------------------------------
sleep_200ms:
    adrp    x0, sleep_time
    add     x0, x0, :lo12:sleep_time
    mov     x1, #0
    mov     x8, #SYS_nanosleep
    svc     #0
    ret

.section .rodata
.align 3
spi_device:
    .asciz "/dev/spidev0.0"
help_msg:
    .ascii "Uso: ./tp3_program [s|g|h|q]\n"
help_msg_end:
invalid_command_msg:
    .ascii "Comando invalido; iniciando monitoramento.\n"
invalid_command_msg_end:
invalid_frame_msg:
    .ascii "SPI frame invalida\n"
invalid_frame_msg_end:

// Sequências ANSI: fundo RGB azul claro, texto azul escuro, limpeza e cursor no
// canto superior esquerdo. Terminais modernos como o da Raspberry Pi OS suportam
// esse formato; os campos exibidos continuam utilizáveis mesmo sem cor.
panel_begin:
    .ascii "\033[48;2;173;216;230m\033[38;2;12;52;70m\033[2J\033[H"
    .ascii "\n  +----------------------------------------------------------------------+\n"
    .ascii "  | TP3 - MONITORAMENTO SPI: Raspberry Pi 4 Model B <-> Tang Nano 4K   |\n"
    .ascii "  +----------------------------------------------------------------------+\n"
    .ascii "  | Estado do frame: VALIDO (marcador 0xA5)                             |\n"
    .ascii "  +----------------------------------------------------------------------+\n"
panel_begin_end:
panel_bmp_label:
    .ascii "  | BMP180 - dado I2C bruto (16 bits): "
panel_bmp_label_end:
panel_lm35_label:
    .ascii "  | LM35 - sensor de temperatura, ADC: "
panel_lm35_label_end:
panel_pot_label:
    .ascii "  | Potenciometro, ADC: "
panel_pot_label_end:
panel_value_suffix:
    .ascii "                                              |\n"
panel_value_suffix_end:
panel_adc_suffix:
    .ascii " / 1023                                      |\n"
panel_adc_suffix_end:
panel_end:
    .ascii "  +----------------------------------------------------------------------+\n"
    .ascii "  | Atualizacao SPI a cada 200 ms. Pressione Ctrl+C para encerrar.      |\n"
    .ascii "  +----------------------------------------------------------------------+\n\033[0m"
panel_end_end:
panel_invalid:
    .ascii "\033[48;2;173;216;230m\033[38;2;127;29;29m\033[2J\033[H"
    .ascii "\n  +----------------------------------------------------------------------+\n"
    .ascii "  | TP3 - MONITORAMENTO SPI: Raspberry Pi 4 Model B <-> Tang Nano 4K   |\n"
    .ascii "  +----------------------------------------------------------------------+\n"
    .ascii "  | Estado do frame: INVALIDO - marcador 0xA5 nao foi recebido.        |\n"
    .ascii "  | Verifique SCLK, MOSI, MISO, CS_N, GND e o nivel logico.             |\n"
    .ascii "  | Nova tentativa em 200 ms. Ctrl+C encerra o monitoramento.           |\n"
    .ascii "  +----------------------------------------------------------------------+\n\033[0m"
panel_invalid_end:
gpio_demo_ok_msg:
    .ascii "GPIO simulado: LDR/STR e teste de bit aprovados.\n"
gpio_demo_ok_msg_end:
gpio_demo_error_msg:
    .ascii "GPIO simulado: falha no teste de bit.\n"
gpio_demo_error_msg_end:
bmp_label:
    .ascii "BMP180="
bmp_label_end:
lm_label:
    .ascii " LM35="
lm_label_end:
pot_label:
    .ascii " POT="
pot_label_end:
newline:
    .ascii "\n"
newline_end:

.align 3
command_jump_table:
    .quad command_gpio     // g
    .quad command_help     // h
    .quad 0                // i
    .quad 0                // j
    .quad 0                // k
    .quad 0                // l
    .quad 0                // m
    .quad 0                // n
    .quad 0                // o
    .quad 0                // p
    .quad command_quit     // q
    .quad 0                // r
    .quad command_status   // s

.section .data
.align 3
spi_mode:
    .byte   0
spi_bits:
    .byte   8
    .align 2
spi_speed:
    .word   SPI_SPEED_HZ

// struct spi_ioc_transfer, layout de 32 bytes em AArch64.
.align 3
spi_transfer:
    .quad   tx_dummy
    .quad   frame_buffer
    .word   FRAME_SIZE
    .word   SPI_SPEED_HZ
    .hword  0
    .byte   8
    .byte   0
    .byte   0
    .byte   0
    .byte   0
    .byte   0

sleep_time:
    .quad   0
    .quad   200000000

tx_dummy:
    .byte   0, 0, 0, 0, 0, 0, 0, 0

.bss
.align 3
frame_buffer:
    .skip   FRAME_SIZE
frame_snapshot:
    .skip   FRAME_SIZE
.align 2
bmp180_value:
    .skip   2
lm35_value:
    .skip   2
potentiometer_value:
    .skip   2
.align 8
gpio_shadow_registers:
    .skip   256
.end

