// sub_bmp180.s - direct BMP180 interface
.include "common.inc"
.text

.extern bmp180_value
.extern pressure_pa_value

.global sub_bmp180_process

// sub_bmp180_process
// Input:  x0/w0 = BMP180 temperature x10, signed 16-bit
//         x1/w1 = BMP180 pressure in Pa, unsigned 32-bit
// Output: w0 = BMP180 temperature x10
// Side effect: stores temperature and pressure for the main panel/ECU.
sub_bmp180_process:
    adrp    x2, bmp180_value
    add     x2, x2, :lo12:bmp180_value
    strh    w0, [x2]
    adrp    x2, pressure_pa_value
    add     x2, x2, :lo12:pressure_pa_value
    str     w1, [x2]
    ret
