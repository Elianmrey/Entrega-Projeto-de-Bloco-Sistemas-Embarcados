// TP4-3: AArch64 Advanced SIMD/NEON routines for Raspberry Pi Zero 2W.
// Q registers are 128-bit views of D registers; q0 contains four s32/f32 lanes.
.text
.align 2

// neon_add_u32: x0=input A pointer, x1=input B pointer, x2=output pointer.
// LD1 loads four uint32 lanes, ADD operates on all four lanes, ST1 stores them.
.global neon_add_u32
.type neon_add_u32, %function
neon_add_u32:
    ld1 {v0.4s}, [x0]
    ld1 {v1.4s}, [x1]
    add v0.4s, v0.4s, v1.4s
    st1 {v0.4s}, [x2]
    ret

// neon_scale_f32: x0=input pointer, s1=scalar factor, x1=output pointer.
// DUP broadcasts the scalar to four lanes; FMUL performs four float products.
.global neon_scale_f32
.type neon_scale_f32, %function
neon_scale_f32:
    ld1 {v0.4s}, [x0]
    dup v1.4s, v1.s[0]
    fmul v0.4s, v0.4s, v1.4s
    st1 {v0.4s}, [x1]
    ret

.size neon_add_u32, .-neon_add_u32
.size neon_scale_f32, .-neon_scale_f32
