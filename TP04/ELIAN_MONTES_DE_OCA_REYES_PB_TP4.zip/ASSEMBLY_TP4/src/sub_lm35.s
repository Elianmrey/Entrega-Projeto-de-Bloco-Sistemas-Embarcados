// sub_lm35.s - direct LM35 interface
.include "common.inc"
.text

.extern temperature_x10_value
.extern lm35_value

.global sub_lm35_process

// sub_lm35_process
// Input:  w0 = processed LM35 temperature x10
//         w1 = raw LM35 ADC (10-bit)
// Output: w0 = processed temperature x10
sub_lm35_process:
    adrp    x2, temperature_x10_value
    add     x2, x2, :lo12:temperature_x10_value
    strh    w0, [x2]
    adrp    x2, lm35_value
    add     x2, x2, :lo12:lm35_value
    strh    w1, [x2]
    ret
