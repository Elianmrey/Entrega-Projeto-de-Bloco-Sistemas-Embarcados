// TP4 numeric extensions. These routines are isolated from the validated
// SPI, sensor, ECU, motor, encoder and panel path.
.text
.align 2

// uint128_add: x1:x0 = x1:x0 + x3:x2, with carry propagation.
.global uint128_add
.type uint128_add, %function
uint128_add:
    adds x0, x0, x2
    adcs x1, x1, x3
    ret

// uint128_sub: x1:x0 = x1:x0 - x3:x2, with borrow propagation.
.global uint128_sub
.type uint128_sub, %function
uint128_sub:
    subs x0, x0, x2
    sbcs x1, x1, x3
    ret

// uint64_mul_128: x1:x0 = x0 * x1 (unsigned 64x64 -> 128).
.global uint64_mul_128
.type uint64_mul_128, %function
uint64_mul_128:
    umulh x2, x0, x1
    mul x0, x0, x1
    mov x1, x2
    ret

// uint64_to_double: d0 = (uint64)x0, using the AArch64 conversion instruction.
.global uint64_to_double
.type uint64_to_double, %function
uint64_to_double:
    ucvtf d0, x0
    ret

// double_to_uint64: x0 = saturating/truncating unsigned conversion of d0.
.global double_to_uint64
.type double_to_uint64, %function
double_to_uint64:
    fcvtzu x0, d0
    ret

// q16_16_mul: x0 = (x0 * x1) >> 16. Q16.16 scale is restored by ASR.
.global q16_16_mul
.type q16_16_mul, %function
q16_16_mul:
    mul x0, x0, x1
    asr x0, x0, #16
    ret

.section .rodata
.align 2
// Numeric lookup table: index 0..15 -> calibrated Q8.8 gain.
.global tp4_lookup_table
.type tp4_lookup_table, %object
tp4_lookup_table:
    .word 256, 282, 307, 333, 358, 384, 410, 435
    .word 461, 486, 512, 538, 563, 589, 614, 640

.text
.align 2
// lookup_value: x0=index, returns table[index] in x0; out-of-range -> 0.
.global lookup_value
.type lookup_value, %function
lookup_value:
    cmp x0, #15
    b.hi 1f
    adrp x1, tp4_lookup_table
    add x1, x1, :lo12:tp4_lookup_table
    ldr w0, [x1, x0, lsl #2]
    ret
1:
    mov x0, #0
    ret

// bitfield_transform: deterministic demonstration of shifts, masks,
// ORR/EOR/BIC and ROR. The result preserves selected fields and rotates them.
.global bitfield_transform
.type bitfield_transform, %function
bitfield_transform:
    lsl x1, x0, #3
    lsr x2, x0, #5
    asr x3, x0, #7
    and x1, x1, #0x000000ff
    orr x1, x1, x2
    eor x1, x1, x3
    mov x2, #0xff
    bic x1, x1, x2
    ror x0, x1, #11
    ret
.size uint128_add, .-uint128_add
.size uint128_sub, .-uint128_sub
.size uint64_mul_128, .-uint64_mul_128
.size uint64_to_double, .-uint64_to_double
.size double_to_uint64, .-double_to_uint64
.size q16_16_mul, .-q16_16_mul
.size lookup_value, .-lookup_value
.size bitfield_transform, .-bitfield_transform
