// sub_pot.s - direct potentiometer interface
.include "common.inc"
.text

.extern pot_percent_value
.extern potentiometer_value

.global sub_pot_process
.global pot_percent_to_pwm

// sub_pot_process
// Input:  w0 = processed potentiometer percent (0..255 candidate)
//         w1 = raw ADC (10-bit)
// Output: w0 = clamped percentage 0..100
// Side effect: stores both real values for the main panel.
sub_pot_process:
    cmp     w0, #100
    b.ls    1f
    mov     w0, #100
1:
    adrp    x2, pot_percent_value
    add     x2, x2, :lo12:pot_percent_value
    strb    w0, [x2]
    adrp    x2, potentiometer_value
    add     x2, x2, :lo12:potentiometer_value
    strh    w1, [x2]
    ret

// pot_percent_to_pwm
// Input:  w0 = potentiometer percentage.
// Output: w0 = PWM percentage, proportional and clamped 0..100.
pot_percent_to_pwm:
    cmp     w0, #100
    b.ls    2f
    mov     w0, #100
2:
    ret
