.arch armv8-a
.include "common.inc"
.text

// ============================================================================
// TP4 - Main orchestrator.
// This file owns SPI, frame validation, sensor value storage, panel, and the
// dispatch between modular sensor/motor routines.
// ============================================================================

.extern sub_pot_process
.extern sub_lm35_process
.extern sub_bmp180_process
.extern pot_percent_to_pwm
.extern motor_init
.extern motor_stop
.extern motor_control_update
.extern motor_force_disable
.extern motor_feedback_update
.extern motor_test_mode
.extern print_motor_panel
.extern encoder_close
.extern motor_gpio_close
.extern motor_shutdown_all
.extern signal_install

.global _start
.global spi_open
.global spi_configure
.global spi_read_frame
.global capture_all_sensors
.global copy_frame_for
.global parse_startup_command
.global dispatch_command
.global gpio_shadow_demo
.global print_sensor_values
.global print_temperature_x10
.global print_u32
.global print_s64
.global print_fixed100
.global write_str
.global sysfs_write_str
.global sysfs_write_buf
.global strlen
.global u64_to_buf
.global zero_buffer
.global clock_monotonic_ns
.global sleep_1ms
.global sleep_200ms

.global motor_gpio_fd
.global active_spi_fd
.global encoder_fd
.global encoder_state
.global last_encoder_state
.global encoder_count
.global previous_count
.global stage_start_ns
.global last_print_ns
.global stage_last_measure_ns
.global stage_elapsed_ns
.global pps_value
.global clock_ts
.global pwm_number_buf
.global bmp180_value
.global temperature_x10_value
.global lm35_value
.global pressure_pa_value
.global potentiometer_value
.global pot_percent_value
global_dummy_symbol2:
    nop

.global gpio_values
.global motor_gpio_request
.global encoder_request
.global encoder_event_buf
.global minus_sign
.global zero_digit
.global motor_decimal_point
.global newline
// Command enum mapping retained from the original, with 1-4 added as the
// integrated simulation states.

_start:
    // Instala SIGINT para garantir parada segura do motor ao pressionar Ctrl+C.
    bl      signal_install

    // Mantem o descritor SPI inativo ate que o modo escolhido o abra.
    adrp    x1, active_spi_fd
    add     x1, x1, :lo12:active_spi_fd
    mov     x0, #-1
    str     x0, [x1]

    bl      parse_startup_command

    cmp     w0, #CMD_QUIT
    b.eq    exit_success
    cmp     w0, #CMD_HELP
    b.eq    show_help_and_exit
    cmp     w0, #CMD_MOTOR
    b.eq    run_motor_and_exit
    cmp     w0, #CMD_GPIO
    b.eq    run_gpio_then_sensor_monitor
    cmp     w0, #CMD_STATE1
    b.eq    run_integrated_state
    cmp     w0, #CMD_STATE2
    b.eq    run_integrated_state
    cmp     w0, #CMD_STATE3
    b.eq    run_integrated_state
    cmp     w0, #CMD_STATE4
    b.eq    run_integrated_state

program_initialize:
    bl      spi_open
    cmp     x0, #0
    b.lt    exit_error
    mov     x19, x0
    adrp    x1, active_spi_fd
    add     x1, x1, :lo12:active_spi_fd
    str     x19, [x1]

    mov     x0, x19
    bl      spi_configure
    cmp     x0, #0
    b.lt    close_error

sensor_main_loop:
    mov     x0, x19
    bl      capture_all_sensors
    cmp     w0, #0xA5
    b.ne    print_invalid_frame

    bl      print_sensor_values
    bl      sleep_200ms
    b       sensor_main_loop

print_invalid_frame:
    bl      print_invalid_frame_panel
    bl      sleep_200ms
    b       sensor_main_loop

run_gpio_then_sensor_monitor:
    bl      gpio_shadow_demo
    b       program_initialize

run_motor_and_exit:
    bl      motor_test_mode
    cmp     w0, #0
    b.lt    exit_error
    b       exit_success

run_integrated_state:
    // w0 is CMD_STATE1..CMD_STATE4. Convert to state 1..4.
    sub     w20, w0, #CMD_STATE1
    add     w20, w20, #1
    adrp    x1, selected_state
    add     x1, x1, :lo12:selected_state
    str     w20, [x1]

    bl      spi_open
    cmp     x0, #0
    b.lt    exit_error
    mov     x19, x0
    adrp    x1, active_spi_fd
    add     x1, x1, :lo12:active_spi_fd
    str     x19, [x1]

    mov     x0, x19
    bl      spi_configure
    cmp     x0, #0
    b.lt    close_error

    bl      motor_init
    cmp     x0, #0
    b.lt    integrated_motor_init_error

integrated_main_loop:
    mov     x0, x19
    bl      capture_all_sensors
    cmp     w0, #0xA5
    b.ne    integrated_invalid_frame

    // Os sensores reais permanecem intactos. O estado selecionado controla somente
    // o cenario simulado de seguranca usado por sub_motor.s.
    adrp    x1, pot_percent_value
    add     x1, x1, :lo12:pot_percent_value
    ldrb    w1, [x1]
    adrp    x0, selected_state
    add     x0, x0, :lo12:selected_state
    ldr     w0, [x0]
    bl      motor_control_update

    bl      motor_feedback_update
    bl      print_integrated_panel
    bl      sleep_200ms
    b       integrated_main_loop

integrated_invalid_frame:
    // Fail-safe: an invalid sensor frame disables the motor.
    bl      motor_force_disable
    bl      print_invalid_frame_panel
    bl      sleep_200ms
    b       integrated_main_loop

integrated_motor_init_error:
    adrp    x0, motor_init_error_msg_main
    add     x0, x0, :lo12:motor_init_error_msg_main
    mov     x1, #motor_init_error_msg_main_end-motor_init_error_msg_main
    bl      write_str
    b       exit_error

show_help_and_exit:
    adrp    x0, help_msg
    add     x0, x0, :lo12:help_msg
    mov     x1, #help_msg_end-help_msg
    bl      write_str
    b       exit_success

close_error:
    // Caminho de erro: parar o motor e liberar todos os recursos antes de sair.
    bl      motor_shutdown_all
    b       exit_error

exit_error:
    mov     w0, #1
    mov     x8, #SYS_exit
    svc     #0

exit_success:
    // Caminho normal de saida tambem faz shutdown para garantir estado seguro.
    bl      motor_shutdown_all
    mov     w0, #0
    mov     x8, #SYS_exit
    svc     #0

// -----------------------------------------------------------------------------
// SIGINT support. Ctrl+C must stop the motor before process termination.
// Uses the Linux rt_sigaction syscall directly to keep the project self-contained.
// -----------------------------------------------------------------------------
.equ SYS_rt_sigaction, 134
.equ SIGINT_NUM, 2
.equ SA_RESTORER_AARCH64, 0x04000000

signal_install:
    stp     x29, x30, [sp, #-16]!
    mov     x29, sp

    adrp    x1, sigint_action
    add     x1, x1, :lo12:sigint_action
    // Handler address.
    adrp    x2, sigint_handler
    add     x2, x2, :lo12:sigint_handler
    str     x2, [x1, #0]
    mov     x2, #SA_RESTORER_AARCH64
    str     x2, [x1, #8]
    adrp    x2, sigint_restorer
    add     x2, x2, :lo12:sigint_restorer
    str     x2, [x1, #16]
    str     xzr, [x1, #24]

    mov     x0, #SIGINT_NUM
    mov     x2, xzr
    mov     x3, #8
    mov     x8, #SYS_rt_sigaction
    svc     #0

    ldp     x29, x30, [sp], #16
    ret

sigint_handler:
    // O kernel entrega o numero do sinal em W0. Nao dependemos dele aqui.
    bl      motor_shutdown_all
    mov     w0, #130
    mov     x8, #SYS_exit
    svc     #0
    b       .

sigint_restorer:
    mov     x8, #139
    svc     #0

// -----------------------------------------------------------------------------
// Startup command parser. Existing s/g/h/q/m commands are preserved.
// New commands 1..4 enter integrated simulation states.
// -----------------------------------------------------------------------------
parse_startup_command:
    ldr     x1, [sp]
    cmp     x1, #2
    b.lt    parser_default
    ldr     x1, [sp, #16]
    ldrb    w0, [x1]
    b       dispatch_command
parser_default:
    mov     w0, #'s'
    b       dispatch_command

dispatch_command:
    cmp     w0, #'1'
    b.eq    command_state1
    cmp     w0, #'2'
    b.eq    command_state2
    cmp     w0, #'3'
    b.eq    command_state3
    cmp     w0, #'4'
    b.eq    command_state4
    cmp     w0, #'g'
    b.lt    command_invalid
    cmp     w0, #'s'
    b.gt    command_invalid
    sub     w0, w0, #'g'
    adrp    x1, command_jump_table
    add     x1, x1, :lo12:command_jump_table
    ldr     x2, [x1, w0, uxtw #3]
    cbz     x2, command_invalid
    br      x2

command_status:
    mov     w0, #CMD_STATUS
    ret
command_gpio:
    mov     w0, #CMD_GPIO
    ret
command_help:
    mov     w0, #CMD_HELP
    ret
command_quit:
    mov     w0, #CMD_QUIT
    ret
command_motor:
    mov     w0, #CMD_MOTOR
    ret
command_state1:
    mov     w0, #CMD_STATE1
    ret
command_state2:
    mov     w0, #CMD_STATE2
    ret
command_state3:
    mov     w0, #CMD_STATE3
    ret
command_state4:
    mov     w0, #CMD_STATE4
    ret
command_invalid:
    mov     w0, #CMD_INVALID
    ret

// -----------------------------------------------------------------------------
// SPI routines - preserved from the functional baseline.
// -----------------------------------------------------------------------------
spi_open:
    mov     x0, #AT_FDCWD
    adrp    x1, spi_device
    add     x1, x1, :lo12:spi_device
    mov     x2, #O_RDWR
    mov     x3, #0
    mov     x8, #SYS_openat
    svc     #0
    ret

spi_configure:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp
    mov     x19, x0

    mov     x0, x19
    ldr     x1, =SPI_IOC_WR_MODE
    adrp    x2, spi_mode
    add     x2, x2, :lo12:spi_mode
    mov     x8, #SYS_ioctl
    svc     #0
    cmp     x0, #0
    b.lt    configure_done

    mov     x0, x19
    ldr     x1, =SPI_IOC_WR_BITS_PER_WORD
    adrp    x2, spi_bits
    add     x2, x2, :lo12:spi_bits
    mov     x8, #SYS_ioctl
    svc     #0
    cmp     x0, #0
    b.lt    configure_done

    mov     x0, x19
    ldr     x1, =SPI_IOC_WR_MAX_SPEED_HZ
    adrp    x2, spi_speed
    add     x2, x2, :lo12:spi_speed
    mov     x8, #SYS_ioctl
    svc     #0
configure_done:
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

spi_read_frame:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp
    mov     x19, x0

    adrp    x2, spi_transfer
    add     x2, x2, :lo12:spi_transfer
    adrp    x3, tx_dummy
    add     x3, x3, :lo12:tx_dummy
    str     x3, [x2, #0]
    str     x1, [x2, #8]

    mov     x0, x19
    ldr     x1, =SPI_IOC_MESSAGE_1
    mov     x8, #SYS_ioctl
    svc     #0
    cmp     x0, #0
    b.lt    frame_done
    mov     x0, #0
frame_done:
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

copy_frame_for:
    mov     w2, #0
copy_frame_for_loop:
    cmp     w2, #FRAME_SIZE
    b.ge    copy_frame_for_done
    ldrb    w3, [x0, w2, uxtw]
    strb    w3, [x1, w2, uxtw]
    add     w2, w2, #1
    b       copy_frame_for_loop
copy_frame_for_done:
    ret

// -----------------------------------------------------------------------------
// capture_all_sensors: o main possui o frame e distribui os campos extraidos
// para os modulos de sensores sem duplicar a recepcao SPI.
// -----------------------------------------------------------------------------
capture_all_sensors:
    stp     x29, x30, [sp, #-48]!
    stp     x19, x20, [sp, #16]
    str     x21, [sp, #32]
    mov     x29, sp
    mov     x19, x0

    adrp    x1, frame_buffer
    add     x1, x1, :lo12:frame_buffer
    bl      spi_read_frame
    cmp     x0, #0
    b.lt    capture_error

    adrp    x20, frame_buffer
    add     x20, x20, :lo12:frame_buffer
    ldrb    w0, [x20, #0]
    cmp     w0, #0xA5
    b.ne    capture_error

    // Keep an intact snapshot before field extraction.
    mov     x0, x20
    adrp    x1, frame_snapshot
    add     x1, x1, :lo12:frame_snapshot
    bl      copy_frame_for

    // --------------------------------------------------------
    // BMP180: bytes 1..2 temperature, bytes 10..13 pressure.
    // main.s owns the frame parsing and sends values to sub_bmp180.s.
    // --------------------------------------------------------
    ldrb    w0, [x20, #1]
    ldrb    w2, [x20, #2]
    lsl     w0, w0, #8
    orr     w0, w0, w2
    ldrb    w1, [x20, #10]
    ldrb    w2, [x20, #11]
    ldrb    w3, [x20, #12]
    ldrb    w4, [x20, #13]
    lsl     w1, w1, #24
    lsl     w2, w2, #16
    lsl     w3, w3, #8
    orr     w1, w1, w2
    orr     w1, w1, w3
    orr     w1, w1, w4
    bl      sub_bmp180_process

    // --------------------------------------------------------
    // LM35: processed temperature bytes 3..4 + raw ADC bytes 6..7.
    // main.s extracts both and sub_lm35.s receives the values directly.
    // --------------------------------------------------------
    ldrb    w0, [x20, #3]
    ldrb    w2, [x20, #4]
    lsl     w0, w0, #8
    orr     w0, w0, w2
    ldrb    w1, [x20, #6]
    ldrb    w2, [x20, #7]
    lsl     w1, w1, #8
    orr     w1, w1, w2
    and     w1, w1, #0x03ff
    bl      sub_lm35_process

    // --------------------------------------------------------
    // Potentiometer: percent byte 5 + raw ADC bytes 8..9.
    // main.s extracts both and sub_pot.s receives the values directly.
    // --------------------------------------------------------
    ldrb    w0, [x20, #5]
    ldrb    w1, [x20, #8]
    ldrb    w2, [x20, #9]
    lsl     w1, w1, #8
    orr     w1, w1, w2
    and     w1, w1, #0x03ff
    bl      sub_pot_process

    // The successful return value remains the frame marker, as in the baseline.
    mov     w0, #0xA5
    b       capture_done
capture_error:
    mov     w0, #-1
capture_done:
    ldr     x21, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #48
    ret

// -----------------------------------------------------------------------------
// Panels.
// -----------------------------------------------------------------------------
print_sensor_values:
    stp     x29, x30, [sp, #-16]!
    mov     x29, sp

    adrp    x0, panel_begin
    add     x0, x0, :lo12:panel_begin
    mov     x1, #panel_begin_end-panel_begin
    bl      write_str

    adrp    x0, panel_bmp_label
    add     x0, x0, :lo12:panel_bmp_label
        mov     x1, #panel_bmp_label_end-panel_bmp_label
    bl      write_str
    adrp    x1, bmp180_value
    add     x1, x1, :lo12:bmp180_value
    ldrsh   w0, [x1]
    bl      print_temperature_x10

    adrp    x0, panel_pressure_label
    add     x0, x0, :lo12:panel_pressure_label
        mov     x1, #panel_pressure_label_end-panel_pressure_label
    bl      write_str
    adrp    x1, pressure_pa_value
    add     x1, x1, :lo12:pressure_pa_value
    ldr     w0, [x1]
    bl      print_u32
    adrp    x0, panel_pressure_suffix
    add     x0, x0, :lo12:panel_pressure_suffix
    mov     x1, #panel_pressure_suffix_end-panel_pressure_suffix
    bl      write_str

    adrp    x0, panel_temp_label
    add     x0, x0, :lo12:panel_temp_label
        mov     x1, #panel_temp_label_end-panel_temp_label
    bl      write_str
    adrp    x1, temperature_x10_value
    add     x1, x1, :lo12:temperature_x10_value
    ldrh    w0, [x1]
    bl      print_temperature_x10

    adrp    x0, panel_pot_percent_label
    add     x0, x0, :lo12:panel_pot_percent_label
        mov     x1, #panel_pot_percent_label_end-panel_pot_percent_label
    bl      write_str
    adrp    x1, pot_percent_value
    add     x1, x1, :lo12:pot_percent_value
    ldrb    w0, [x1]
    bl      print_u32
    adrp    x0, panel_percent_suffix
    add     x0, x0, :lo12:panel_percent_suffix
    mov     x1, #panel_percent_suffix_end-panel_percent_suffix
    bl      write_str

    adrp    x0, panel_lm35_raw_label
    add     x0, x0, :lo12:panel_lm35_raw_label
        mov     x1, #panel_lm35_raw_label_end-panel_lm35_raw_label
    bl      write_str
    adrp    x1, lm35_value
    add     x1, x1, :lo12:lm35_value
    ldrh    w0, [x1]
    bl      print_u32
    adrp    x0, panel_adc_suffix
    add     x0, x0, :lo12:panel_adc_suffix
    mov     x1, #panel_adc_suffix_end-panel_adc_suffix
    bl      write_str

    adrp    x0, panel_pot_raw_label
    add     x0, x0, :lo12:panel_pot_raw_label
        mov     x1, #panel_pot_raw_label_end-panel_pot_raw_label
    bl      write_str
    adrp    x1, potentiometer_value
    add     x1, x1, :lo12:potentiometer_value
    ldrh    w0, [x1]
    bl      print_u32
    adrp    x0, panel_adc_suffix
    add     x0, x0, :lo12:panel_adc_suffix
    mov     x1, #panel_adc_suffix_end-panel_adc_suffix
    bl      write_str

    adrp    x0, panel_end
    add     x0, x0, :lo12:panel_end
    mov     x1, #panel_end_end-panel_end
    bl      write_str

    ldp     x29, x30, [sp], #16
    ret

print_integrated_panel:
    stp     x29, x30, [sp, #-16]!
    mov     x29, sp
    bl      print_sensor_values
    bl      print_motor_panel
    adrp    x0, integrated_panel_footer
    add     x0, x0, :lo12:integrated_panel_footer
    mov     x1, #integrated_panel_footer_end-integrated_panel_footer
    bl      write_str
    ldp     x29, x30, [sp], #16
    ret

print_temperature_x10:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp
    mov     w19, w0
    mov     w0, #10
    udiv    w20, w19, w0
    msub    w19, w20, w0, w19
    mov     w0, w20
    bl      print_u32
    adrp    x0, decimal_point
    add     x0, x0, :lo12:decimal_point
    mov     x1, #1
    bl      write_str
    mov     w0, w19
    bl      print_u32
    adrp    x0, temp_c_suffix
    add     x0, x0, :lo12:temp_c_suffix
    mov     x1, #4
    bl      write_str
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

print_invalid_frame_panel:
    adrp    x0, panel_invalid
    add     x0, x0, :lo12:panel_invalid
    mov     x1, #panel_invalid_end-panel_invalid
    b       write_str

print_u32:
    stp     x29, x30, [sp, #-80]!
    stp     x19, x20, [sp, #16]
    stp     x21, x22, [sp, #32]
    mov     x29, sp
    mov     w19, w0
    add     x21, sp, #64
    mov     w22, #0
    cbnz    w19, convert_digit
    sub     x21, x21, #1
    mov     w0, #'0'
    strb    w0, [x21]
    mov     w22, #1
    b       write_number
convert_digit:
    mov     w0, #10
    udiv    w1, w19, w0
    msub    w2, w1, w0, w19
    add     w2, w2, #'0'
    sub     x21, x21, #1
    strb    w2, [x21]
    mov     w19, w1
    add     w22, w22, #1
    cbnz    w19, convert_digit
write_number:
    mov     x0, #1
    mov     x1, x21
    mov     w2, w22
    mov     x8, #SYS_write
    svc     #0
    ldp     x21, x22, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #80
    ret

print_s64:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp
    mov     x19, x0
    tbz     x19, #63, print_s64_positive
    adrp    x0, minus_sign
    add     x0, x0, :lo12:minus_sign
    mov     x1, #1
    bl      write_str
    neg     x19, x19
print_s64_positive:
    mov     x0, x19
    adrp    x1, pwm_number_buf
    add     x1, x1, :lo12:pwm_number_buf
    bl      u64_to_buf
    mov     x2, x1
    mov     x1, x0
    mov     x0, #1
    mov     x8, #SYS_write
    svc     #0
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

print_fixed100:
    stp     x29, x30, [sp, #-48]!
    stp     x19, x20, [sp, #16]
    stp     x21, x22, [sp, #32]
    mov     x29, sp
    mov     x19, x0
    mov     x20, #100
    udiv    x0, x19, x20
    bl      print_u32
    adrp    x0, motor_decimal_point
    add     x0, x0, :lo12:motor_decimal_point
    mov     x1, #1
    bl      write_str
    msub    x21, x19, x20, x19
    cmp     x21, #10
    b.ge    fixed100_two_digits
    adrp    x0, zero_digit
    add     x0, x0, :lo12:zero_digit
    mov     x1, #1
    bl      write_str
fixed100_two_digits:
    mov     x0, x21
    bl      print_u32
    ldp     x21, x22, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #48
    ret

write_str:
    mov     x2, x1
    mov     x1, x0
    mov     x0, #1
    mov     x8, #SYS_write
    svc     #0
    ret

sysfs_write_str:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp
    mov     x19, x0
    mov     x20, x1
    mov     x0, x20
    bl      strlen
    mov     x2, x0
    mov     x0, x19
    mov     x1, x20
    bl      sysfs_write_buf
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

sysfs_write_buf:
    stp     x29, x30, [sp, #-48]!
    stp     x19, x20, [sp, #16]
    str     x21, [sp, #32]
    mov     x29, sp
    mov     x19, x0
    mov     x20, x1
    mov     x21, x2
    mov     x0, #AT_FDCWD
    mov     x1, x19
    mov     x2, #O_WRONLY
    mov     x3, #0
    mov     x8, #SYS_openat
    svc     #0
    cmp     x0, #0
    b.lt    sysfs_write_done
    mov     x19, x0
    mov     x0, x19
    mov     x1, x20
    mov     x2, x21
    mov     x8, #SYS_write
    svc     #0
    mov     x21, x0
    mov     x0, x19
    mov     x8, #SYS_close
    svc     #0
    mov     x0, x21
sysfs_write_done:
    ldr     x21, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #48
    ret

strlen:
    mov     x2, x0
strlen_loop:
    ldrb    w3, [x2]
    cbz     w3, strlen_done
    add     x2, x2, #1
    b       strlen_loop
strlen_done:
    sub     x0, x2, x0
    ret

u64_to_buf:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp
    mov     x19, x0
    mov     x20, x1
    add     x2, x1, #31
    mov     w3, #0
    cbnz    x19, u64_loop
    sub     x2, x2, #1
    mov     w4, #'0'
    strb    w4, [x2]
    mov     w3, #1
    b       u64_done
u64_loop:
    mov     x4, #10
    udiv    x5, x19, x4
    msub    x6, x5, x4, x19
    add     x6, x6, #'0'
    sub     x2, x2, #1
    strb    w6, [x2]
    mov     x19, x5
    add     w3, w3, #1
    cbnz    x19, u64_loop
u64_done:
    mov     x0, x2
    mov     x1, x3
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

zero_buffer:
    mov     x2, #0
zero_buffer_loop:
    cmp     x2, x1
    b.ge    zero_buffer_done
    strb    wzr, [x0, x2]
    add     x2, x2, #1
    b       zero_buffer_loop
zero_buffer_done:
    ret

clock_monotonic_ns:
    adrp    x1, clock_ts
    add     x1, x1, :lo12:clock_ts
    mov     x0, #CLOCK_MONOTONIC
    mov     x8, #SYS_clock_gettime
    svc     #0
    cmp     x0, #0
    b.lt    clock_ns_fail
    adrp    x1, clock_ts
    add     x1, x1, :lo12:clock_ts
    ldr     x2, [x1, #0]
    ldr     x3, [x1, #8]
    ldr     x4, =1000000000
    mul     x2, x2, x4
    add     x0, x2, x3
    ret
clock_ns_fail:
    mov     x0, #-1
    ret

sleep_1ms:
    adrp    x0, sleep_1ms_time
    add     x0, x0, :lo12:sleep_1ms_time
    mov     x1, #0
    mov     x8, #SYS_nanosleep
    svc     #0
    ret

sleep_200ms:
    adrp    x0, sleep_time
    add     x0, x0, :lo12:sleep_time
    mov     x1, #0
    mov     x8, #SYS_nanosleep
    svc     #0
    ret

gpio_shadow_demo:
    adrp    x0, gpio_shadow_registers
    add     x0, x0, :lo12:gpio_shadow_registers
    mov     w1, #(1 << 17)
    str     w1, [x0, #0x1C]
    ldr     w2, [x0, #0x1C]
    str     w2, [x0, #0x34]
    ldr     w3, [x0, #0x34]
    tst     w3, w1
    b.eq    gpio_shadow_error
    str     wzr, [x0, #0x28]
    adrp    x0, gpio_demo_ok_msg
    add     x0, x0, :lo12:gpio_demo_ok_msg
    mov     x1, #gpio_demo_ok_msg_end-gpio_demo_ok_msg
    b       write_str
gpio_shadow_error:
    adrp    x0, gpio_demo_error_msg
    add     x0, x0, :lo12:gpio_demo_error_msg
    mov     x1, #gpio_demo_error_msg_end-gpio_demo_error_msg
    b       write_str

.section .rodata
.align 3
gpio_chip_path:
    .asciz "/dev/gpiochip0"
spi_device:
    .asciz "/dev/spidev0.0"
help_msg:
    .ascii "Uso: ./tp4_program [s|g|h|m|q|1|2|3|4]\n"
help_msg_end:
invalid_command_msg:
    .ascii "Comando invalido; iniciando monitoramento.\n"
invalid_command_msg_end:
motor_init_error_msg_main:
    .ascii "Motor init failed for integrated mode.\n"
motor_init_error_msg_main_end:
invalid_frame_msg:
    .ascii "SPI frame invalida\n"
invalid_frame_msg_end:
panel_begin:
    .ascii "\033[40m\033[37m\033[2J\033[H"
    .ascii "\n  +----------------------------------------------------------------------+\n"
    .ascii "  | TP4 - MONITOR SPI: Raspberry Pi 4 <-> Tang Nano 4K                  |\n"
    .ascii "  +----------------------------------------------------------------------+\n"
    .ascii "  | Frame: VALIDO (0xA5)                                                |\n"
    .ascii "  +----------------------------------------------------------------------+\n"
panel_begin_end:
panel_bmp_label:
    .ascii "  | BMP180 REAL (Tang Nano) - Temperatura: "
panel_bmp_label_end:
panel_pressure_label:
    .ascii "  | BMP180 REAL (Tang Nano) - Pressao: "
panel_pressure_label_end:
panel_pressure_suffix:
    .ascii " Pa                                             |\n"
panel_pressure_suffix_end:
panel_temp_label:
    .ascii "  | LM35 REAL (Tang Nano) - Temperatura: "
panel_temp_label_end:
panel_pot_percent_label:
    .ascii "  | POT REAL (Tang Nano) - Percentual: "
panel_pot_percent_label_end:
panel_percent_suffix:
    .ascii " %                                             |\n"
panel_percent_suffix_end:
panel_lm35_raw_label:
    .ascii "  | LM35 REAL - ADC bruto: "
panel_lm35_raw_label_end:
panel_pot_raw_label:
    .ascii "  | POT REAL - ADC bruto: "
panel_pot_raw_label_end:
panel_adc_suffix:
    .ascii " / 1023                                      |\n"
panel_adc_suffix_end:
panel_end:
    .ascii "  +----------------------------------------------------------------------+\n"
    .ascii "  | Atualizacao SPI a cada 200 ms.                                     |\n"
    .ascii "  +----------------------------------------------------------------------+\n\033[0m"
panel_end_end:
panel_invalid:
    .ascii "\033[40m\033[37m\033[2J\033[H"
    .ascii "\n  +----------------------------------------------------------------------+\n"
    .ascii "  | TP4 - MONITOR DE SENSORES                                          |\n"
    .ascii "  +----------------------------------------------------------------------+\n"
    .ascii "  | Frame INVALIDO - marcador 0xA5 nao recebido.                       |\n"
    .ascii "  | Motor mantido DESLIGADO no modo integrado.                         |\n"
    .ascii "  +----------------------------------------------------------------------+\n\033[0m"
panel_invalid_end:
integrated_panel_footer:
    .ascii "  +----------------------------------------------------------------------+\n\033[0m"
integrated_panel_footer_end:
gpio_demo_ok_msg:
    .ascii "Teste GPIO simulado aprovado.\n"
gpio_demo_ok_msg_end:
gpio_demo_error_msg:
    .ascii "Teste GPIO simulado falhou.\n"
gpio_demo_error_msg_end:
minus_sign:
    .ascii "-"
zero_digit:
    .ascii "0"
motor_decimal_point:
    .ascii "."
decimal_point:
    .ascii "."
temp_c_suffix:
    .ascii " C\n"
newline:
    .ascii "\n"

.align 3
command_jump_table:
    .quad command_gpio     // g
    .quad command_help     // h
    .quad 0                // i
    .quad 0                // j
    .quad 0                // k
    .quad 0                // l
    .quad command_motor    // m
    .quad 0                // n
    .quad 0                // o
    .quad 0                // p
    .quad command_quit     // q
    .quad 0                // r
    .quad command_status   // s

.section .data
.align 3
spi_mode:
    .byte   0
spi_bits:
    .byte   8
    .align 2
spi_speed:
    .word   SPI_SPEED_HZ
.align 3
spi_transfer:
    .quad   tx_dummy
    .quad   frame_buffer
    .word   FRAME_SIZE
    .word   SPI_SPEED_HZ
    .hword  0
    .byte   8
    .byte   0
    .byte   0
    .byte   0
    .byte   0
    .byte   0
sleep_1ms_time:
    .quad   0
    .quad   1000000
sleep_time:
    .quad   0
    .quad   200000000
active_spi_fd:
    .quad   -1
motor_gpio_fd:
    .quad -1
encoder_fd:
    .quad -1
tx_dummy:
    .byte   0,0,0,0,0,0,0,0,0,0,0,0,0,0

.align 3
sigint_action:
    .quad 0
    .quad 0
    .quad 0
    .quad 0

.align 2
selected_state:
    .word 1

.section .bss
.align 3
frame_buffer:
    .skip FRAME_SIZE
frame_snapshot:
    .skip FRAME_SIZE
.align 2
bmp180_value:
    .skip 2
pressure_pa_value:
    .skip 4
temperature_x10_value:
    .skip 2
pot_percent_value:
    .skip 1
lm35_value:
    .skip 2
potentiometer_value:
    .skip 2
.align 8
encoder_state:
    .word 0
last_encoder_state:
    .word 0
encoder_count:
    .quad 0
previous_count:
    .quad 0
stage_start_ns:
    .quad 0
last_print_ns:
    .quad 0
stage_last_measure_ns:
    .quad 0
stage_elapsed_ns:
    .quad 0
pps_value:
    .quad 0
clock_ts:
    .quad 0
    .quad 0
pwm_number_buf:
    .skip 32
gpio_values:
    .skip 16
motor_gpio_request:
    .skip GPIO_V2_REQ_SIZE
encoder_request:
    .skip GPIO_V2_REQ_SIZE
encoder_event_buf:
    .skip (GPIO_V2_EVENT_SIZE * 32)
gpio_shadow_registers:
    .skip 256

.end
