.arch armv8-a
.include "common.inc"
.text

.extern motor_gpio_fd
.extern encoder_fd
.extern encoder_state
.extern last_encoder_state
.extern encoder_count
.extern previous_count
.extern stage_start_ns
.extern last_print_ns
.extern stage_last_measure_ns
.extern stage_elapsed_ns
.extern pps_value
.extern clock_ts
.extern pwm_number_buf
.extern gpio_values
.extern motor_gpio_request
.extern encoder_request
.extern encoder_event_buf
.extern newline
.extern active_spi_fd

.extern write_str
.extern print_u32
.extern print_s64
.extern print_fixed100
.extern u64_to_buf
.extern sysfs_write_str
.extern sysfs_write_buf
.extern strlen
.extern zero_buffer
.extern clock_monotonic_ns
.extern sleep_1ms
.extern pot_percent_to_pwm
.extern print_temperature_x10

.global motor_init
.global motor_stop
.global motor_set_direction
.global motor_set_pwm
.global encoder_init
.global encoder_update
.global encoder_calculate_rpm
.global motor_test_mode
.global motor_control_update
.global motor_force_disable
.global motor_feedback_update
.global motor_evaluate_state
.global print_motor_panel
.global motor_shutdown_all

.global motor_enable
.global motor_pwm_percent
.global motor_rpm_x100
.global motor_rpm_percent_x100
.global motor_direction_code
.global motor_actuator_error
.global motor_safety_ok
.global motor_selected_state
.global simulated_ckp_rpm
.global simulated_cmp_ok
.global simulated_maf_gps

// -----------------------------------------------------------------------------
// motor_init
// -----------------------------------------------------------------------------
motor_init:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp

    // Estado inicial: o atuador ainda nao foi inicializado com sucesso.
    adrp    x1, motor_initialized
    add     x1, x1, :lo12:motor_initialized
    str     wzr, [x1]

    bl      motor_gpio_init
    cmp     x0, #0
    b.lt    motor_init_fail

    bl      pwm_sysfs_init
    cmp     x0, #0
    b.lt    motor_init_fail_gpio

    // A parada inicial tambem e uma operacao real do atuador. Seu retorno
    // precisa ser consumido imediatamente; sem isso uma falha de direcao ou
    // PWM seria ocultada e o subsistema poderia ser marcado como inicializado.
    bl      motor_stop
    cmp     w0, #0
    b.lt    motor_init_fail_pwm

    bl      encoder_init
    cmp     x0, #0
    b.lt    motor_init_fail_pwm

    adrp    x1, motor_enable
    add     x1, x1, :lo12:motor_enable
    str     wzr, [x1]
    adrp    x1, motor_pwm_percent
    add     x1, x1, :lo12:motor_pwm_percent
    str     wzr, [x1]
    adrp    x1, motor_rpm_x100
    add     x1, x1, :lo12:motor_rpm_x100
    str     xzr, [x1]
    adrp    x1, motor_rpm_percent_x100
    add     x1, x1, :lo12:motor_rpm_percent_x100
    str     xzr, [x1]
    adrp    x1, motor_direction_code
    add     x1, x1, :lo12:motor_direction_code
    str     wzr, [x1]
    adrp    x1, motor_safety_ok
    add     x1, x1, :lo12:motor_safety_ok
    str     wzr, [x1]
    adrp    x1, motor_measure_valid
    add     x1, x1, :lo12:motor_measure_valid
    str     wzr, [x1]

    // Somente agora o subsistema do motor e considerado inicializado.
    adrp    x1, motor_initialized
    add     x1, x1, :lo12:motor_initialized
    mov     w2, #1
    str     w2, [x1]

    mov     w0, #0
    b       motor_init_done

motor_init_fail_pwm:
    bl      pwm_disable
motor_init_fail_gpio:
    bl      motor_gpio_close
motor_init_fail:
    mov     w0, #-1
motor_init_done:
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

// -----------------------------------------------------------------------------
// GPIO / PWM low level.
// -----------------------------------------------------------------------------
motor_gpio_init:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp

    mov     x0, #AT_FDCWD
    adrp    x1, gpio_chip_path
    add     x1, x1, :lo12:gpio_chip_path
    mov     x2, #O_RDWR
    mov     x3, #0
    mov     x8, #SYS_openat
    svc     #0
    cmp     x0, #0
    b.lt    motor_gpio_open_fail
    mov     x19, x0

    adrp    x20, motor_gpio_request
    add     x20, x20, :lo12:motor_gpio_request
    mov     x0, x20
    mov     x1, #GPIO_V2_REQ_SIZE
    bl      zero_buffer

    mov     w0, #GPIO5
    str     w0, [x20, #0]
    mov     w0, #GPIO6
    str     w0, [x20, #4]
    mov     x0, #GPIO_V2_LINE_FLAG_OUTPUT
    str     x0, [x20, #288]
    mov     w0, #1
    str     w0, [x20, #296]
    mov     w0, #GPIO_V2_LINE_ATTR_ID_OUTPUT_VALUES
    str     w0, [x20, #320]
    str     wzr, [x20, #328]
    mov     x0, #3
    str     x0, [x20, #328]
    str     x0, [x20, #336]
    mov     w0, #2
    str     w0, [x20, #560]

    mov     x0, x19
    ldr     x1, =GPIO_V2_GET_LINE_IOCTL
    mov     x2, x20
    mov     x8, #SYS_ioctl
    svc     #0
    cmp     x0, #0
    b.lt    motor_gpio_ioctl_fail

    ldrsw   x0, [x20, #588]
    adrp    x1, motor_gpio_fd
    add     x1, x1, :lo12:motor_gpio_fd
    str     x0, [x1]

    mov     x0, x19
    mov     x8, #SYS_close
    svc     #0
    mov     w0, #0
    b       motor_gpio_done

motor_gpio_ioctl_fail:
    mov     x0, x19
    mov     x8, #SYS_close
    svc     #0
motor_gpio_open_fail:
    mov     w0, #-1
motor_gpio_done:
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

motor_gpio_close:
    adrp    x1, motor_gpio_fd
    add     x1, x1, :lo12:motor_gpio_fd
    ldr     x0, [x1]
    cmp     x0, #0
    b.lt    motor_gpio_close_done
    mov     x8, #SYS_close
    svc     #0
    mov     x0, #-1
    str     x0, [x1]
motor_gpio_close_done:
    ret

pwm_sysfs_init:
    // Inicializa PWM0 do controlador de PWM usado pelo GPIO18.
    // O export pode retornar EBUSY quando o canal ja esta exportado;
    // nesse caso o canal existente deve ser reutilizado.
    stp     x29, x30, [sp, #-16]!
    mov     x29, sp

    adrp    x0, pwm_export_path
    add     x0, x0, :lo12:pwm_export_path
    adrp    x1, pwm_zero_str
    add     x1, x1, :lo12:pwm_zero_str
    bl      sysfs_write_str

    // -16 = EBUSY e -17 = EEXIST: o canal ja foi exportado e pode ser
    // reutilizado. Outros retornos negativos permanecem falhas reais.
    cmp     x0, #-16
    b.eq    pwm_export_ready
    cmp     x0, #-17
    b.eq    pwm_export_ready
    cmp     x0, #0
    b.lt    pwm_sysfs_fail

pwm_export_ready:
    // Aguarda a criacao de pwm0 apos o export.
    mov     w0, #1
    bl      sleep_1ms

    // Garante 0% antes de qualquer reconfiguracao.
    adrp    x0, pwm_enable_path
    add     x0, x0, :lo12:pwm_enable_path
    adrp    x1, pwm_zero_str
    add     x1, x1, :lo12:pwm_zero_str
    bl      sysfs_write_str
    cmp     x0, #0
    b.lt    pwm_sysfs_fail

    // Periodo de 1 ms -> 1 kHz.
    adrp    x0, pwm_period_path
    add     x0, x0, :lo12:pwm_period_path
    adrp    x1, pwm_period_str
    add     x1, x1, :lo12:pwm_period_str
    bl      sysfs_write_str
    cmp     x0, #0
    b.lt    pwm_sysfs_fail

    // Duty inicial em zero.
    adrp    x0, pwm_duty_path
    add     x0, x0, :lo12:pwm_duty_path
    adrp    x1, pwm_zero_str
    add     x1, x1, :lo12:pwm_zero_str
    bl      sysfs_write_str
    cmp     x0, #0
    b.lt    pwm_sysfs_fail

    mov     w0, #0
    b       pwm_sysfs_done

pwm_sysfs_fail:
    mov     w0, #-1
pwm_sysfs_done:
    ldp     x29, x30, [sp], #16
    ret

pwm_disable:
    adrp    x0, pwm_enable_path
    add     x0, x0, :lo12:pwm_enable_path
    adrp    x1, pwm_zero_str
    add     x1, x1, :lo12:pwm_zero_str
    b       sysfs_write_str

motor_set_direction:
    // w0 = 0 stop, 1 forward, 2 reverse.
    stp     x29, x30, [sp, #-16]!
    mov     x29, sp
    mov     w2, w0

    adrp    x1, motor_gpio_fd
    add     x1, x1, :lo12:motor_gpio_fd
    ldr     x0, [x1]
    cmp     x0, #0
    b.lt    motor_set_direction_fail

    adrp    x1, gpio_values
    add     x1, x1, :lo12:gpio_values
    mov     x3, #3
    str     x3, [x1, #8]
    mov     x3, #0
    cmp     w2, #1
    b.eq    motor_dir_forward
    cmp     w2, #2
    b.eq    motor_dir_reverse
    b       motor_dir_store
motor_dir_forward:
    mov     x3, #1
    b       motor_dir_store
motor_dir_reverse:
    mov     x3, #2
motor_dir_store:
    str     x3, [x1, #0]
    mov     x2, x1
    ldr     x1, =GPIO_V2_LINE_SET_VALUES_IOCTL
    mov     x8, #SYS_ioctl
    svc     #0
    cmp     x0, #0
    b.lt    motor_set_direction_fail
    adrp    x1, motor_actuator_error
    add     x1, x1, :lo12:motor_actuator_error
    str     wzr, [x1]
    mov     w0, #0
    b       motor_set_direction_done
motor_set_direction_fail:
    adrp    x1, motor_actuator_error
    add     x1, x1, :lo12:motor_actuator_error
    mov     w2, #1
    str     w2, [x1]
    mov     w0, #-1
motor_set_direction_done:
    ldp     x29, x30, [sp], #16
    ret

motor_stop:
    // Para fisicamente o motor: PWM=0 e AIN1/AIN2=0.
    // O retorno so indica sucesso quando as duas operacoes de parada foram aceitas.
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp

    // Primeiro remove o comando de direcao.
    mov     w0, #0
    bl      motor_set_direction
    mov     w19, w0

    // Depois desabilita o PWM.
    bl      pwm_disable
    mov     w20, w0

    // Se a direcao falhou, preserve esse diagnostico.
    cmp     w19, #0
    b.lt    motor_stop_direction_error

    // Se a desabilitacao do PWM falhou, e uma falha real do atuador.
    cmp     w20, #0
    b.lt    motor_stop_pwm_error

    adrp    x1, motor_actuator_error
    add     x1, x1, :lo12:motor_actuator_error
    str     wzr, [x1]
    mov     w0, #0
    b       motor_stop_done

motor_stop_direction_error:
    adrp    x1, motor_actuator_error
    add     x1, x1, :lo12:motor_actuator_error
    mov     w2, #1
    str     w2, [x1]
    mov     w0, #-1
    b       motor_stop_done

motor_stop_pwm_error:
    adrp    x1, motor_actuator_error
    add     x1, x1, :lo12:motor_actuator_error
    mov     w2, #2
    str     w2, [x1]
    mov     w0, #-1

motor_stop_done:
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

motor_set_pwm:
    // Entrada: W0 = duty logico em percentual, 0..100.
    // Saida: W0 = 0 em sucesso, -1 em falha.
    // A frequencia permanece em 1 kHz. O valor fisico do duty e escrito
    // e o canal e habilitado conforme a sequencia funcional de referencia.
    stp     x29, x30, [sp, #-48]!
    stp     x19, x20, [sp, #16]
    str     x21, [sp, #32]
    mov     x29, sp

    and     w19, w0, #0xff
    cmp     w19, #100
    b.ls    motor_pwm_percent_ok
    mov     w19, #100
motor_pwm_percent_ok:

    // A referencia funcional escreve o duty e habilita o canal sem inserir
    // uma desabilitacao entre comandos. O PWM ja foi colocado em estado
    // seguro por pwm_sysfs_init ou pelo comando anterior, portanto esta
    // sequencia evita o comportamento observado de pulso seguido de parada.
    // Percentual -> nanossegundos.
    mov     w20, #10000
    umull   x0, w19, w20

    // Evita duty == period no limite de 100%.
    ldr     x1, =PWM_PERIOD_NS
    cmp     x0, x1
    b.lo    motor_pwm_duty_ready
    sub     x0, x1, #1
motor_pwm_duty_ready:

    adrp    x1, pwm_number_buf
    add     x1, x1, :lo12:pwm_number_buf
    bl      u64_to_buf
    mov     x2, x1
    mov     x1, x0
    adrp    x0, pwm_duty_path
    add     x0, x0, :lo12:pwm_duty_path
    bl      sysfs_write_buf
    cmp     x0, #0
    b.lt    motor_pwm_error

    // Habilita o canal somente apos duty e periodo serem aceitos.
    adrp    x0, pwm_enable_path
    add     x0, x0, :lo12:pwm_enable_path
    adrp    x1, pwm_one_str
    add     x1, x1, :lo12:pwm_one_str
    bl      sysfs_write_str
    cmp     x0, #0
    b.ge    motor_pwm_success

    // Pequena recuperacao de uma possivel corrida de criacao/export do PWM.
    mov     w0, #1
    bl      sleep_1ms
    adrp    x0, pwm_enable_path
    add     x0, x0, :lo12:pwm_enable_path
    adrp    x1, pwm_one_str
    add     x1, x1, :lo12:pwm_one_str
    bl      sysfs_write_str
    cmp     x0, #0
    b.lt    motor_pwm_error

motor_pwm_success:
    adrp    x1, motor_actuator_error
    add     x1, x1, :lo12:motor_actuator_error
    str     wzr, [x1]
    mov     w0, #0
    b       motor_pwm_done

motor_pwm_error:
    adrp    x1, motor_actuator_error
    add     x1, x1, :lo12:motor_actuator_error
    mov     w2, #2
    str     w2, [x1]
    mov     w0, #-1

motor_pwm_done:
    ldr     x21, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #48
    ret

// -----------------------------------------------------------------------------
// Encoder.
// -----------------------------------------------------------------------------
encoder_init:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp

    mov     x0, #AT_FDCWD
    adrp    x1, gpio_chip_path
    add     x1, x1, :lo12:gpio_chip_path
    mov     x2, #O_RDWR
    mov     x3, #0
    mov     x8, #SYS_openat
    svc     #0
    cmp     x0, #0
    b.lt    encoder_init_fail
    mov     x19, x0

    adrp    x20, encoder_request
    add     x20, x20, :lo12:encoder_request
    mov     x0, x20
    mov     x1, #GPIO_V2_REQ_SIZE
    bl      zero_buffer

    mov     w0, #GPIO17
    str     w0, [x20, #0]
    mov     w0, #GPIO27
    str     w0, [x20, #4]
    mov     x0, #(GPIO_V2_LINE_FLAG_INPUT | GPIO_V2_LINE_FLAG_EDGE_RISING | GPIO_V2_LINE_FLAG_EDGE_FALLING | GPIO_V2_LINE_FLAG_BIAS_PULL_UP)
    str     x0, [x20, #288]
    mov     w0, #2
    str     w0, [x20, #560]
    mov     w0, #GPIO_V2_EVENT_BUF_SIZE
    str     w0, [x20, #564]

    mov     x0, x19
    ldr     x1, =GPIO_V2_GET_LINE_IOCTL
    mov     x2, x20
    mov     x8, #SYS_ioctl
    svc     #0
    cmp     x0, #0
    b.lt    encoder_init_fail_chip

    ldrsw   x0, [x20, #588]
    adrp    x1, encoder_fd
    add     x1, x1, :lo12:encoder_fd
    str     x0, [x1]

    mov     x0, x19
    mov     x8, #SYS_close
    svc     #0

    ldr     x19, [x1]
    mov     x0, x19
    mov     x1, #F_GETFL
    mov     x8, #SYS_fcntl
    svc     #0
    cmp     x0, #0
    b.lt    encoder_init_fail_fd
    orr     x2, x0, #O_NONBLOCK
    mov     x0, x19
    mov     x1, #F_SETFL
    mov     x8, #SYS_fcntl
    svc     #0
    cmp     x0, #0
    b.lt    encoder_init_fail_fd

    mov     x0, x19
    adrp    x2, gpio_values
    add     x2, x2, :lo12:gpio_values
    mov     x3, #3
    str     x3, [x2, #8]
    ldr     x1, =GPIO_V2_LINE_GET_VALUES_IOCTL
    mov     x8, #SYS_ioctl
    svc     #0
    cmp     x0, #0
    b.lt    encoder_init_fail_fd

    adrp    x1, gpio_values
    add     x1, x1, :lo12:gpio_values
    ldr     x0, [x1, #0]
    and     x0, x0, #3
    adrp    x1, encoder_state
    add     x1, x1, :lo12:encoder_state
    str     w0, [x1]
    adrp    x1, last_encoder_state
    add     x1, x1, :lo12:last_encoder_state
    str     w0, [x1]
    adrp    x1, encoder_count
    add     x1, x1, :lo12:encoder_count
    str     xzr, [x1]

    mov     w0, #0
    b       encoder_init_done
encoder_init_fail_fd:
    bl      encoder_close
    b       encoder_init_fail
encoder_init_fail_chip:
    mov     x0, x19
    mov     x8, #SYS_close
    svc     #0
encoder_init_fail:
    mov     w0, #-1
encoder_init_done:
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

encoder_close:
    adrp    x1, encoder_fd
    add     x1, x1, :lo12:encoder_fd
    ldr     x0, [x1]
    cmp     x0, #0
    b.lt    encoder_close_done
    mov     x8, #SYS_close
    svc     #0
    mov     x0, #-1
    str     x0, [x1]
encoder_close_done:
    ret

encoder_update:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp
    adrp    x19, encoder_fd
    add     x19, x19, :lo12:encoder_fd
    ldr     x19, [x19]
    cmp     x19, #0
    b.lt    encoder_update_fail

encoder_read_again:
    mov     x0, x19
    adrp    x1, encoder_event_buf
    add     x1, x1, :lo12:encoder_event_buf
    mov     x2, #(GPIO_V2_EVENT_SIZE * 32)
    mov     x8, #SYS_read
    svc     #0
    cmp     x0, #0
    b.le    encoder_update_done
    mov     x20, x0
    mov     x1, #(GPIO_V2_EVENT_SIZE)
encoder_event_loop:
    cmp     x20, x1
    b.lt    encoder_read_again
    adrp    x2, encoder_event_buf
    add     x2, x2, :lo12:encoder_event_buf
    sub     x3, x0, x20
    add     x2, x2, x3
    ldr     w4, [x2, #8]
    ldr     w5, [x2, #12]
    adrp    x6, encoder_state
    add     x6, x6, :lo12:encoder_state
    ldr     w7, [x6]

    cmp     w5, #GPIO17
    b.eq    encoder_event_a
    cmp     w5, #GPIO27
    b.ne    encoder_event_next

    cmp     w4, #1
    b.eq    encoder_b_high
    bic     w7, w7, #2
    b       encoder_state_ready
encoder_b_high:
    orr     w7, w7, #2
    b       encoder_state_ready

encoder_event_a:
    cmp     w4, #1
    b.eq    encoder_a_high
    bic     w7, w7, #1
    b       encoder_state_ready
encoder_a_high:
    orr     w7, w7, #1

encoder_state_ready:
    adrp    x2, last_encoder_state
    add     x2, x2, :lo12:last_encoder_state
    ldr     w4, [x2]
    lsl     w5, w4, #2
    orr     w5, w5, w7

    cmp     w5, #0x1
    b.eq    encoder_inc
    cmp     w5, #0x7
    b.eq    encoder_inc
    cmp     w5, #0xE
    b.eq    encoder_inc
    cmp     w5, #0x8
    b.eq    encoder_inc

    cmp     w5, #0x2
    b.eq    encoder_dec
    cmp     w5, #0xB
    b.eq    encoder_dec
    cmp     w5, #0xD
    b.eq    encoder_dec
    cmp     w5, #0x4
    b.eq    encoder_dec
    b       encoder_store_state

encoder_inc:
    adrp    x3, encoder_count
    add     x3, x3, :lo12:encoder_count
    ldr     x4, [x3]
    add     x4, x4, #1
    str     x4, [x3]
    b       encoder_store_state
encoder_dec:
    adrp    x3, encoder_count
    add     x3, x3, :lo12:encoder_count
    ldr     x4, [x3]
    sub     x4, x4, #1
    str     x4, [x3]
encoder_store_state:
    str     w7, [x6]
    str     w7, [x2]
encoder_event_next:
    sub     x20, x20, x1
    b       encoder_event_loop

encoder_update_done:
    mov     w0, #0
    b       encoder_update_exit
encoder_update_fail:
    mov     w0, #-1
encoder_update_exit:
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

// encoder_calculate_rpm
// Input: x0 = signed delta count, x1 = elapsed ns.
// Output: x0 = absolute RPM multiplied by 100.
encoder_calculate_rpm:
    cmp     x0, #0
    b.ge    rpm_abs_ready
    neg     x0, x0
rpm_abs_ready:
    ldr     x2, =600000000000000
    mul     x0, x0, x2
    ldr     x2, =ENCODER_PPR_NUM
    mul     x2, x2, x1
    udiv    x0, x0, x2
    ret

// -----------------------------------------------------------------------------
// ECU simulation and digital motor safety.
// ONLY CKP, CMP and MAF are simulated.
// POT, LM35 and BMP180 values are REAL values received from Tang Nano 4K.
// -----------------------------------------------------------------------------
motor_evaluate_state:
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp
    mov     w19, w0

    // Default values.
    adrp    x1, simulated_ckp_rpm
    add     x1, x1, :lo12:simulated_ckp_rpm
    str     wzr, [x1]
    adrp    x1, simulated_cmp_ok
    add     x1, x1, :lo12:simulated_cmp_ok
    str     wzr, [x1]
    adrp    x1, simulated_maf_gps
    add     x1, x1, :lo12:simulated_maf_gps
    str     wzr, [x1]

    cmp     w19, #STATE_1
    b.eq    ecu_state1
    cmp     w19, #STATE_2
    b.eq    ecu_state2
    cmp     w19, #STATE_3
    b.eq    ecu_state3
    cmp     w19, #STATE_4
    b.eq    ecu_state4
    b       ecu_unsafe

ecu_state1:
    mov     w1, #800
    mov     w2, #1
    mov     w3, #120
    b       ecu_store_sim

ecu_state2:
    mov     w1, #0
    mov     w2, #0
    mov     w3, #120
    b       ecu_store_sim

ecu_state3:
    mov     w1, #1500
    mov     w2, #1
    mov     w3, #180
    b       ecu_store_sim

ecu_state4:
    mov     w1, #1500
    mov     w2, #1
    mov     w3, #5

ecu_store_sim:
    adrp    x11, simulated_ckp_rpm
    add     x11, x11, :lo12:simulated_ckp_rpm
    str     w1, [x11]
    adrp    x11, simulated_cmp_ok
    add     x11, x11, :lo12:simulated_cmp_ok
    str     w2, [x11]
    adrp    x11, simulated_maf_gps
    add     x11, x11, :lo12:simulated_maf_gps
    str     w3, [x11]

    // --------------------------------------------------------
    // REAL Tang Nano values: BMP180 temperature, LM35,
    // BMP180 pressure and potentiometer percent.
    // --------------------------------------------------------
    adrp    x1, bmp180_value
    add     x1, x1, :lo12:bmp180_value
    ldrsh   w2, [x1]
    ldr     w3, =SAFE_TEMP_MIN_X10
    cmp     w2, w3
    b.lt    ecu_unsafe
    ldr     w3, =SAFE_TEMP_MAX_X10
    cmp     w2, w3
    b.gt    ecu_unsafe

    adrp    x1, temperature_x10_value
    add     x1, x1, :lo12:temperature_x10_value
    ldrsh   w2, [x1]
    ldr     w3, =SAFE_TEMP_MIN_X10
    cmp     w2, w3
    b.lt    ecu_unsafe
    ldr     w3, =SAFE_TEMP_MAX_X10
    cmp     w2, w3
    b.gt    ecu_unsafe

    adrp    x1, pressure_pa_value
    add     x1, x1, :lo12:pressure_pa_value
    ldr     w2, [x1]
    ldr     w3, =SAFE_PRESSURE_MIN_PA
    cmp     w2, w3
    b.lt    ecu_unsafe
    ldr     w3, =SAFE_PRESSURE_MAX_PA
    cmp     w2, w3
    b.gt    ecu_unsafe

    adrp    x1, lm35_value
    add     x1, x1, :lo12:lm35_value
    ldrh    w2, [x1]
    ldr     w3, =1023
    cmp     w2, w3
    b.hi    ecu_unsafe

    adrp    x1, pot_percent_value
    add     x1, x1, :lo12:pot_percent_value
    ldrb    w2, [x1]
    ldr     w3, =SAFE_POT_MAX_PERCENT
    cmp     w2, w3
    b.hi    ecu_unsafe

    // --------------------------------------------------------
    // SIMULATED CKP
    // --------------------------------------------------------
    adrp    x1, simulated_ckp_rpm
    add     x1, x1, :lo12:simulated_ckp_rpm
    ldr     w2, [x1]
    ldr     w3, =CKP_MIN_RPM
    cmp     w2, w3
    b.lt    ecu_unsafe
    ldr     w3, =CKP_MAX_RPM
    cmp     w2, w3
    b.gt    ecu_unsafe

    // --------------------------------------------------------
    // SIMULATED CMP
    // --------------------------------------------------------
    adrp    x1, simulated_cmp_ok
    add     x1, x1, :lo12:simulated_cmp_ok
    ldr     w2, [x1]
    cmp     w2, #1
    b.ne    ecu_unsafe

    // --------------------------------------------------------
    // SIMULATED MAF
    // --------------------------------------------------------
    adrp    x1, simulated_maf_gps
    add     x1, x1, :lo12:simulated_maf_gps
    ldr     w2, [x1]
    ldr     w3, =MAF_MIN_GPS
    cmp     w2, w3
    b.lt    ecu_unsafe
    ldr     w3, =MAF_MAX_GPS
    cmp     w2, w3
    b.gt    ecu_unsafe

    mov     w20, #1
    b       ecu_store_safety

ecu_unsafe:
    mov     w20, #0

ecu_store_safety:
    adrp    x1, motor_safety_ok
    add     x1, x1, :lo12:motor_safety_ok
    str     w20, [x1]
    mov     w0, w20
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

// -----------------------------------------------------------------------------
// Interruptor digital de seguranca e comando do motor.
// A seguranca tem prioridade sobre o potenciometro.
// Em estado seguro, o motor so e marcado como habilitado depois que os
// comandos reais de direcao e PWM retornam sucesso.
// -----------------------------------------------------------------------------
motor_force_disable:
    // Desligamento solicitado pela ECU. Este caminho nao e uma falha do
    // atuador se motor_stop executar as operacoes fisicas com sucesso.
    stp     x29, x30, [sp, #-32]!
    stp     x19, x20, [sp, #16]
    mov     x29, sp

    bl      motor_stop
    mov     w19, w0

    adrp    x1, motor_enable
    add     x1, x1, :lo12:motor_enable
    str     wzr, [x1]
    adrp    x1, motor_pwm_percent
    add     x1, x1, :lo12:motor_pwm_percent
    str     wzr, [x1]
    adrp    x1, motor_direction_code
    add     x1, x1, :lo12:motor_direction_code
    str     wzr, [x1]

    adrp    x1, motor_actuator_ok
    add     x1, x1, :lo12:motor_actuator_ok
    cmp     w19, #0
    b.lt    motor_force_disable_fault
    mov     w0, #1
    str     w0, [x1]
    b       motor_force_disable_done

motor_force_disable_fault:
    str     wzr, [x1]

motor_force_disable_done:
    // O resultado da parada e o retorno da funcao. Ele deve ser colocado em
    // W0 antes de restaurar X19, pois X19 pertence ao chamador e sera
    // sobrescrito pelo epilogo da funcao.
    mov     w0, w19
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #32
    ret

motor_control_update:
    // Input: w0 = STATE 1..4, w1 = REAL potentiometer percent.
    stp     x29, x30, [sp, #-48]!
    stp     x19, x20, [sp, #16]
    stp     x21, x22, [sp, #32]
    mov     x29, sp
    mov     w19, w0
    mov     w20, w1

    adrp    x1, motor_selected_state
    add     x1, x1, :lo12:motor_selected_state
    str     w19, [x1]

    cmp     w20, #100
    b.hi    motor_control_unsafe

    mov     w0, w19
    bl      motor_evaluate_state
    mov     w21, w0
    cbz     w21, motor_control_unsafe

    // SAFE state: POT is the accelerator command.
    mov     w0, w20
    bl      pot_percent_to_pwm
    mov     w22, w0

    mov     w0, #1
    bl      motor_set_direction
    cmp     w0, #0
    b.lt    motor_control_fail

    mov     w0, w22
    bl      motor_set_pwm
    cmp     w0, #0
    b.lt    motor_control_fail

    adrp    x1, motor_enable
    add     x1, x1, :lo12:motor_enable
    mov     w0, #1
    str     w0, [x1]

    adrp    x1, motor_pwm_percent
    add     x1, x1, :lo12:motor_pwm_percent
    str     w22, [x1]

    adrp    x1, motor_direction_code
    add     x1, x1, :lo12:motor_direction_code
    mov     w0, #1
    str     w0, [x1]

    adrp    x1, motor_actuator_ok
    add     x1, x1, :lo12:motor_actuator_ok
    mov     w0, #1
    str     w0, [x1]

    mov     w0, #1
    b       motor_control_done

motor_control_unsafe:
    bl      motor_force_disable
    mov     w0, #0
    b       motor_control_done

motor_control_fail:
    // O erro de acionamento foi detectado. Primeiro pare o motor; em seguida
    // preserve o codigo da falha que causou a entrada neste caminho.
    adrp    x1, motor_actuator_error
    add     x1, x1, :lo12:motor_actuator_error
    ldr     w19, [x1]
    bl      motor_force_disable
    adrp    x1, motor_actuator_ok
    add     x1, x1, :lo12:motor_actuator_ok
    str     wzr, [x1]
    adrp    x1, motor_actuator_error
    add     x1, x1, :lo12:motor_actuator_error
    str     w19, [x1]
    mov     w0, #-1

motor_control_done:
    ldp     x21, x22, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #48
    ret

// -----------------------------------------------------------------------------
// Shutdown global. Idempotente: pode ser chamado por Ctrl+C, por erro ou por
// uma saida normal. Nunca deixa o PWM ou os pinos de direcao ativos.
// -----------------------------------------------------------------------------
motor_shutdown_all:
    stp     x29, x30, [sp, #-16]!
    mov     x29, sp

    adrp    x1, motor_initialized
    add     x1, x1, :lo12:motor_initialized
    ldr     w2, [x1]
    cbz     w2, motor_shutdown_close_resources

    // Parada fisica e prioridade absoluta.
    bl      motor_stop

    adrp    x1, motor_enable
    add     x1, x1, :lo12:motor_enable
    str     wzr, [x1]
    adrp    x1, motor_pwm_percent
    add     x1, x1, :lo12:motor_pwm_percent
    str     wzr, [x1]

motor_shutdown_close_resources:
    bl      encoder_close
    bl      motor_gpio_close
    bl      pwm_disable

    adrp    x1, motor_initialized
    add     x1, x1, :lo12:motor_initialized
    str     wzr, [x1]

    // Fecha o SPI somente se o main tiver registrado um descritor ativo.
    adrp    x1, active_spi_fd
    add     x1, x1, :lo12:active_spi_fd
    ldr     x0, [x1]
    cmp     x0, #0
    b.lt    motor_shutdown_done
    mov     x8, #SYS_close
    svc     #0
    mov     x0, #-1
    str     x0, [x1]

motor_shutdown_done:
    ldp     x29, x30, [sp], #16
    ret

// -----------------------------------------------------------------------------
// Feedback: encoder count, PPS, RPM and RPM percentage.
// -----------------------------------------------------------------------------
motor_feedback_update:
    stp     x29, x30, [sp, #-64]!
    stp     x19, x20, [sp, #16]
    stp     x21, x22, [sp, #32]
    stp     x23, x24, [sp, #48]
    mov     x29, sp

    // A leitura do encoder nao pode ser tratada como bem-sucedida sem
    // verificar seu retorno imediatamente; uma falha de descritor invalida
    // o calculo de PPS/RPM, mas nao altera o estado de seguranca do motor.
    bl      encoder_update
    cmp     w0, #0
    b.lt    motor_feedback_done
    bl      clock_monotonic_ns
    cmp     x0, #0
    b.lt    motor_feedback_done
    mov     x19, x0

    adrp    x1, motor_measure_valid
    add     x1, x1, :lo12:motor_measure_valid
    ldr     w2, [x1]
    cbnz    w2, motor_feedback_have_baseline

    adrp    x1, motor_last_measure_ns
    add     x1, x1, :lo12:motor_last_measure_ns
    str     x19, [x1]
    adrp    x1, previous_count
    add     x1, x1, :lo12:previous_count
    adrp    x2, encoder_count
    add     x2, x2, :lo12:encoder_count
    ldr     x3, [x2]
    str     x3, [x1]
    adrp    x1, motor_measure_valid
    add     x1, x1, :lo12:motor_measure_valid
    mov     w2, #1
    str     w2, [x1]
    adrp    x1, motor_rpm_x100
    add     x1, x1, :lo12:motor_rpm_x100
    str     xzr, [x1]
    adrp    x1, motor_rpm_percent_x100
    add     x1, x1, :lo12:motor_rpm_percent_x100
    str     xzr, [x1]
    adrp    x1, pps_value
    add     x1, x1, :lo12:pps_value
    str     xzr, [x1]
    adrp    x1, motor_direction_code
    add     x1, x1, :lo12:motor_direction_code
    str     wzr, [x1]
    b       motor_feedback_done

motor_feedback_have_baseline:
    adrp    x1, motor_last_measure_ns
    add     x1, x1, :lo12:motor_last_measure_ns
    ldr     x20, [x1]
    sub     x21, x19, x20
    cmp     x21, #0
    b.eq    motor_feedback_done
    str     x19, [x1]

    adrp    x1, encoder_count
    add     x1, x1, :lo12:encoder_count
    ldr     x22, [x1]
    adrp    x1, previous_count
    add     x1, x1, :lo12:previous_count
    ldr     x23, [x1]
    sub     x24, x22, x23
    str     x22, [x1]

    mov     x0, x24
    cmp     x0, #0
    b.ge    motor_feedback_abs_ready
    neg     x0, x0
motor_feedback_abs_ready:
    ldr     x1, =1000000000
    mul     x0, x0, x1
    udiv    x0, x0, x21
    adrp    x1, pps_value
    add     x1, x1, :lo12:pps_value
    str     x0, [x1]

    mov     x0, x24
    mov     x1, x21
    bl      encoder_calculate_rpm
    adrp    x1, motor_rpm_x100
    add     x1, x1, :lo12:motor_rpm_x100
    str     x0, [x1]
    mov     x20, x0

    ldr     x1, =MOTOR_NOMINAL_RPM_X100
    cmp     x20, x1
    csel    x0, x20, x1, ls
    adrp    x1, motor_rpm_percent_x100
    add     x1, x1, :lo12:motor_rpm_percent_x100
    str     x0, [x1]

    adrp    x1, motor_direction_code
    add     x1, x1, :lo12:motor_direction_code
    cmp     x24, #0
    b.gt    motor_feedback_cw
    b.lt    motor_feedback_ccw
    str     wzr, [x1]
    b       motor_feedback_done
motor_feedback_cw:
    mov     w0, #1
    str     w0, [x1]
    b       motor_feedback_done
motor_feedback_ccw:
    mov     w0, #2
    str     w0, [x1]

motor_feedback_done:
    ldp     x23, x24, [sp, #48]
    ldp     x21, x22, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #64
    ret

// -----------------------------------------------------------------------------
// Motor/ECU panel. Real sensors are explicitly marked as REAL/TANG NANO 4K.
// CMP and MAF are shown as simulated in this panel. CKP simulation is retained internally for ECU safety.
// -----------------------------------------------------------------------------
print_motor_panel:
    // Painel da ECU: mostra dados reais, sensores simulados, seguranca e atuador.
    stp     x29, x30, [sp, #-16]!
    mov     x29, sp

    // Estado selecionado.
    adrp    x0, motor_state_label
    add     x0, x0, :lo12:motor_state_label
    mov     x1, #motor_state_label_end-motor_state_label
    bl      write_str
    adrp    x1, motor_selected_state
    add     x1, x1, :lo12:motor_selected_state
    ldr     w0, [x1]
    bl      print_u32
    adrp    x0, newline
    add     x0, x0, :lo12:newline
    mov     x1, #1
    bl      write_str

    // Sensores reais recebidos da Tang Nano 4K.
    adrp    x0, motor_real_header
    add     x0, x0, :lo12:motor_real_header
    mov     x1, #motor_real_header_end-motor_real_header
    bl      write_str

    adrp    x0, motor_pot_real_label
    add     x0, x0, :lo12:motor_pot_real_label
    mov     x1, #motor_pot_real_label_end-motor_pot_real_label
    bl      write_str
    adrp    x1, pot_percent_value
    add     x1, x1, :lo12:pot_percent_value
    ldrb    w0, [x1]
    bl      print_u32
    adrp    x0, percent_line
    add     x0, x0, :lo12:percent_line
    mov     x1, #percent_line_end-percent_line
    bl      write_str

    adrp    x0, motor_lm35_real_label
    add     x0, x0, :lo12:motor_lm35_real_label
    mov     x1, #motor_lm35_real_label_end-motor_lm35_real_label
    bl      write_str
    adrp    x1, temperature_x10_value
    add     x1, x1, :lo12:temperature_x10_value
    ldrh    w0, [x1]
    bl      print_temperature_x10

    adrp    x0, motor_bmp_real_label
    add     x0, x0, :lo12:motor_bmp_real_label
    mov     x1, #motor_bmp_real_label_end-motor_bmp_real_label
    bl      write_str
    adrp    x1, bmp180_value
    add     x1, x1, :lo12:bmp180_value
    ldrsh   w0, [x1]
    bl      print_temperature_x10

    adrp    x0, motor_pressure_real_label
    add     x0, x0, :lo12:motor_pressure_real_label
    mov     x1, #motor_pressure_real_label_end-motor_pressure_real_label
    bl      write_str
    adrp    x1, pressure_pa_value
    add     x1, x1, :lo12:pressure_pa_value
    ldr     w0, [x1]
    bl      print_u32
    adrp    x0, pressure_unit_label
    add     x0, x0, :lo12:pressure_unit_label
    mov     x1, #pressure_unit_label_end-pressure_unit_label
    bl      write_str

    // Apenas CMP e MAF sao exibidos como simulados neste painel.
    adrp    x0, motor_sim_header
    add     x0, x0, :lo12:motor_sim_header
    mov     x1, #motor_sim_header_end-motor_sim_header
    bl      write_str

    adrp    x0, sim_cmp_label
    add     x0, x0, :lo12:sim_cmp_label
    mov     x1, #sim_cmp_label_end-sim_cmp_label
    bl      write_str
    adrp    x1, simulated_cmp_ok
    add     x1, x1, :lo12:simulated_cmp_ok
    ldr     w0, [x1]
    bl      print_u32
    adrp    x0, newline
    add     x0, x0, :lo12:newline
    mov     x1, #1
    bl      write_str

    adrp    x0, sim_maf_label
    add     x0, x0, :lo12:sim_maf_label
    mov     x1, #sim_maf_label_end-sim_maf_label
    bl      write_str
    adrp    x1, simulated_maf_gps
    add     x1, x1, :lo12:simulated_maf_gps
    ldr     w0, [x1]
    bl      print_u32
    adrp    x0, maf_unit_label
    add     x0, x0, :lo12:maf_unit_label
    mov     x1, #maf_unit_label_end-maf_unit_label
    bl      write_str

    // Seguranca ECU.
    adrp    x0, motor_safety_label
    add     x0, x0, :lo12:motor_safety_label
    mov     x1, #motor_safety_label_end-motor_safety_label
    bl      write_str
    adrp    x1, motor_safety_ok
    add     x1, x1, :lo12:motor_safety_ok
    ldr     w0, [x1]
    cbz     w0, panel_unsafe
    adrp    x0, state_safe
    add     x0, x0, :lo12:state_safe
    mov     x1, #state_safe_end-state_safe
    bl      write_str
    b       panel_safety_done
panel_unsafe:
    adrp    x0, state_unsafe
    add     x0, x0, :lo12:state_unsafe
    mov     x1, #state_unsafe_end-state_unsafe
    bl      write_str
panel_safety_done:
    adrp    x0, newline
    add     x0, x0, :lo12:newline
    mov     x1, #1
    bl      write_str

    // Estado logico do motor. SAFE nao implica fault do atuador.
    adrp    x0, motor_enable_label
    add     x0, x0, :lo12:motor_enable_label
    mov     x1, #motor_enable_label_end-motor_enable_label
    bl      write_str
    adrp    x1, motor_enable
    add     x1, x1, :lo12:motor_enable
    ldr     w0, [x1]
    cbz     w0, panel_disabled
    adrp    x0, motor_enabled_text
    add     x0, x0, :lo12:motor_enabled_text
    mov     x1, #motor_enabled_text_end-motor_enabled_text
    bl      write_str
    b       panel_motor_done
panel_disabled:
    adrp    x0, motor_disabled_text
    add     x0, x0, :lo12:motor_disabled_text
    mov     x1, #motor_disabled_text_end-motor_disabled_text
    bl      write_str
panel_motor_done:
    adrp    x0, newline
    add     x0, x0, :lo12:newline
    mov     x1, #1
    bl      write_str

    // Estado do atuador.
    adrp    x0, motor_actuator_label
    add     x0, x0, :lo12:motor_actuator_label
    mov     x1, #motor_actuator_label_end-motor_actuator_label
    bl      write_str
    adrp    x1, motor_actuator_ok
    add     x1, x1, :lo12:motor_actuator_ok
    ldr     w0, [x1]
    cbz     w0, panel_actuator_fault
    adrp    x0, actuator_ok_text
    add     x0, x0, :lo12:actuator_ok_text
    mov     x1, #actuator_ok_text_end-actuator_ok_text
    bl      write_str
    b       panel_actuator_done
panel_actuator_fault:
    adrp    x0, actuator_fault_text
    add     x0, x0, :lo12:actuator_fault_text
    mov     x1, #actuator_fault_text_end-actuator_fault_text
    bl      write_str
panel_actuator_done:
    adrp    x0, newline
    add     x0, x0, :lo12:newline
    mov     x1, #1
    bl      write_str

    // PWM comandado.
    adrp    x0, motor_pwm_label
    add     x0, x0, :lo12:motor_pwm_label
    mov     x1, #motor_pwm_label_end-motor_pwm_label
    bl      write_str
    adrp    x1, motor_pwm_percent
    add     x1, x1, :lo12:motor_pwm_percent
    ldr     w0, [x1]
    bl      print_u32
    adrp    x0, percent_line
    add     x0, x0, :lo12:percent_line
    mov     x1, #percent_line_end-percent_line
    bl      write_str

    // Feedback do encoder.
    adrp    x0, motor_count_label
    add     x0, x0, :lo12:motor_count_label
    mov     x1, #motor_count_label_end-motor_count_label
    bl      write_str
    adrp    x1, encoder_count
    add     x1, x1, :lo12:encoder_count
    ldr     x0, [x1]
    bl      print_s64
    adrp    x0, newline
    add     x0, x0, :lo12:newline
    mov     x1, #1
    bl      write_str

    adrp    x0, motor_pps_label
    add     x0, x0, :lo12:motor_pps_label
    mov     x1, #motor_pps_label_end-motor_pps_label
    bl      write_str
    adrp    x1, pps_value
    add     x1, x1, :lo12:pps_value
    ldr     x0, [x1]
    bl      print_u32
    adrp    x0, newline
    add     x0, x0, :lo12:newline
    mov     x1, #1
    bl      write_str

    adrp    x0, motor_rpm_label
    add     x0, x0, :lo12:motor_rpm_label
    mov     x1, #motor_rpm_label_end-motor_rpm_label
    bl      write_str
    adrp    x1, motor_rpm_x100
    add     x1, x1, :lo12:motor_rpm_x100
    ldr     x0, [x1]
    bl      print_fixed100
    adrp    x0, newline
    add     x0, x0, :lo12:newline
    mov     x1, #1
    bl      write_str

    adrp    x0, motor_rpm_percent_label
    add     x0, x0, :lo12:motor_rpm_percent_label
    mov     x1, #motor_rpm_percent_label_end-motor_rpm_percent_label
    bl      write_str
    adrp    x1, motor_rpm_percent_x100
    add     x1, x1, :lo12:motor_rpm_percent_x100
    ldr     x0, [x1]
    bl      print_fixed100
    adrp    x0, percent_line
    add     x0, x0, :lo12:percent_line
    mov     x1, #percent_line_end-percent_line
    bl      write_str

    adrp    x0, motor_dir_label
    add     x0, x0, :lo12:motor_dir_label
    mov     x1, #motor_dir_label_end-motor_dir_label
    bl      write_str
    adrp    x1, motor_direction_code
    add     x1, x1, :lo12:motor_direction_code
    ldr     w0, [x1]
    cmp     w0, #1
    b.eq    panel_dir_cw
    cmp     w0, #2
    b.eq    panel_dir_ccw
    adrp    x0, dir_stopped
    add     x0, x0, :lo12:dir_stopped
    mov     x1, #dir_stopped_end-dir_stopped
    bl      write_str
    b       panel_dir_done
panel_dir_cw:
    adrp    x0, dir_clockwise
    add     x0, x0, :lo12:dir_clockwise
    mov     x1, #dir_clockwise_end-dir_clockwise
    bl      write_str
    b       panel_dir_done
panel_dir_ccw:
    adrp    x0, dir_counterclockwise
    add     x0, x0, :lo12:dir_counterclockwise
    mov     x1, #dir_counterclockwise_end-dir_counterclockwise
    bl      write_str
panel_dir_done:
    adrp    x0, newline
    add     x0, x0, :lo12:newline
    mov     x1, #1
    bl      write_str

    // Detalhe do erro somente quando o atuador esta em fault.
    adrp    x1, motor_actuator_ok
    add     x1, x1, :lo12:motor_actuator_ok
    ldr     w0, [x1]
    cbnz    w0, panel_error_done
    adrp    x0, actuator_error_label
    add     x0, x0, :lo12:actuator_error_label
    mov     x1, #actuator_error_label_end-actuator_error_label
    bl      write_str
    adrp    x1, motor_actuator_error
    add     x1, x1, :lo12:motor_actuator_error
    ldr     w0, [x1]
    cmp     w0, #1
    b.eq    panel_error_dir
    cmp     w0, #2
    b.eq    panel_error_pwm
    adrp    x0, actuator_error_none
    add     x0, x0, :lo12:actuator_error_none
    mov     x1, #actuator_error_none_end-actuator_error_none
    bl      write_str
    b       panel_error_done
panel_error_dir:
    adrp    x0, actuator_error_direction
    add     x0, x0, :lo12:actuator_error_direction
    mov     x1, #actuator_error_direction_end-actuator_error_direction
    bl      write_str
    b       panel_error_done
panel_error_pwm:
    adrp    x0, actuator_error_pwm
    add     x0, x0, :lo12:actuator_error_pwm
    mov     x1, #actuator_error_pwm_end-actuator_error_pwm
    bl      write_str
panel_error_done:
    adrp    x0, newline
    add     x0, x0, :lo12:newline
    mov     x1, #1
    bl      write_str

    ldp     x29, x30, [sp], #16
    ret

// -----------------------------------------------------------------------------
// Legacy motor test: keep the validated 20/30/50/98 stages.
// -----------------------------------------------------------------------------
motor_test_mode:
    stp     x29, x30, [sp, #-64]!
    stp     x19, x20, [sp, #16]
    stp     x21, x22, [sp, #32]
    stp     x23, x24, [sp, #48]
    mov     x29, sp

    bl      motor_init
    cmp     x0, #0
    b.lt    motor_test_init_fail

    adrp    x19, motor_stage_values
    add     x19, x19, :lo12:motor_stage_values
    mov     w20, #0

motor_stage_loop:
    cmp     w20, #MOTOR_STAGE_COUNT
    b.ge    motor_test_success
    ldrb    w21, [x19, w20, uxtw]

    mov     w0, #1
    bl      motor_set_direction
    cmp     w0, #0
    b.lt    motor_test_fail

    mov     w0, w21
    bl      motor_set_pwm
    cmp     w0, #0
    b.lt    motor_test_fail

    adrp    x0, motor_stage_header
    add     x0, x0, :lo12:motor_stage_header
    mov     x1, #motor_stage_header_end-motor_stage_header
    bl      write_str
    mov     w0, w21
    bl      print_u32
    adrp    x0, percent_line
    add     x0, x0, :lo12:percent_line
    mov     x1, #1
    bl      write_str

    adrp    x0, encoder_count
    add     x0, x0, :lo12:encoder_count
    str     xzr, [x0]
    adrp    x0, last_encoder_state
    add     x0, x0, :lo12:last_encoder_state
    adrp    x1, encoder_state
    add     x1, x1, :lo12:encoder_state
    ldr     w2, [x1]
    str     w2, [x0]
    adrp    x22, stage_start_ns
    add     x22, x22, :lo12:stage_start_ns
    bl      clock_monotonic_ns
    str     x0, [x22]
    adrp    x23, last_print_ns
    add     x23, x23, :lo12:last_print_ns
    str     x0, [x23]
    adrp    x23, stage_last_measure_ns
    add     x23, x23, :lo12:stage_last_measure_ns
    str     x0, [x23]
    adrp    x23, previous_count
    add     x23, x23, :lo12:previous_count
    str     xzr, [x23]

    mov     w0, #1
    bl      sleep_1ms

motor_stage_run:
    bl      encoder_update
    adrp    x0, stage_start_ns
    add     x0, x0, :lo12:stage_start_ns
    ldr     x0, [x0]
    bl      clock_monotonic_ns
    adrp    x1, stage_elapsed_ns
    add     x1, x1, :lo12:stage_elapsed_ns
    adrp    x2, stage_start_ns
    add     x2, x2, :lo12:stage_start_ns
    ldr     x3, [x2]
    sub     x2, x0, x3
    str     x2, [x1]
    ldr     x14, =10000000000
    cmp     x2, x14
    b.ge    motor_stage_stop

    adrp    x2, last_print_ns
    add     x2, x2, :lo12:last_print_ns
    ldr     x3, [x2]
    sub     x4, x0, x3
    ldr     x14, =500000000
    cmp     x4, x14
    b.lt    motor_stage_sleep

    str     x0, [x2]
    adrp    x5, previous_count
    add     x5, x5, :lo12:previous_count
    ldr     x6, [x5]
    adrp    x7, encoder_count
    add     x7, x7, :lo12:encoder_count
    ldr     x8, [x7]
    sub     x9, x8, x6
    str     x8, [x5]

    adrp    x5, stage_last_measure_ns
    add     x5, x5, :lo12:stage_last_measure_ns
    ldr     x10, [x5]
    sub     x11, x0, x10
    str     x0, [x5]

    mov     x12, x9
    cmp     x12, #0
    b.ge    pps_abs_ready
    neg     x12, x12
pps_abs_ready:
    ldr     x13, =1000000000
    mul     x12, x12, x13
    udiv    x12, x12, x11
    adrp    x5, pps_value
    add     x5, x5, :lo12:pps_value
    str     x12, [x5]

    mov     x0, x9
    mov     x1, x11
    bl      encoder_calculate_rpm
    mov     x24, x0
    adrp    x1, motor_rpm_x100
    add     x1, x1, :lo12:motor_rpm_x100
    str     x24, [x1]
    adrp    x1, motor_rpm_percent_x100
    add     x1, x1, :lo12:motor_rpm_percent_x100
    ldr     x0, [x1]
    ldr     x2, =MOTOR_NOMINAL_RPM_X100
    cmp     x24, x2
    csel    x0, x24, x2, ls
    str     x0, [x1]

    mov     x0, x21
    mov     x1, x9
    mov     x2, x12
    mov     x3, x24
    bl      print_motor_status_legacy

motor_stage_sleep:
    bl      sleep_1ms
    b       motor_stage_run

motor_stage_stop:
    bl      motor_stop
    adrp    x0, newline
    add     x0, x0, :lo12:newline
    mov     x1, #1
    bl      write_str
    add     w20, w20, #1
    b       motor_stage_loop

motor_test_success:
    bl      encoder_close
    bl      motor_gpio_close
    adrp    x1, motor_initialized
    add     x1, x1, :lo12:motor_initialized
    str     wzr, [x1]
    mov     w0, #0
    b       motor_test_done
motor_test_fail:
    bl      motor_stop
    bl      encoder_close
    bl      motor_gpio_close
    adrp    x1, motor_initialized
    add     x1, x1, :lo12:motor_initialized
    str     wzr, [x1]
    mov     w0, #-1
    b       motor_test_done
motor_test_init_fail:
    adrp    x0, motor_init_error_msg
    add     x0, x0, :lo12:motor_init_error_msg
    mov     x1, #motor_init_error_msg_end-motor_init_error_msg
    bl      write_str
    mov     w0, #-1
motor_test_done:
    ldp     x23, x24, [sp, #48]
    ldp     x21, x22, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #64
    ret

// Legacy status formatter for the m command.
print_motor_status_legacy:
    stp     x29, x30, [sp, #-48]!
    stp     x19, x20, [sp, #16]
    str     x21, [sp, #32]
    mov     x29, sp
    mov     x19, x0
    mov     x20, x1
    mov     x21, x3

    adrp    x0, motor_pwm_label
    add     x0, x0, :lo12:motor_pwm_label
        mov     x1, #motor_pwm_label_end-motor_pwm_label
    bl      write_str
    mov     x0, x19
    bl      print_u32
    adrp    x0, percent_line
    add     x0, x0, :lo12:percent_line
    mov     x1, #1
    bl      write_str

    adrp    x0, motor_count_label
    add     x0, x0, :lo12:motor_count_label
        mov     x1, #motor_count_label_end-motor_count_label
    bl      write_str
    adrp    x1, encoder_count
    add     x1, x1, :lo12:encoder_count
    ldr     x0, [x1]
    bl      print_s64
    adrp    x0, motor_delta_label
    add     x0, x0, :lo12:motor_delta_label
        mov     x1, #motor_delta_label_end-motor_delta_label
    bl      write_str
    mov     x0, x20
    bl      print_s64

    adrp    x0, motor_pps_label
    add     x0, x0, :lo12:motor_pps_label
        mov     x1, #motor_pps_label_end-motor_pps_label
    bl      write_str
    adrp    x1, pps_value
    add     x1, x1, :lo12:pps_value
    ldr     x0, [x1]
    bl      print_u32

    adrp    x0, motor_rpm_label
    add     x0, x0, :lo12:motor_rpm_label
        mov     x1, #motor_rpm_label_end-motor_rpm_label
    bl      write_str
    mov     x0, x21
    bl      print_fixed100
    adrp    x0, newline
    add     x0, x0, :lo12:newline
    mov     x1, #1
    bl      write_str

    adrp    x0, motor_dir_label
    add     x0, x0, :lo12:motor_dir_label
        mov     x1, #motor_dir_label_end-motor_dir_label
    bl      write_str
    cmp     x20, #0
    b.gt    legacy_dir_cw
    b.lt    legacy_dir_ccw
    adrp    x0, dir_stopped
    add     x0, x0, :lo12:dir_stopped
    mov     x1, #dir_stopped_end-dir_stopped
    b       legacy_dir_write
legacy_dir_cw:
    adrp    x0, dir_clockwise
    add     x0, x0, :lo12:dir_clockwise
    mov     x1, #dir_clockwise_end-dir_clockwise
    b       legacy_dir_write
legacy_dir_ccw:
    adrp    x0, dir_counterclockwise
    add     x0, x0, :lo12:dir_counterclockwise
    mov     x1, #dir_counterclockwise_end-dir_counterclockwise
legacy_dir_write:
    bl      write_str
    adrp    x0, newline
    add     x0, x0, :lo12:newline
    mov     x1, #1
    bl      write_str

    ldr     x21, [sp, #32]
    ldp     x19, x20, [sp, #16]
    ldp     x29, x30, [sp], #48
    ret

.section .rodata
.align 3
gpio_chip_path:
    .asciz "/dev/gpiochip0"
pwm_export_path:
    .asciz "/sys/class/pwm/pwmchip0/export"
pwm_period_path:
    .asciz "/sys/class/pwm/pwmchip0/pwm0/period"
pwm_duty_path:
    .asciz "/sys/class/pwm/pwmchip0/pwm0/duty_cycle"
pwm_enable_path:
    .asciz "/sys/class/pwm/pwmchip0/pwm0/enable"
pwm_period_str:
    .asciz "1000000"
pwm_zero_str:
    .asciz "0"
pwm_one_str:
    .asciz "1"
minus_sign:
    .ascii "-"
zero_digit:
    .ascii "0"
motor_decimal_point:
    .ascii "."
percent_line:
    .ascii "%\n"
percent_line_end:
motor_state_label:
    .ascii "ESTADO ECU: "
motor_state_label_end:
motor_real_header:
    .ascii "DADOS REAIS - TANG NANO 4K\n"
motor_real_header_end:
motor_pot_real_label:
    .ascii "POT REAL: "
motor_pot_real_label_end:
motor_lm35_real_label:
    .ascii "LM35 REAL: "
motor_lm35_real_label_end:
motor_bmp_real_label:
    .ascii "BMP180 REAL: "
motor_bmp_real_label_end:
motor_pressure_real_label:
    .ascii "PRESSAO REAL: "
motor_pressure_real_label_end:
pressure_unit_label:
    .ascii " Pa\n"
pressure_unit_label_end:
motor_sim_header:
    .ascii "SENSORES ECU SIMULADOS\n"
motor_sim_header_end:
sim_cmp_label:
    .ascii "Sensor de Posicao do Comando de Valvulas (CMP): "
sim_cmp_label_end:
sim_maf_label:
    .ascii "MAF: "
sim_maf_label_end:
maf_unit_label:
    .ascii " g/s\n"
maf_unit_label_end:
motor_safety_label:
    .ascii "SEGURANCA: "
motor_safety_label_end:
state_safe:
    .ascii "SAFE"
state_safe_end:
state_unsafe:
    .ascii "UNSAFE"
state_unsafe_end:
motor_enable_label:
    .ascii "MOTOR: "
motor_enable_label_end:
motor_enabled_text:
    .ascii "HABILITADO"
motor_enabled_text_end:
motor_disabled_text:
    .ascii "DESABILITADO"
motor_disabled_text_end:
motor_actuator_label:
    .ascii "ATUADOR: "
motor_actuator_label_end:
actuator_ok_text:
    .ascii "OK"
actuator_ok_text_end:
actuator_fault_text:
    .ascii "FALHA"
actuator_fault_text_end:
motor_pwm_label:
    .ascii "PWM: "
motor_pwm_label_end:
motor_count_label:
    .ascii "CONTAGEM: "
motor_count_label_end:
motor_delta_label:
    .ascii "DELTA: "
motor_delta_label_end:
motor_pps_label:
    .ascii "Pulsos por Segundo (PPS): "
motor_pps_label_end:
motor_rpm_label:
    .ascii "RPM - Posicao Virabrequim (CKP): "
motor_rpm_label_end:
motor_rpm_percent_label:
    .ascii "RPM PERCENTUAL: "
motor_rpm_percent_label_end:
motor_dir_label:
    .ascii "DIRECAO: "
motor_dir_label_end:
dir_clockwise:
    .ascii "HORARIO"
dir_clockwise_end:
dir_counterclockwise:
    .ascii "ANTI-HORARIO"
dir_counterclockwise_end:
dir_stopped:
    .ascii "PARADO"
dir_stopped_end:
actuator_error_label:
    .ascii "ERRO ATUADOR: "
actuator_error_label_end:
actuator_error_none:
    .ascii "NENHUM"
actuator_error_none_end:
actuator_error_direction:
    .ascii "DIRECAO"
actuator_error_direction_end:
actuator_error_pwm:
    .ascii "PWM"
actuator_error_pwm_end:
motor_stage_header:
    .ascii "\n--- TESTE MOTOR PWM: "
motor_stage_header_end:
motor_init_error_msg:
    .ascii "Motor init failed. Check /dev/gpiochip0 and PWM overlay/path.\n"
motor_init_error_msg_end:
motor_stage_values:
    .byte 20,30,50,98
.section .data
.align 3

.section .bss
.align 8
motor_enable:
    .word 0
motor_pwm_percent:
    .word 0
motor_rpm_x100:
    .quad 0
motor_rpm_percent_x100:
    .quad 0
motor_direction_code:
    .word 0
motor_safety_ok:
    .word 0
motor_actuator_ok:
    .word 0
motor_actuator_error:
    .word 0
motor_selected_state:
    .word 0
simulated_ckp_rpm:
    .word 0
simulated_cmp_ok:
    .word 0
simulated_maf_gps:
    .word 0
motor_measure_valid:
    .word 0
motor_initialized:
    .word 0
.align 8
motor_last_measure_ns:
    .quad 0

