// Testes numericos deterministas do TP4 implementados inteiramente em assembly AArch64.
// Os casos reproduzem tests/test_tp4_numeric.py sem depender de uma referencia Python.
.text
.align 2
.global _start
.type _start, %function
.extern uint128_add
.extern uint128_sub
.extern q16_16_mul
.extern lookup_value
.extern neon_add_u32
.extern neon_scale_f32

_start:
    // uint128_add: 0xffffffffffffffff + 1 -> alta:baixa = 1:0.
    mov x0, #-1
    mov x1, #0
    mov x2, #1
    mov x3, #0
    bl uint128_add
    cbnz x0, test_failed
    cmp x1, #1
    b.ne test_failed

    // uint128_sub: 1:0 - 0:1 -> alta:baixa = 0xffffffffffffffff:ffffffffffffffff.
    mov x0, #0
    mov x1, #1
    mov x2, #1
    mov x3, #0
    bl uint128_sub
    mov x4, #-1
    cmp x0, x4
    b.ne test_failed
    cmp x1, xzr
    b.ne test_failed

    // Q16.16: 1.5 * 2.0 = 3.0.
    mov x0, #98304             // 1.5 * 65536
    mov x1, #131072            // 2.0 * 65536
    bl q16_16_mul
    mov x4, #196608            // 3.0 * 65536
    cmp x0, x4
    b.ne test_failed

    // Tabela de consulta: lookup_value(10) == 512.
    mov x0, #10
    bl lookup_value
    mov x4, #512
    cmp x0, x4
    b.ne test_failed

    // Vetor NEON uint32: [1,2,3,4] + [10,20,30,40].
    adrp x0, vec_a
    add x0, x0, :lo12:vec_a
    adrp x1, vec_b
    add x1, x1, :lo12:vec_b
    adrp x2, vec_add_output
    add x2, x2, :lo12:vec_add_output
    bl neon_add_u32
    adrp x0, vec_add_expected
    add x0, x0, :lo12:vec_add_expected
    adrp x1, vec_add_output
    add x1, x1, :lo12:vec_add_output
    mov x2, #16
    bl compare_bytes
    cbnz x0, test_failed

    // Vetor NEON de ponto flutuante: [1,2,3,4] * 2.5 == [2.5,5,7.5,10].
    adrp x0, vec_float_input
    add x0, x0, :lo12:vec_float_input
    adrp x1, scalar_2_5
    add x1, x1, :lo12:scalar_2_5
    ldr s1, [x1]
    adrp x1, vec_float_output
    add x1, x1, :lo12:vec_float_output
    bl neon_scale_f32
    adrp x0, vec_float_expected
    add x0, x0, :lo12:vec_float_expected
    adrp x1, vec_float_output
    add x1, x1, :lo12:vec_float_output
    mov x2, #16
    bl compare_bytes
    cbnz x0, test_failed

    // Linux AArch64: sair com codigo 0.
    mov x0, #0
    mov x8, #93
    svc #0

// compare_bytes(x0=esperado, x1=obtido, x2=tamanho): retorna x0=0 se igual, 1 caso contrario.
.type compare_bytes, %function
compare_bytes:
    cbz x2, compare_equal
compare_loop:
    ldrb w3, [x0], #1
    ldrb w4, [x1], #1
    cmp w3, w4
    b.ne compare_not_equal
    subs x2, x2, #1
    b.ne compare_loop
compare_equal:
    mov x0, #0
    ret
compare_not_equal:
    mov x0, #1
    ret

.type test_failed, %function
test_failed:
    mov x0, #1
    mov x8, #93
    svc #0

.section .rodata
.align 4
vec_a:
    .word 1, 2, 3, 4
vec_b:
    .word 10, 20, 30, 40
vec_add_expected:
    .word 11, 22, 33, 44
vec_float_input:
    .float 1.0, 2.0, 3.0, 4.0
scalar_2_5:
    .float 2.5
vec_float_expected:
    .float 2.5, 5.0, 7.5, 10.0
.section .bss
.align 4
vec_add_output:
    .skip 16
vec_float_output:
    .skip 16
.text
.align 2
