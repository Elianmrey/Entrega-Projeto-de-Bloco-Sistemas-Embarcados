module uart_rx
#(
    parameter CLK_FREQ  = 27000000,      // Frequência do clock da FPGA (27 MHz)
    parameter BAUD_RATE = 9600           // Taxa de transmissão UART
)
(
    input  wire clk,                     // Clock principal
    input  wire rst_n,                   // Reset assíncrono, ativo em baixo
    input  wire uart_rx_in,              // Linha serial de entrada

    output reg [7:0] data_out,           // Byte recebido
    output reg       data_valid          // Pulso: '1' quando data_out é válido
);
// Número de ciclos de clock por bit UART
localparam CLKS_PER_BIT = CLK_FREQ / BAUD_RATE; // 27.000.000 Hz / 9.600 bps= 2812,5 (inteiro: 2812)

// Definição dos estados da FSM
localparam IDLE  = 2'd0;
localparam START = 2'd1;
localparam DATA  = 2'd2;
localparam STOP  = 2'd3;

reg [1:0] state;
reg [15:0] clk_count;
reg [2:0]  bit_index;
reg [7:0]  rx_shift;

// Sincronizador de 2 estágios para mitigar metastabilidade
reg rx_ff1;
reg rx_ff2;

always @(posedge clk)
begin
    rx_ff1 <= uart_rx_in;
    rx_ff2 <= rx_ff1;
end

// Lógica principal da FSM
always @(posedge clk or negedge rst_n)
begin
    if(!rst_n)
    begin
        state      <= IDLE;
        clk_count  <= 0;
        bit_index  <= 0;
        rx_shift   <= 0;
        data_out   <= 0;
        data_valid <= 0;
    end
    else
    begin
        data_valid <= 1'b0; // Pulso de 1 ciclo

        case(state)
            IDLE:
            begin
                clk_count <= 0;
                bit_index <= 0;
                if(rx_ff2 == 1'b0)
                    state <= START;
            end

            START:
            begin
                // Amostra no meio do bit para confirmar start válido
                if(clk_count == (CLKS_PER_BIT/2))
                begin
                    if(rx_ff2 == 1'b0) begin
                        clk_count <= 0;
                        state <= DATA;
                    end
                    else
                        state <= IDLE; // Falso start
                end
                else
                    clk_count <= clk_count + 1;
            end

            DATA:
            begin
                if(clk_count < CLKS_PER_BIT-1)
                    clk_count <= clk_count + 1;
                else
                begin
                    clk_count <= 0;
                    rx_shift[bit_index] <= rx_ff2; // Amostra o bit
                    if(bit_index < 7)
                        bit_index <= bit_index + 1;
                    else
                    begin
                        bit_index <= 0;
                        state <= STOP;
                    end
                end
            end

            STOP:
            begin
                if(clk_count < CLKS_PER_BIT-1)
                    clk_count <= clk_count + 1;
                else
                begin
                    data_out   <= rx_shift; // Transfere o byte recebido
                    data_valid <= 1'b1;    // Sinaliza dado válido
                    clk_count <= 0;
                    state <= IDLE;
                end
            end
            default: state <= IDLE;
        endcase
    end
end

endmodule
