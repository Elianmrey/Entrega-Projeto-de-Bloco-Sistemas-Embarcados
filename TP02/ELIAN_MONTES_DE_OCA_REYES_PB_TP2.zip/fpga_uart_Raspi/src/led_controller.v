module led_controller
(
    input  wire clk,
    input  wire rst_n,
    input  wire uart_rx_in,

    output reg led_temp_out,  // LED indicador de temperatura
    output reg led_pot_out     // LED indicador de potenciômetro
);

// IMPORTANTE: Tang Nano 4K usa cristal de 27MHz no pino 45
parameter CLK_FREQ = 27000000; 
parameter BAUD_RATE = 9600;

// Instância do receptor UART
wire [7:0] rx_data;
wire       rx_valid;

uart_rx #(.CLK_FREQ(CLK_FREQ), .BAUD_RATE(BAUD_RATE)) uart0
(
    .clk(clk),
    .rst_n(rst_n),
    .uart_rx_in(uart_rx_in),
    .data_out(rx_data),
    .data_valid(rx_valid)
);

// Temporizador de LED: ~200 ms a 27 MHz
reg [24:0]  led_timer_count; 
localparam LED_BLINK_TIME = 5400000; // ~0.2s para 27MHz

// Polaridade: 
// Se 1'b1 acende, LED_OFF deve ser 1'b0.
// 
localparam LED_ON  = 1'b1; 
localparam LED_OFF = 1'b0;

always @(posedge clk or negedge rst_n)
begin
    if(!rst_n)
    begin
        // Ao resetar, ligamos os LEDs por um instante, para teste físico
        led_temp_out    <= LED_ON; 
        led_pot_out     <= LED_ON;
        led_timer_count <= LED_BLINK_TIME; 
    end
    else
    begin
        if(rx_valid)
        begin
            // Lógica combinacional de decodificação de comandos ASCII
            if(rx_data == "P") 
            begin
                led_pot_out     <= LED_ON;  // Potenciômetro
                led_timer_count <= LED_BLINK_TIME;
            end
            else if(rx_data == "T")
            begin
                led_temp_out    <= LED_ON;  // Temperatura
                led_timer_count <= LED_BLINK_TIME;
            end
        end
        else if (led_timer_count > 0) 
        begin
            led_timer_count <= led_timer_count - 1; // Decrementa temporizador
        end 
        else 
        begin
            led_pot_out  <= LED_OFF;    // Apaga LED Potenciometro após ~200 ms
            led_temp_out <= LED_OFF;    // Apaga LED Temperatura após ~200 ms
        end
    end
end

endmodule
