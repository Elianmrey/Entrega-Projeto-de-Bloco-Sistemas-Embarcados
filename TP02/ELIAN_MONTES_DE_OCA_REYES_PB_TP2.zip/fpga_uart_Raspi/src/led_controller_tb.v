// led_controller_tb.v

`timescale 1ns / 1ps

module led_controller_tb;

    // Parâmetros (devem corresponder aos definidos em led_controller.v)
    parameter CLK_FREQ  = 27000000;
    parameter BAUD_RATE = 9600;

    // Entradas
    reg clk;
    reg rst_n;
    reg uart_rx_in;

    // Saidas
    wire led_temp_out;
    wire led_pot_out;

    // Instanciar a Unidade Sob Teste (UUT)
    led_controller #(
        .CLK_FREQ(CLK_FREQ),
        .BAUD_RATE(BAUD_RATE)
    ) uut (
        .clk(clk),
        .rst_n(rst_n),
        .uart_rx_in(uart_rx_in),
        .led_temp_out(led_temp_out),
        .led_pot_out(led_pot_out)
    );

    // Geração do clock
    always #((1000000000 / CLK_FREQ) / 2) clk = ~clk;

    // Tarefa para transmitir dados via UART (simulação)
    task uart_transmit;
        input [7:0] tx_data;
        integer i;
        begin
            // Bit de início
            uart_rx_in = 1'b0;
            #((1000000000 / BAUD_RATE));

            // Bits de dados
            for (i = 0; i < 8; i = i + 1) begin
                uart_rx_in = tx_data[i];
                #((1000000000 / BAUD_RATE));
            end

            // Bit de parada
            uart_rx_in = 1'b1;
            #((1000000000 / BAUD_RATE));
        end
    endtask

    initial begin
        // =========================
        // Dump waveform
        // =========================
        $dumpfile("wave.vcd");
        $dumpvars(0, led_controller_tb);
        // =========================

        // Inicializar as entradas
        clk = 1'b0;
        rst_n = 1'b0; // Reset ativo em nível baixo
        uart_rx_in = 1'b1; // Estado ocioso em nível alto

        // Aplicar o reset
        #100;
        rst_n = 1'b1;
        #100;

        $display("Simulação iniciada. Aguardando o heartbeat...");
        #20000000;

        $display("Heartbeat finalizado. Testando comando 'P'...");
        uart_transmit("P");
        #30000000;

        $display("Testando comando 'T'...");
        uart_transmit("T");
        #30000000;

        $display("Simulação finalizada.");
        $finish;
    end

    // Monitor de saidas
    always @(posedge clk) begin
        if (rst_n) begin
            $display("Tempo: %0t, led_pot_out: %b, led_temp_out: %b", $time, led_pot_out, led_temp_out);
        end
    end

endmodule