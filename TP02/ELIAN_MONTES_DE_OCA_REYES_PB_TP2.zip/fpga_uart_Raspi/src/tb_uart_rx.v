// tb_uart_rx.v

`timescale 1ns / 1ps

module tb_uart_rx;

    // Parâmetros (devem corresponder aos definidos em uart_rx.v)
    parameter CLK_FREQ  = 27000000;
    parameter BAUD_RATE = 9600;

    // Entradas
    reg clk;
    reg rst_n;
    reg uart_tx_out; // Este sinal será conectado à entrada uart_rx_in da UUT

    // Saídas
    wire [7:0] data_out;
    wire       data_valid;

    // Instanciação da Unidade Sob Teste (UUT)
    uart_rx #(
        .CLK_FREQ(CLK_FREQ),
        .BAUD_RATE(BAUD_RATE)
    ) uut (
        .clk(clk),
        .rst_n(rst_n),
        .uart_rx_in(uart_tx_out),
        .data_out(data_out),
        .data_valid(data_valid)
    );

    // Geração de clock
    always #((1000000000 / CLK_FREQ) / 2) clk = ~clk;

    // Tarefa de transmissão UART (simulação de entrada de dados no RX)
    task uart_transmit_data;
        input [7:0] tx_data;
        integer i;
        begin
            // Bit de início
            uart_tx_out = 1'b0;
            #((1000000000 / BAUD_RATE));

            // Bits de dados (LSB primeiro)
            for (i = 0; i < 8; i = i + 1) begin
                uart_tx_out = tx_data[i];
                #((1000000000 / BAUD_RATE));
            end

            // Bit de parada
            uart_tx_out = 1'b1;
            #((1000000000 / BAUD_RATE));
        end
    endtask

    initial begin
        // Inicialização dos sinais
        clk = 1'b0;
        rst_n = 1'b0;        // Reset ativo em nível baixo
        uart_tx_out = 1'b1;  // Linha em estado ocioso (idle em nível alto)

        // Aplicação do reset
        #100;
        rst_n = 1'b1; // Liberação do reset

        // Simulação
        $display("Simulação iniciada. Enviando o caractere 'A'...");
        uart_transmit_data(8'h41); // ASCII 'A'
        #500000; // Aguarda recepção

        $display("Enviando caractere 'B'...");
        uart_transmit_data(8'h42); // ASCII 'B'
        #500000; // Aguarda recepção

        $display("Simulação finalizada.");
        $finish;
    end

    // Monitoramento das saídas
    always @(posedge clk) begin
        if (data_valid) begin
            $display("Tempo: %0t | Dados recebidos: %c (0x%h)", $time, data_out, data_out);
        end
    end

endmodule