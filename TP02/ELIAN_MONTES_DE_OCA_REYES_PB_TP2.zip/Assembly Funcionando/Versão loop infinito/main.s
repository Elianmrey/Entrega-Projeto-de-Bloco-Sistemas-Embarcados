.global _start

.extern sr_potenciometro
.extern sr_temperatura

//--------------------------------------------------
// SYSCALLS
//--------------------------------------------------

.equ SYS_OPENAT, 56
.equ SYS_WRITE, 64
.equ SYS_CLOSE, 57
.equ SYS_EXIT, 93

.equ O_RDWR, 2

//--------------------------------------------------
// UART
//--------------------------------------------------

.section .data

uart_dev:
.asciz "/dev/ttyS0"

newline:
.ascii "\n"

msg_pot:
.asciz "Enviando Potenciometro: "

msg_temp:
.asciz "Enviando Temperatura: "

.section .text

_start:

//--------------------------------------------------
// ABRE UART
//--------------------------------------------------

mov x0,#-100
ldr x1,=uart_dev
mov x2,#O_RDWR
mov x3,#0
mov x8,#SYS_OPENAT
svc #0

cmp x0,#0
blt fim_erro // Se x0 < 0, houve um erro ao abrir a UART, vai para fim_erro

mov x19,x0 // Salva o file descriptor da UART em x19

//--------------------------------------------------
// LOOP PRINCIPAL (INFINITO)
//--------------------------------------------------

loop:

//--------------------------------------------------
// POTENCIOMETRO
//--------------------------------------------------

bl sr_potenciometro

mov x20,x0 // Endereço da string
mov x21,x1 // Tamanho da string

// Imprime no terminal "Enviando Potenciometro: "
mov x0, #1 // stdout
ldr x1, =msg_pot
mov x2, #24
mov x8, #SYS_WRITE
svc #0

// Imprime o valor no terminal
mov x0, #1 // stdout
mov x1, x20
mov x2, x21
mov x8, #SYS_WRITE
svc #0

// Imprime newline no terminal
mov x0, #1 // stdout
ldr x1, =newline
mov x2, #1
mov x8, #SYS_WRITE
svc #0

// Envia via UART
mov x0,x19
mov x1,x20
mov x2,x21
mov x8,#SYS_WRITE
svc #0

// Envia newline via UART
mov x0,x19
ldr x1,=newline
mov x2,#1
mov x8,#SYS_WRITE
svc #0

//--------------------------------------------------
// DELAY
//--------------------------------------------------
ldr x22,=4000000
delay1:
subs x22,x22,#1
bne delay1

//--------------------------------------------------
// TEMPERATURA
//--------------------------------------------------

bl sr_temperatura

mov x20,x0 // Endereço da string
mov x21,x1 // Tamanho da string

// Imprime no terminal "Enviando Temperatura: "
mov x0, #1 // stdout
ldr x1, =msg_temp
mov x2, #22
mov x8, #SYS_WRITE
svc #0

// Imprime o valor no terminal
mov x0, #1 // stdout
mov x1, x20
mov x2, x21
mov x8, #SYS_WRITE
svc #0

// Imprime newline no terminal
mov x0, #1 // stdout
ldr x1, =newline
mov x2, #1
mov x8, #SYS_WRITE
svc #0

// Envia via UART
mov x0,x19
mov x1,x20
mov x2,x21
mov x8,#SYS_WRITE
svc #0

// Envia newline via UART
mov x0,x19
ldr x1,=newline
mov x2,#1
mov x8,#SYS_WRITE
svc #0

//--------------------------------------------------
// DELAY
//--------------------------------------------------

ldr x22,=4000000

delay2:
subs x22,x22,#1
bne delay2

b loop // Loop infinito

//--------------------------------------------------
// FINALIZA EM CASO DE ERRO NA ABERTURA DA UART
//--------------------------------------------------
fim_erro:

// Fecha a UART se ela foi aberta com sucesso antes de um erro
cmp x19, #0
blt nao_fechar_uart // Se x19 < 0, a UART não foi aberta ou houve erro, não precisa fechar
mov x0,x19
mov x8,#SYS_CLOSE
svc #0

nao_fechar_uart:
mov x0,#1 // Código de erro
mov x8,#SYS_EXIT
svc #0
