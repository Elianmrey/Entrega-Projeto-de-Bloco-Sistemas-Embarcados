.global sr_potenciometro

.equ SYS_OPENAT, 56
.equ SYS_IOCTL, 29
.equ SYS_CLOSE, 57

.equ O_RDWR, 2
.equ SPI_IOC_MESSAGE_1, 0x40206B00

.section .data

spi_dev_p:
    .asciz "/dev/spidev0.0"

tx_buf_p:
    .byte 0x01
    .byte 0xF0
    .byte 0x00

rx_buf_p:
    .byte 0,0,0

pot_string:
    .space 8

.balign 8

tr_p:
    .quad tx_buf_p
    .quad rx_buf_p
    .word 3
    .word 1000000
    .hword 0
    .byte 8
    .byte 0
    .byte 0
    .byte 0
    .byte 0
    .byte 0

.section .text

sr_potenciometro:
    // Salva registradores que serão usados
    stp x29, x30, [sp, #-32]!
    mov x29, sp
    str x19, [sp, #16]

    mov x0,#-100
    ldr x1,=spi_dev_p
    mov x2,#O_RDWR
    mov x3,#0
    mov x8,#SYS_OPENAT
    svc #0

    mov x19,x0

    mov x0,x19
    movz x1,#0x6B00
    movk x1,#0x4020,lsl #16
    ldr x2,=tr_p
    mov x8,#SYS_IOCTL
    svc #0

    ldr x0,=rx_buf_p

    ldrb w1,[x0,#1]
    ldrb w2,[x0,#2]

    and w1,w1,#3
    lsl w1,w1,#8
    orr w20,w1,w2

    mov x0,x19
    mov x8,#SYS_CLOSE
    svc #0

    ldr x9,=pot_string

    mov w10, #80 // Código ASCII para 'P'
    strb w10,[x9]

    add x1,x9,#1
    mov w0,w20
    bl itoa_sr

    add x0,x0,#1 // +1 para o prefixo 'P'

    mov x1,x0
    ldr x0,=pot_string

    // Restaura registradores
    ldr x19, [sp, #16]
    ldp x29, x30, [sp], #32
    ret

itoa_sr:

    mov x11,x1
    mov w12,#10
    mov x13,#0

1:
    udiv w14,w0,w12
    msub w15,w14,w12,w0
    add w15,w15,#48
    strb w15,[x11,x13]
    add x13,x13,#1
    mov w0,w14
    cbnz w0,1b

    mov x14,#0
    sub x15,x13,#1

2:
    cmp x14,x15
    bge 3f

    ldrb w16,[x11,x14]
    ldrb w17,[x11,x15]

    strb w17,[x11,x14]
    strb w16,[x11,x15]

    add x14,x14,#1
    sub x15,x15,#1

    b 2b

3:
    mov w16,#0
    strb w16,[x11,x13]

    mov x0,x13
    ret
